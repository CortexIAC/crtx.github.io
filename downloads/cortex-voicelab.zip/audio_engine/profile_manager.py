import json
import os
from typing import List, Optional, Callable
from audio_engine.models.profile import Profile
from audio_engine.models.blueprint import Blueprint
from audio_engine.blueprint_manager import BlueprintManager


class ProfileManager:
    def __init__(self, blueprint_manager: BlueprintManager, profiles_dir: str = ""):
        self._bm = blueprint_manager
        self._directory = profiles_dir
        self._profiles: List[Profile] = []
        self._current: Optional[Profile] = None
        self._on_change: list[Callable] = []

        self._load_builtins()

    @property
    def current(self) -> Optional[Profile]:
        return self._current

    @property
    def all(self) -> List[Profile]:
        return self._profiles

    def on_change(self, listener: Callable):
        self._on_change.append(listener)

    def _notify(self):
        for listener in self._on_change:
            try:
                listener(self._current)
            except Exception:
                pass

    def _load_builtins(self):
        self._profiles = [
            Profile("deep_voice", "Deep Voice", "Deep, resonant voice with enhanced low frequencies",
                     "deep_voice", "volume-down", "voice", is_builtin=True),
            Profile("female_voice", "Female Voice", "Higher pitch voice with bright tonal characteristics",
                     "female_voice", "volume-up", "voice", is_builtin=True),
            Profile("commander", "Commander", "Authoritative command voice with radio compression",
                     "commander", "military-tech", "character", is_builtin=True),
            Profile("radio_operator", "Radio Operator", "Classic radio communication voice",
                     "radio_operator", "radio", "character", is_builtin=True),
            Profile("storm_chaser", "Storm Chaser", "Weather-beaten radio voice with atmosphere",
                     "storm_chaser", "storm", "character", is_builtin=True),
            Profile("robot", "Robot", "Robotic voice with mechanical resonance",
                     "robot", "android", "character", is_builtin=True),
            Profile("cyberpunk", "Cyberpunk", "Futuristic cybernetic voice with glitch effects",
                     "cyberpunk", "cyber", "character", is_builtin=True),
            Profile("narrator", "Narrator", "Rich cinematic narration voice",
                     "narrator", "record-voice-over", "character", is_builtin=True),
        ]

    def select(self, name: str) -> Optional[Profile]:
        profile = self.get(name)
        if profile is None:
            return None
        self._current = profile
        self._notify()
        return profile

    def get(self, name: str) -> Optional[Profile]:
        for p in self._profiles:
            if p.name == name:
                return p
        return None

    def add(self, profile: Profile):
        existing = self.get(profile.name)
        if existing:
            self._profiles.remove(existing)
        self._profiles.append(profile)

    def remove(self, name: str):
        self._profiles = [p for p in self._profiles if p.name != name]
        if self._current and self._current.name == name:
            self._current = None

    def get_blueprint(self, profile: Profile) -> Optional[Blueprint]:
        return self._bm.load(profile.blueprint_name)

    def get_current_blueprint(self) -> Optional[Blueprint]:
        if self._current is None:
            return None
        return self.get_blueprint(self._current)

    def save(self):
        if not self._directory:
            return
        os.makedirs(self._directory, exist_ok=True)
        for profile in self._profiles:
            if profile.is_builtin:
                continue
            path = os.path.join(self._directory, f"{profile.name}.json")
            with open(path, "w", encoding="utf-8") as f:
                json.dump(profile.to_dict(), f, indent=2)

    def load_user_profiles(self):
        if not self._directory or not os.path.exists(self._directory):
            return
        for f in os.listdir(self._directory):
            if f.endswith(".json"):
                path = os.path.join(self._directory, f)
                try:
                    with open(path, "r", encoding="utf-8") as fp:
                        data = json.load(fp)
                    profile = Profile.from_dict(data)
                    existing = self.get(profile.name)
                    if existing:
                        self._profiles.remove(existing)
                    self._profiles.append(profile)
                except Exception:
                    pass
