"""
Cortex Audio Engine (CAE)
=======================
A standalone, reusable audio framework for real-time voice processing,
audio routing, device management, and effects processing.

Designed for consumption by VoiceLab, VortexLink, Cortex Studio,
Synapse Core, and future Cortex applications.

Usage:
    from audio_engine import AudioEngine

    engine = AudioEngine()
    engine.initialize()
    engine.start()
    engine.set_profile("deep_voice")
    # Voice is now processed in real-time
    engine.stop()
"""

__version__ = "1.0.0"
__author__ = "Cortex Intelligence"

from typing import Optional

from audio_engine.device_manager import DeviceManager
from audio_engine.audio_router import AudioRouter
from audio_engine.audio_pipeline import AudioPipeline
from audio_engine.blueprint_manager import BlueprintManager
from audio_engine.profile_manager import ProfileManager

from audio_engine.voice_conversion import ModelManager, RVCInference, PerformanceMonitor
from audio_engine.integrations import VoiceModBridge
from audio_engine.models.audio_device import AudioDevice, AudioLevel, StreamConfig, StreamMetrics
from audio_engine.models.processing_node import ProcessingNode, NodeType, NodeConnection, NodeParameter
from audio_engine.models.blueprint import Blueprint
from audio_engine.models.profile import Profile
from audio_engine.models.settings import AppSettings


class AudioEngine:
    """High-level facade for the complete Cortex Audio Engine.

    Provides a single entry point integrating device management, audio routing,
    pipeline processing, blueprint management, and profile management.
    """

    def __init__(self):
        self.devices = DeviceManager()
        self.router = AudioRouter(self.devices)
        self.pipeline = AudioPipeline()
        self.blueprints = BlueprintManager()
        self.profiles = ProfileManager(self.blueprints)
        self.vc_models = ModelManager()
        self.voicemod = VoiceModBridge()
        self.settings = AppSettings()

        self._initialized = False

    # --- Lifecycle ---

    def initialize(self, blueprints_dir: str = "", profiles_dir: str = ""):
        if blueprints_dir:
            self.blueprints.directory = blueprints_dir
        if profiles_dir:
            self.profiles._directory = profiles_dir
            self.profiles.load_user_profiles()
        self._initialized = True

    def start(self):
        if not self._initialized:
            raise RuntimeError("Engine not initialized. Call initialize() first.")
        self.router.set_processing_callback(self.pipeline.process)
        self.router.set_config_callback(self.pipeline.configure)
        self.router.start()
        # Auto-enable live playback if a profile is loaded
        if self.current_profile:
            self.router.live_playback = True

    def stop(self):
        self.router.stop()

    def shutdown(self):
        self.stop()
        self.devices.shutdown()
        self.router.shutdown()

    # --- Blueprint / Profile ---

    def set_blueprint(self, name: str) -> bool:
        bp = self.blueprints.load(name)
        if bp is None:
            return False
        self.pipeline.set_blueprint(bp)
        return True

    def set_profile(self, name: str) -> bool:
        profile = self.profiles.select(name)
        if profile is None:
            return False
        bp = self.profiles.get_blueprint(profile)
        if bp is not None:
            self.pipeline.set_blueprint(bp)
        # Enable live playback so the user hears the profile immediately
        if self.is_active:
            self.router.live_playback = True
        return True

    @property
    def current_profile(self) -> Optional[str]:
        p = self.profiles.current
        return p.display_name if p else None

    @property
    def current_blueprint(self) -> Optional[str]:
        bp = self.profiles.get_current_blueprint()
        return bp.name if bp else None

    # --- Live playback control ---

    @property
    def live_playback(self) -> bool:
        return self.router.live_playback

    @live_playback.setter
    def live_playback(self, enabled: bool):
        self.router.live_playback = enabled

    @property
    def bypass(self) -> bool:
        return self.router.bypass

    @bypass.setter
    def bypass(self, enabled: bool):
        self.router.bypass = enabled

    @property
    def low_latency_mode(self) -> bool:
        return self.router._config.buffer_size <= 128

    @low_latency_mode.setter
    def low_latency_mode(self, enabled: bool):
        self.router._config.buffer_size = 128 if enabled else 256
        self.router._config.latency = 0.003 if enabled else 0.005
        if self.is_active:
            self.restart()

    def restart(self):
        """Restart the audio stream with current config."""
        was_active = self.is_active
        if was_active:
            self.stop()
        self.start()

    @property
    def input_gain(self) -> float:
        return self.router.input_gain

    @input_gain.setter
    def input_gain(self, value: float):
        self.router.input_gain = value

    # --- Metrics ---

    @property
    def metrics(self):
        return self.router.metrics

    @property
    def is_active(self) -> bool:
        return self.router.is_active


# Convenience exports
__all__ = [
    "AudioEngine",
    "DeviceManager",
    "AudioRouter",
    "AudioPipeline",
    "BlueprintManager",
    "ProfileManager",
    "ModelManager",
    "RVCInference",
    "PerformanceMonitor",
    "AppSettings",
    "AudioDevice",
    "AudioLevel",
    "StreamConfig",
    "StreamMetrics",
    "ProcessingNode",
    "NodeType",
    "NodeConnection",
    "NodeParameter",
    "Blueprint",
    "Profile",
]
