import re
import sounddevice as sd
import numpy as np
from typing import List, Optional, Callable
from audio_engine.models.audio_device import AudioDevice, DeviceType, AudioLevel


class DeviceManager:
    def __init__(self):
        self._devices: List[AudioDevice] = []
        self._default_input: Optional[str] = None
        self._default_output: Optional[str] = None
        self._selected_input: Optional[str] = None
        self._selected_output: Optional[str] = None
        self._level_listeners: list[Callable] = []
        self.refresh()

    def refresh(self):
        self._devices.clear()
        try:
            devices = sd.query_devices()
            default_input = sd.default.device[0]
            default_output = sd.default.device[1]

            for i, dev in enumerate(devices):
                has_input = dev["max_input_channels"] > 0
                has_output = dev["max_output_channels"] > 0
                if has_input and has_output:
                    dtype = DeviceType.DUPLEX
                elif has_input:
                    dtype = DeviceType.INPUT
                else:
                    dtype = DeviceType.OUTPUT

                max_in = dev["max_input_channels"]
                max_out = dev["max_output_channels"]
                audio_dev = AudioDevice(
                    id=str(i),
                    name=dev["name"],
                    device_type=dtype,
                    channels=max(max_in, max_out),
                    input_channels=max_in,
                    output_channels=max_out,
                    sample_rate=int(dev.get("default_samplerate", 48000)),
                    is_default=(i == default_input or i == default_output),
                    host_api=str(dev.get("hostapi", "")),
                )
                self._devices.append(audio_dev)

                if i == default_input:
                    self._default_input = str(i)
                if i == default_output:
                    self._default_output = str(i)
        except Exception:
            pass

    # --- Queries ---

    def all(self) -> List[AudioDevice]:
        return self._devices

    def inputs(self) -> List[AudioDevice]:
        return [d for d in self._devices if d.is_input]

    def outputs(self) -> List[AudioDevice]:
        return [d for d in self._devices if d.is_output]

    def get(self, device_id: str) -> Optional[AudioDevice]:
        for d in self._devices:
            if d.id == device_id:
                return d
        return None

    def default_input(self) -> Optional[AudioDevice]:
        return self.get(self._default_input) if self._default_input else None

    def default_output(self) -> Optional[AudioDevice]:
        return self.get(self._default_output) if self._default_output else None

    # --- Selection ---

    @property
    def selected_input_id(self) -> Optional[str]:
        return self._selected_input or self._default_input

    @property
    def selected_output_id(self) -> Optional[str]:
        return self._selected_output or self._default_output

    def select_input(self, device_id: str):
        if self.get(device_id) and self.get(device_id).is_input:
            self._selected_input = device_id

    def select_output(self, device_id: str):
        if self.get(device_id) and self.get(device_id).is_output:
            self._selected_output = device_id

    # --- Smart Device Pairing ---

    def suggest_pair(self) -> tuple:
        """Find the best matching input/output device pair (headset > monitor).
        Returns (input_id, output_id). Prioritizes WASAPI host API for low latency."""
        inputs = self.inputs()
        outputs = self.outputs()
        if not inputs or not outputs:
            return (self.selected_input_id, self.selected_output_id)

        host_names = {}
        try:
            for i, api in enumerate(sd.query_hostapis()):
                host_names[str(i)] = api["name"]
        except Exception:
            pass

        api_priority = {"Windows WASAPI": 0, "Windows WDM-KS": 1, "Windows DirectSound": 2, "MME": 3}

        def api_score(dev):
            name = host_names.get(str(getattr(dev, 'host_api', '0')), "")
            return api_priority.get(name, 99)

        # Extract a "key" from device name: shared identifying substring
        def device_key(name):
            n = name.lower().strip()
            # Remove common prefixes
            for prefix in ["microphone ", "speakers ", "output ", "input "]:
                if n.startswith(prefix):
                    n = n[len(prefix):]
            # Strip trailing host-API suffixes like "(wasapi)", "(windows directsound)"
            n = re.sub(r'\s*\((wasapi|windows directsound|mme|windows wdm-ks)\)\s*$', '', n)
            return n.strip()

        # Headset keywords to prefer
        headset_kws = ["g432", "logitech", "gaming headset", "headset"]

        def has_headset(name):
            n = name.lower()
            return any(k in n for k in headset_kws)

        best_pair = (self.selected_input_id, self.selected_output_id)
        best_score = 999

        for inp in inputs:
            for out in outputs:
                in_key = device_key(inp.name)
                out_key = device_key(out.name)

                # Same host API + matching key = strongest pair
                same_api = inp.host_api == out.host_api
                key_match = in_key == out_key or (len(in_key) > 5 and in_key in out_key) or (len(out_key) > 5 and out_key in in_key)
                is_headset = has_headset(inp.name) and has_headset(out.name)

                if same_api and key_match and is_headset:
                    score = api_score(inp) + api_score(out)
                    if score < best_score:
                        best_score = score
                        best_pair = (inp.id, out.id)

        # Second pass: same API + any key match (for non-headset pairs)
        if best_score == 999:
            for inp in inputs:
                for out in outputs:
                    in_key = device_key(inp.name)
                    out_key = device_key(out.name)
                    same_api = inp.host_api == out.host_api
                    key_match = (len(in_key) > 3 and in_key in out_key) or (len(out_key) > 3 and out_key in in_key)

                    if same_api and key_match:
                        if best_score == 999 or api_score(inp) + api_score(out) < best_score:
                            best_score = api_score(inp) + api_score(out)
                            best_pair = (inp.id, out.id)

        # Third pass: headset devices even on different APIs
        if best_score == 999:
            for inp in inputs:
                for out in outputs:
                    if has_headset(inp.name) and has_headset(out.name):
                        score = api_score(inp) + api_score(out)
                        if score < best_score:
                            best_score = score
                            best_pair = (inp.id, out.id)

        return best_pair

    # --- Level Monitoring ---

    def on_level(self, listener: Callable):
        self._level_listeners.append(listener)

    def _notify_level(self, level: AudioLevel):
        for listener in self._level_listeners:
            try:
                listener(level)
            except Exception:
                pass

    @property
    def default_sample_rate(self) -> int:
        try:
            dev = sd.query_devices(kind="input")
            return int(dev["default_samplerate"])
        except Exception:
            return 48000

    def read_level(self, device_id: Optional[str] = None, duration: float = 0.05) -> AudioLevel:
        try:
            dev_id = int(device_id) if device_id else None
            data = sd.rec(
                int(duration * 48000),
                samplerate=48000,
                channels=1 if dev_id else 2,
                device=dev_id,
                blocking=True,
            )
            level = AudioLevel()
            if len(data) > 0:
                level.peak = float(np.abs(data).max())
                level.rms = float(np.sqrt(np.mean(data ** 2)))
                if data.shape[1] > 0:
                    level.left = float(np.abs(data[:, 0]).max())
                if data.shape[1] > 1:
                    level.right = float(np.abs(data[:, -1]).max())
                level.is_clipping = level.peak > 0.95
            return level
        except Exception:
            return AudioLevel()

    def shutdown(self):
        self._level_listeners.clear()
