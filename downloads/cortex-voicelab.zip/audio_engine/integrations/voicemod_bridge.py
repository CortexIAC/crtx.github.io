"""VoiceMod Bridge — detects VoiceMod virtual devices and routes audio
through VoiceMod's processing engine.

When active, the audio chain becomes:
  Mic → Our pipeline → VoiceMod Virtual Input
  VoiceMod Virtual Output → Our output → Speakers

Requires VoiceMod or a virtual audio cable to be installed.
"""

import threading
import numpy as np
import sounddevice as sd
from typing import Optional, Callable


class VoiceModBridge:
    """Manages audio routing through VoiceMod's virtual devices."""

    def __init__(self):
        self._vm_input_id: Optional[int] = None    # device index for VoiceMod's virtual output (we read from it)
        self._vm_output_id: Optional[int] = None   # device index for VoiceMod's virtual input (we write to it)
        self._enabled: bool = False
        self._running: bool = False
        self._stream: Optional[sd.Stream] = None
        self._processing_callback: Optional[Callable] = None

    # -- Detection --------------------------------------------------------

    @property
    def is_installed(self) -> bool:
        """Check if VoiceMod virtual devices exist on the system."""
        in_id, out_id = self._find_devices()
        return in_id is not None and out_id is not None

    def _find_devices(self):
        """Find VoiceMod virtual audio device indices.

        Returns (input_device_id, output_device_id) or (None, None).
        """
        vm_keywords = ["voicemod", "voice mod", "voice_mod"]
        try:
            devices = sd.query_devices()
            vm_in, vm_out = None, None
            for i, dev in enumerate(devices):
                name = dev["name"].lower()
                is_vm = any(k in name for k in vm_keywords)
                if not is_vm:
                    continue
                if dev["max_input_channels"] > 0 and dev["max_output_channels"] == 0:
                    vm_in = i
                elif dev["max_output_channels"] > 0:
                    vm_out = i
            return vm_in, vm_out
        except Exception:
            return None, None

    @property
    def device_name(self) -> str:
        """Return the name of the detected VoiceMod device."""
        devices = sd.query_devices()
        if self._vm_input_id is not None and self._vm_input_id < len(devices):
            return devices[self._vm_input_id]["name"]
        if self._vm_output_id is not None and self._vm_output_id < len(devices):
            return devices[self._vm_output_id]["name"]
        return "VoiceMod (not detected)"

    @property
    def input_device_id(self) -> Optional[int]:
        return self._vm_input_id

    @property
    def output_device_id(self) -> Optional[int]:
        return self._vm_output_id

    # -- State -----------------------------------------------------------

    @property
    def enabled(self) -> bool:
        return self._enabled

    @enabled.setter
    def enabled(self, val: bool):
        self._enabled = val

    @property
    def is_active(self) -> bool:
        return self._running

    def set_processing_callback(self, cb: Callable):
        self._processing_callback = cb

    # -- Stream lifecycle ------------------------------------------------

    def start(self):
        """Open a VoiceMod passthrough stream.

        Audio flow:
          Mic → VoiceMod Virtual Input → [VoiceMod processes] → VoiceMod Virtual Output → Speakers
        """
        if self._running:
            return
        if not self._enabled:
            return

        vm_in, vm_out = self._find_devices()
        self._vm_input_id = vm_in
        self._vm_output_id = vm_out

        if vm_in is None or vm_out is None:
            raise RuntimeError("VoiceMod virtual devices not found")

        try:
            # We read from VoiceMod's virtual microphone (its processed output)
            # and write to VoiceMod's virtual input (our mic feed)
            # But actually the simpler approach: just select VoiceMod devices
            # as the router's output, letting PortAudio handle the routing.

            # The bridge creates a dedicated passthrough stream through VoiceMod.
            # Router handles the mic → VoiceMod part, bridge handles VoiceMod → speakers.
            sr = 44100
            bs = 512

            self._stream = sd.Stream(
                device=(vm_in, vm_out),
                samplerate=sr,
                blocksize=bs,
                channels=(2, 2),
                dtype="float32",
                latency="high",
                callback=self._callback,
            )
            self._stream.start()
            self._running = True
        except Exception as e:
            self._running = False
            raise RuntimeError(f"Failed to start VoiceMod bridge: {e}")

    def _callback(self, indata, outdata, frames, time_info, status):
        """VoiceMod passthrough: read processed audio from VoiceMod,
        forward to output."""
        if self._enabled and self._processing_callback:
            try:
                processed = self._processing_callback(indata.copy())
                outdata[:] = processed.reshape(outdata.shape)
            except Exception:
                outdata[:] = indata
        else:
            outdata[:] = indata

    def stop(self):
        self._running = False
        if self._stream:
            try:
                self._stream.stop()
                self._stream.close()
            except Exception:
                pass
            self._stream = None

    def shutdown(self):
        self.stop()
