import time
import numpy as np
import sounddevice as sd
from typing import Optional, Callable, List, Tuple
from audio_engine.models.audio_device import (
    AudioDevice, AudioLevel, StreamConfig, StreamMetrics,
)
from audio_engine.device_manager import DeviceManager


def _boost_audio_priority():
    """Boost the audio callback thread priority on Windows."""
    try:
        import ctypes
        win32 = ctypes.windll.kernel32
        win32.SetThreadPriority(win32.GetCurrentThread(), 1)
    except Exception:
        pass


# Max fraction of buffer duration allowed for processing before we drop effects
_MAX_PROCESS_TIME_FRAC = 0.6


class AudioRouter:
    def __init__(self, device_manager: DeviceManager):
        self._dm = device_manager
        self._stream: Optional[sd.Stream] = None
        self._input_stream: Optional[sd.InputStream] = None
        self._output_stream: Optional[sd.OutputStream] = None

        self._config = StreamConfig()
        self._processing_callback: Optional[Callable] = None
        self._config_callback: Optional[Callable] = None
        self._metrics_listeners: list[Callable] = []
        self._metrics = StreamMetrics()
        self._running = False
        self._live_playback: bool = False
        self._bypass: bool = False
        self._input_gain: float = 1.0

        # Processing budget tracking
        self._budget_s: float = 0.01
        self._overload_count: int = 0
        self._frame_counter: int = 0
        self._level_skip: int = 0
        self._processing: bool = False  # guard: true while callback is busy
        self._work_buf: Optional[np.ndarray] = None  # pre-allocated work buffer
        self._silence_buf: Optional[np.ndarray] = None  # pre-allocated silence
        self._drop_window: int = 0  # drops in last 1000 frames

    # --- Properties ---

    @property
    def config(self) -> StreamConfig:
        return self._config

    @config.setter
    def config(self, cfg: StreamConfig):
        self._config = cfg

    @property
    def metrics(self) -> StreamMetrics:
        return self._metrics

    @property
    def is_active(self) -> bool:
        return self._running

    @property
    def live_playback(self) -> bool:
        return self._live_playback

    @live_playback.setter
    def live_playback(self, enabled: bool):
        self._live_playback = enabled

    @property
    def bypass(self) -> bool:
        return self._bypass

    @bypass.setter
    def bypass(self, enabled: bool):
        self._bypass = enabled

    @property
    def input_gain(self) -> float:
        return self._input_gain

    @input_gain.setter
    def input_gain(self, value: float):
        self._input_gain = max(0.0, min(5.0, value))

    # --- Callbacks ---

    def set_processing_callback(self, callback: Callable[[np.ndarray], np.ndarray]):
        self._processing_callback = callback

    def set_config_callback(self, callback: Callable[[int, int], None]):
        self._config_callback = callback

    def on_metrics(self, listener: Callable):
        self._metrics_listeners.append(listener)

    # --- Device Resolution ---

    def _query_device(self, device_id: int) -> tuple:
        try:
            info = sd.query_devices(device_id)
            return (
                info["max_input_channels"],
                info["max_output_channels"],
                int(info.get("default_samplerate", 44100)),
            )
        except Exception:
            return (0, 0, 44100)

    def _resolve_stream_config(self):
        input_id = self._dm.selected_input_id
        output_id = self._dm.selected_output_id
        input_idx = int(input_id) if input_id is not None else None
        output_idx = int(output_id) if output_id is not None else None

        in_ch, _, sr_in = self._query_device(input_idx) if input_idx is not None else (0, 0, 44100)
        _, out_ch, sr_out = self._query_device(output_idx) if output_idx is not None else (0, 0, 44100)

        if input_idx is not None and output_idx is not None:
            sr = sr_in if sr_in == sr_out else min(sr_in, sr_out)
        elif input_idx is not None:
            sr = sr_in
        else:
            sr = sr_out

        cfg_sr = self._config.sample_rate
        if cfg_sr in (sr_in, sr_out) or (input_idx is None and output_idx is None):
            sr = cfg_sr

        bs = max(64, min(1024, self._config.buffer_size))
        return (input_idx, output_idx, sr, bs, (max(in_ch, 1), max(out_ch, 1)))

    # --- Stream Lifecycle ---

    def start(self):
        if self._running:
            return

        input_idx, output_idx, sr, bs, (in_ch, out_ch) = self._resolve_stream_config()
        if input_idx is None and output_idx is None:
            raise RuntimeError("No input or output device selected")

        self._config.sample_rate = sr
        self._config.buffer_size = bs
        self._budget_s = bs / sr * _MAX_PROCESS_TIME_FRAC
        self._overload_count = 0
        self._frame_counter = 0

        _boost_audio_priority()

        if self._config_callback:
            try:
                self._config_callback(sr, bs)
            except Exception:
                pass

        if input_idx is not None and output_idx is not None:
            try:
                self._stream = sd.Stream(
                    device=(input_idx, output_idx),
                    samplerate=sr, blocksize=bs,
                    channels=(in_ch, out_ch),
                    dtype="float32", latency=self._config.latency,
                    callback=self._duplex_callback,
                )
                self._stream.start()
            except Exception:
                self._stream = None
                self._input_stream = sd.InputStream(
                    device=input_idx, samplerate=sr, blocksize=bs,
                    channels=in_ch, dtype="float32", latency=self._config.latency,
                    callback=self._input_callback,
                )
                self._input_stream.start()
                self._output_stream = sd.OutputStream(
                    device=output_idx, samplerate=sr, blocksize=bs,
                    channels=out_ch, dtype="float32", latency=self._config.latency,
                )
                self._output_stream.start()
        elif input_idx is not None:
            self._input_stream = sd.InputStream(
                device=input_idx, samplerate=sr, blocksize=bs,
                channels=in_ch, dtype="float32", latency=self._config.latency,
                callback=self._input_callback,
            )
            self._input_stream.start()
        elif output_idx is not None:
            self._output_stream = sd.OutputStream(
                device=output_idx, samplerate=sr, blocksize=bs,
                channels=out_ch, dtype="float32", latency=self._config.latency,
            )
            self._output_stream.start()

        self._running = True
        self._metrics.is_active = True
        self._notify_metrics()

    def stop(self):
        self._running = False
        self._metrics.is_active = False
        for s in ("_stream", "_input_stream", "_output_stream"):
            handle = getattr(self, s, None)
            if handle:
                try:
                    handle.stop()
                    handle.close()
                except Exception:
                    pass
                setattr(self, s, None)
        self._notify_metrics()

    # --- Fast Processing (no locks, no allocations beyond what's needed) ---

    def _process(self, audio: np.ndarray) -> np.ndarray:
        """Process audio with time budget protection. Must be fast."""
        gain = self._input_gain
        if gain != 1.0:
            audio = audio * gain

        if self._bypass or not self._live_playback:
            return audio

        cb = self._processing_callback
        if cb is None:
            return audio

        start = time.perf_counter()
        try:
            out = cb(audio)
        except Exception:
            return audio
        elapsed = time.perf_counter() - start

        # Budget guard: if processing took too long, count overload and future
        # calls will be more aggressive about skipping
        if elapsed > self._budget_s:
            self._overload_count += 1

        return out

    def _match_channels(self, audio: np.ndarray, target_channels: int) -> np.ndarray:
        if audio.ndim == 1:
            audio = audio.reshape(-1, 1)
        current = audio.shape[1]
        if current == target_channels:
            return audio
        if current > target_channels:
            return audio[:, :target_channels]
        repeats = target_channels // current + 1
        audio = np.tile(audio, (1, repeats))
        return audio[:, :target_channels]

    # --- Duplex callback (hot path — keep minimal) ---

    def _duplex_callback(self, indata: np.ndarray, outdata: np.ndarray,
                         frames: int, time_info, status):
        fc = self._frame_counter + 1
        self._frame_counter = fc

        # Reset drop window every 1000 frames
        if fc % 1000 == 0:
            self._drop_window = 0
            self._metrics.dropped_frames = 0

        # Processing guard: if previous callback is still running,
        # write a silent/decaying buffer instead of raw audio to avoid
        # jarring processed↔raw alternation
        if self._processing:
            if self._silence_buf is None or self._silence_buf.shape != outdata.shape:
                self._silence_buf = np.zeros_like(outdata)
            # Write decaying previous output mixed with silence
            outdata[:] = outdata * 0.3 if hasattr(outdata, '__getitem__') else 0.0
            self._metrics.dropped_frames += 1
            self._drop_window += 1
            return

        self._processing = True

        if status:
            self._metrics.dropped_frames += 1

        start = time.perf_counter()

        # Use pre-allocated work buffer to avoid allocation in callback
        if self._work_buf is None or self._work_buf.shape != indata.shape:
            self._work_buf = np.empty_like(indata)
        np.copyto(self._work_buf, indata)
        processed = self._process(self._work_buf)
        if processed.shape[1] != outdata.shape[1]:
            processed = self._match_channels(processed, outdata.shape[1])
        outdata[:] = processed

        if fc % 5 == 0:
            self._metrics.input_level = self._fast_level(indata)
            self._metrics.output_level = self._fast_level(processed)
        self._metrics.latency_ms = max(0.0, (time.perf_counter() - start) * 1000)

        self._processing = False

    # --- Input-only callback ---

    def _input_callback(self, indata: np.ndarray, frames: int, time_info, status):
        if not self._running:
            return

        fc = self._frame_counter + 1
        self._frame_counter = fc

        if fc % 1000 == 0:
            self._drop_window = 0
            self._metrics.dropped_frames = 0

        if self._processing:
            self._metrics.dropped_frames += 1
            return

        self._processing = True
        start = time.perf_counter()

        if self._work_buf is None or self._work_buf.shape != indata.shape:
            self._work_buf = np.empty_like(indata)
        np.copyto(self._work_buf, indata)
        processed = self._process(self._work_buf)

        if self._output_stream:
            try:
                out_ch = getattr(self._output_stream, 'channels', 2)
                if processed.shape[1] != out_ch:
                    processed = self._match_channels(processed, out_ch)
                self._output_stream.write(processed)
            except Exception:
                self._metrics.dropped_frames += 1

        if fc % 5 == 0:
            self._metrics.input_level = self._fast_level(indata)
            self._metrics.output_level = self._fast_level(processed)
        self._metrics.latency_ms = max(0.0, (time.perf_counter() - start) * 1000)

        self._processing = False

    # --- Fast level (avoids sqrt for RMS) ---

    def _fast_level(self, data: np.ndarray) -> AudioLevel:
        level = AudioLevel()
        if data.size == 0:
            return level
        peak = float(np.abs(data).max())
        level.peak = peak
        if data.ndim > 1 and data.shape[1] > 0:
            level.left = float(np.abs(data[:, 0]).max())
            level.right = float(np.abs(data[:, -1]).max()) if data.shape[1] > 1 else level.left
        level.is_clipping = peak > 0.95
        return level

    def _notify_metrics(self):
        m = self._metrics
        for listener in self._metrics_listeners:
            try:
                listener(m)
            except Exception:
                pass

    def shutdown(self):
        self.stop()
        self._metrics_listeners.clear()
