import threading
import numpy as np
from typing import Dict, List, Optional, Callable
from audio_engine.models.processing_node import ProcessingNode, NodeConnection, NodeType
from audio_engine.models.blueprint import Blueprint
from audio_engine.effects.base import EffectNode
from audio_engine.effects import EFFECT_REGISTRY


def _boost_priority():
    """Set the calling thread to high priority on Windows."""
    try:
        import ctypes
        win32 = ctypes.windll.kernel32
        win32.SetThreadPriority(win32.GetCurrentThread(), 1)  # THREAD_PRIORITY_ABOVE_NORMAL
    except Exception:
        pass


class AudioPipeline:
    """Audio processing pipeline with thread-safe blueprint swapping.

    The `process()` method (called from the audio callback thread) uses
    non-blocking lock acquisition. If a blueprint swap is in progress
    it safely returns unprocessed audio instead of reading partial state.
    """

    def __init__(self):
        self._lock = threading.Lock()
        self._effect_instances: Dict[str, EffectNode] = {}
        self._bp_nodes: Dict[str, ProcessingNode] = {}
        self._execution_order: List[str] = []
        self._active_ids: List[str] = []
        self._connections: List[NodeConnection] = []
        self._sample_rate: int = 48000
        self._buffer_size: int = 512
        self._processing_hooks: list[Callable] = []
        self._prealloc: Optional[np.ndarray] = None  # pre-allocated output buffer
        _boost_priority()

    def on_process(self, hook: Callable[[np.ndarray], None]):
        self._processing_hooks.append(hook)

    def set_blueprint(self, blueprint: Blueprint):
        """Swap the active blueprint. Thread-safe — blocks until
        any in-flight callback completes, then atomically replaces state."""
        with self._lock:
            self._swap(blueprint)

    def _swap(self, blueprint: Blueprint):
        """Internal: perform the swap while holding the lock."""
        self._bp_nodes = {n.id: n for n in blueprint.nodes}
        self._connections = list(blueprint.connections)

        new_effects: Dict[str, EffectNode] = {}
        for bp_node in blueprint.nodes:
            factory = EFFECT_REGISTRY.get(bp_node.node_type.value)
            if factory is None:
                continue
            effect = factory(bp_node)
            new_effects[bp_node.id] = effect

        new_order = self._resolve_order(blueprint)

        # Atomically swap — all assignments happen while lock is held
        self._effect_instances = new_effects
        self._execution_order = new_order

        # Pre-compute active (non-bypassed, non-IO) effect IDs for fast iteration
        self._active_ids = [
            nid for nid in new_order
            if nid in new_effects
            and not self._bp_nodes.get(nid, ProcessingNode("x", NodeType.INPUT)).bypass
            and self._bp_nodes.get(nid, ProcessingNode("x", NodeType.INPUT)).node_type
            not in (NodeType.INPUT, NodeType.OUTPUT)
        ]

        for node in self._effect_instances.values():
            node.configure(self._sample_rate, self._buffer_size)

    def _resolve_order(self, blueprint: Blueprint) -> List[str]:
        adj: Dict[str, List[str]] = {n.id: [] for n in blueprint.nodes}
        indegree: Dict[str, int] = {n.id: 0 for n in blueprint.nodes}

        for conn in blueprint.connections:
            if conn.source_id in adj and conn.target_id in adj:
                adj[conn.source_id].append(conn.target_id)
                indegree[conn.target_id] = indegree.get(conn.target_id, 0) + 1

        queue = [nid for nid, deg in indegree.items() if deg == 0]
        order = []
        while queue:
            nid = queue.pop(0)
            order.append(nid)
            for neighbor in adj.get(nid, []):
                indegree[neighbor] -= 1
                if indegree[neighbor] == 0:
                    queue.append(neighbor)

        output_nodes = [n for n in order if self._bp_nodes.get(n, ProcessingNode("x", NodeType.OUTPUT)).node_type == NodeType.OUTPUT]
        for on in output_nodes:
            order.remove(on)
            order.append(on)

        return order

    def process(self, audio: np.ndarray) -> np.ndarray:
        """Process audio through the pipeline.

        Uses pre-computed active IDs and non-blocking lock for
        thread-safe, fast processing. Returns unprocessed audio
        if a swap is in progress.
        """
        active = self._active_ids
        if not active:
            return audio

        if not self._lock.acquire(blocking=False):
            return audio
        try:
            # Use pre-allocated buffer if shape matches, else copy
            if self._prealloc is None or self._prealloc.shape != audio.shape:
                self._prealloc = audio.copy()
            else:
                np.copyto(self._prealloc, audio)
            output = self._prealloc

            for nid in active:
                effect = self._effect_instances.get(nid)
                bp_node = self._bp_nodes.get(nid)
                if effect is None or bp_node is None:
                    continue
                try:
                    output = effect.process(output, bp_node.parameters)
                except Exception:
                    pass

            # DC blocker
            output = output - np.mean(output, axis=0) if output.ndim > 1 else output - np.mean(output)
            # Safety limiter — ensures output never exceeds ±1.0 even without a limiter node
            peak = np.abs(output).max()
            if peak > 1.0:
                output = output / peak * 0.99

            for hook in self._processing_hooks:
                try:
                    hook(output)
                except Exception:
                    pass
            return output
        finally:
            self._lock.release()

    def configure(self, sample_rate: int, buffer_size: int):
        self._sample_rate = sample_rate
        self._buffer_size = buffer_size
        for node in self._effect_instances.values():
            node.configure(sample_rate, buffer_size)

    def get_node(self, node_id: str) -> Optional[EffectNode]:
        return self._effect_instances.get(node_id)

    def get_bp_node(self, node_id: str) -> Optional[ProcessingNode]:
        return self._bp_nodes.get(node_id)

    def reset(self):
        for node in self._effect_instances.values():
            node.reset()

    def clear(self):
        self._bp_nodes.clear()
        self._effect_instances.clear()
        self._execution_order.clear()
        self._connections.clear()
