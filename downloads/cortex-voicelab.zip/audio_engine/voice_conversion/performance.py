from dataclasses import dataclass, field
from typing import Optional


@dataclass
class PerformanceSnapshot:
    inference_ms: float = 0.0
    pipeline_ms: float = 0.0
    total_latency_ms: float = 0.0
    gpu_util_pct: float = 0.0
    vram_used_mb: float = 0.0
    vram_total_mb: float = 0.0
    vram_pct: float = 0.0
    provider: str = "CPU"


class PerformanceMonitor:
    """Tracks inference and pipeline performance metrics.

    Supports GPU monitoring via pynvml if available, otherwise
    reports CPU-based metrics.
    """

    def __init__(self):
        self._nvml = None
        self._device_count: int = 0
        self._snapshot = PerformanceSnapshot()
        self._init_nvml()

    def _init_nvml(self):
        try:
            from pynvml import nvmlInit, nvmlDeviceGetCount, nvmlDeviceGetHandleByIndex
            self._nvml = True
            nvmlInit()
            self._device_count = nvmlDeviceGetCount()
        except Exception:
            self._nvml = None
            self._device_count = 0

    @property
    def gpu_available(self) -> bool:
        return self._nvml is not None and self._device_count > 0

    def snapshot(self,
                 inference_ms: float = 0.0,
                 pipeline_ms: float = 0.0,
                 total_latency_ms: float = 0.0,
                 provider: str = "CPU") -> PerformanceSnapshot:
        """Take a performance snapshot."""
        snap = PerformanceSnapshot(
            inference_ms=inference_ms,
            pipeline_ms=pipeline_ms,
            total_latency_ms=total_latency_ms,
            provider=provider,
        )

        if self.gpu_available:
            try:
                from pynvml import nvmlDeviceGetHandleByIndex, nvmlDeviceGetUtilizationRates, nvmlDeviceGetMemoryInfo
                handle = nvmlDeviceGetHandleByIndex(0)
                util = nvmlDeviceGetUtilizationRates(handle)
                mem = nvmlDeviceGetMemoryInfo(handle)
                snap.gpu_util_pct = float(util.gpu)
                snap.vram_used_mb = mem.used / (1024 * 1024)
                snap.vram_total_mb = mem.total / (1024 * 1024)
                snap.vram_pct = (mem.used / mem.total * 100) if mem.total > 0 else 0.0
            except Exception:
                pass

        self._snapshot = snap
        return snap

    @property
    def last(self) -> PerformanceSnapshot:
        return self._snapshot

    def shutdown(self):
        if self._nvml:
            try:
                from pynvml import nvmlShutdown
                nvmlShutdown()
            except Exception:
                pass
