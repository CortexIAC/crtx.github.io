import numpy as np
import time
from typing import Optional, Tuple
from audio_engine.models.audio_device import StreamMetrics


class RVCInference:
    """Wrapper around an ONNX session for RVC voice conversion inference.

    Architecture-ready: just plug in a different model session and
    the rest of the pipeline stays the same.
    """

    def __init__(self):
        self._session = None
        self._hop_size: int = 320
        self._sr: int = 48000
        self._inference_time_ms: float = 0.0
        self._enabled: bool = True
        self._model_name: str = ""

    @property
    def enabled(self) -> bool:
        return self._enabled

    @enabled.setter
    def enabled(self, val: bool):
        self._enabled = val

    @property
    def inference_time_ms(self) -> float:
        return self._inference_time_ms

    @property
    def model_name(self) -> str:
        return self._model_name

    def set_session(self, session, model_name: str = "", hop_size: int = 320, sr: int = 48000):
        self._session = session
        self._model_name = model_name
        self._hop_size = hop_size
        self._sr = sr

    def process(self, audio: np.ndarray) -> np.ndarray:
        """Process audio through RVC model.

        Args:
            audio: float32 numpy array of shape (samples, channels)

        Returns:
            Processed audio (same shape, or mono expanded to match input)
        """
        if self._session is None or not self._enabled:
            return audio

        start = time.perf_counter()

        try:
            # Convert to mono for inference
            if audio.ndim > 1 and audio.shape[1] > 1:
                mono = np.mean(audio, axis=1)
            else:
                mono = audio.flatten()

            # Normalise
            peak = np.abs(mono).max()
            if peak > 0:
                mono = mono / peak * 0.95

            # Pad to hop-size multiple
            hop = self._hop_size
            pad_len = (hop - len(mono) % hop) % hop
            if pad_len > 0:
                mono = np.pad(mono, (0, pad_len))

            # ONNX inference
            input_name = self._session.get_inputs()[0].name
            feats = mono.astype(np.float32).reshape(1, 1, -1)

            outputs = self._session.run(None, {input_name: feats})
            out = outputs[0]

            # Reshape back
            if out.ndim == 3:
                out = out[0, 0, :] if out.shape[1] == 1 else out[0].mean(axis=0)
            elif out.ndim == 2:
                out = out[0]

            # Trim padding
            out = out[:audio.shape[0]]

            # Restore channels
            if audio.ndim > 1 and audio.shape[1] > 1:
                result = np.column_stack([out] * audio.shape[1])
            else:
                result = out.reshape(-1, 1) if audio.ndim > 1 else out

            # Normalise output
            peak_out = np.abs(result).max()
            if peak_out > 1.0:
                result = result / peak_out * 0.95

            self._inference_time_ms = (time.perf_counter() - start) * 1000

            return result.astype(np.float32)

        except Exception:
            self._inference_time_ms = (time.perf_counter() - start) * 1000
            return audio
