import os
import json
from dataclasses import dataclass, field
from typing import Optional, List, Callable
from pathlib import Path


@dataclass
class ModelInfo:
    name: str
    path: str
    sr: int = 48000
    hop_size: int = 320
    f0_method: str = "pm"
    is_loaded: bool = False
    file_size_mb: float = 0.0


class ModelManager:
    """Manages RVC ONNX model discovery, loading, and hot-swapping."""

    def __init__(self, models_dir: str = ""):
        self._models_dir = models_dir
        self._models: List[ModelInfo] = []
        self._loaded: Optional[ModelInfo] = None
        self._session = None
        self._on_load: list[Callable] = []
        self._cuda_available: bool = False
        self._cuda_enabled: bool = False
        self._providers: List[str] = []

        self._detect_providers()
        self._scan_models()

    # -- provider detection ------------------------------------------------

    def _detect_providers(self):
        try:
            import onnxruntime as ort
            available = ort.get_available_providers()
            self._providers = available
            self._cuda_available = "CUDAExecutionProvider" in available
        except ImportError:
            self._providers = ["CPUExecutionProvider"]
            self._cuda_available = False

    @property
    def cuda_available(self) -> bool:
        return self._cuda_available

    @property
    def cuda_enabled(self) -> bool:
        return self._cuda_enabled

    @cuda_enabled.setter
    def cuda_enabled(self, enabled: bool):
        self._cuda_enabled = enabled and self._cuda_available
        if self._loaded:
            self.load(self._loaded.name)

    @property
    def provider_names(self) -> List[str]:
        return self._providers

    @property
    def active_provider(self) -> str:
        if self._cuda_enabled:
            return "CUDA"
        return "CPU"

    # -- model discovery --------------------------------------------------

    def set_models_dir(self, path: str):
        self._models_dir = path
        self._scan_models()

    def _scan_models(self):
        self._models.clear()
        if not self._models_dir or not os.path.exists(self._models_dir):
            return

        for f in os.listdir(self._models_dir):
            if f.endswith(".onnx"):
                fpath = os.path.join(self._models_dir, f)
                size = os.path.getsize(fpath) / (1024 * 1024)
                name = f[:-5]
                info = ModelInfo(name=name, path=fpath, file_size_mb=round(size, 1))
                self._models.append(info)

        # Also look for model configs (index.json)
        index_path = os.path.join(self._models_dir, "index.json")
        if os.path.exists(index_path):
            try:
                with open(index_path) as fp:
                    for item in json.load(fp):
                        existing = [m for m in self._models if m.name == item.get("name")]
                        if existing:
                            for k, v in item.items():
                                if k != "name" and hasattr(existing[0], k):
                                    setattr(existing[0], k, v)
            except Exception:
                pass

    @property
    def models(self) -> List[ModelInfo]:
        return self._models

    @property
    def loaded_model(self) -> Optional[ModelInfo]:
        return self._loaded

    @property
    def session(self):
        return self._session

    # -- model loading ----------------------------------------------------

    def on_load(self, callback: Callable):
        self._on_load.append(callback)

    def load(self, model_name: str) -> bool:
        """Load a model by name. Returns True if successful."""
        model = next((m for m in self._models if m.name == model_name), None)
        if model is None:
            return False

        try:
            import onnxruntime as ort

            providers = ["CUDAExecutionProvider", "CPUExecutionProvider"] if self._cuda_enabled else ["CPUExecutionProvider"]
            opts = ort.SessionOptions()
            opts.graph_optimization_level = ort.GraphOptimizationLevel.ORT_ENABLE_ALL
            opts.intra_op_num_threads = 2
            opts.inter_op_num_threads = 2

            self._session = ort.InferenceSession(model.path, opts, providers=providers)
            self._loaded = model
            model.is_loaded = True

            for cb in self._on_load:
                try:
                    cb(model)
                except Exception:
                    pass
            return True

        except Exception as e:
            self._session = None
            self._loaded = None
            raise RuntimeError(f"Failed to load model '{model_name}': {e}")

    def unload(self):
        self._session = None
        if self._loaded:
            self._loaded.is_loaded = False
            self._loaded = None

    # -- public query -----------------------------------------------------

    def has_models(self) -> bool:
        return len(self._models) > 0

    def model_names(self) -> List[str]:
        return [m.name for m in self._models]
