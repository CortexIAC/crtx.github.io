import numpy as np
from typing import Dict
from audio_engine.effects.base import EffectNode
from audio_engine.models.processing_node import NodeParameter


# ── Numba JIT comb filter (compiled to native code, no Python loop overhead) ──

_HAS_NUMBA = False
_jit_comb = None

try:
    from numba import njit, prange

    @njit(cache=True, fastmath=True)
    def _comb_numba(audio, buffers, indices, feedback, damp):
        """JIT-compiled comb filter loop — runs at native C speed."""
        n = len(audio)
        num = len(buffers)
        out = np.zeros(n, dtype=np.float32)
        for i in range(n):
            wl, wr = 0.0, 0.0
            for j in range(num):
                idx = indices[j]
                buf = buffers[j]
                ds = buf[idx]
                if j & 1:
                    wr += ds
                else:
                    wl += ds
                inp = audio[i]
                comb = inp + ds * feedback
                buf[idx] = comb * (1.0 - damp) + ds * damp
                indices[j] = (idx + 1) % len(buf)
            # Divide by number of pairs
            np_ = num // 2 if num >= 2 else 1
            out[i] = (wl / np_) * 0.5 + (wr / np_) * 0.5
        return out

    _HAS_NUMBA = True
except ImportError:
    pass


class ReverbEffect(EffectNode):
    """Reverb — Numba JIT comb filters for native speed, pure Python fallback."""

    def __init__(self, node):
        super().__init__(node)
        self._buffers = []
        self._indices = []

    def configure(self, sample_rate: int, buffer_size: int):
        super().configure(sample_rate, buffer_size)
        delays_s = [0.03, 0.037, 0.041, 0.047]
        self._buffers = []
        self._indices = []
        for d_s in delays_s:
            self._buffers.append(np.zeros(int(d_s * sample_rate) + 1, dtype=np.float32))
            self._indices.append(0)
        # Warm up Numba JIT on first configure
        if _HAS_NUMBA:
            test = np.zeros(64, dtype=np.float32)
            _comb_numba(test, self._buffers, self._indices, 0.5, 0.5)
            self._indices = [0] * len(self._indices)
            for b in self._buffers:
                b.fill(0.0)

    def process(self, audio: np.ndarray, params: Dict[str, NodeParameter]) -> np.ndarray:
        wet = params.get("wet_mix", NodeParameter("wet_mix", 0.25)).value
        if wet <= 0:
            return audio

        room_size = params.get("room_size", NodeParameter("room_size", 0.5)).value
        damping = params.get("damping", NodeParameter("damping", 0.5)).value
        dry = params.get("dry_mix", NodeParameter("dry_mix", 0.7)).value
        width = params.get("width", NodeParameter("width", 0.5)).value
        feedback = 0.3 + room_size * 0.6
        damp = 0.1 + damping * 0.8
        output = np.zeros_like(audio)

        for ch in range(min(audio.shape[1], 2)):
            channel = audio[:, ch]

            if _HAS_NUMBA:
                wet_sum = _comb_numba(channel, self._buffers, self._indices, feedback, damp)
            else:
                wet_sum = self._comb_python(channel, feedback, damp)

            if audio.shape[1] > 1:
                if ch == 0:
                    output[:, ch] = channel * dry + wet_sum * wet * (1 + width)
                else:
                    output[:, ch] = channel * dry + wet_sum * wet * (1 - width)
            else:
                output[:, ch] = channel * dry + wet_sum * wet

        return np.clip(output, -1.0, 1.0)

    def _comb_python(self, audio, feedback, damp):
        """Pure Python comb filter fallback."""
        n = len(audio)
        num = len(self._buffers)
        out = np.zeros(n, dtype=np.float32)
        for i in range(n):
            wl, wr = 0.0, 0.0
            for j in range(num):
                idx = self._indices[j]
                ds = self._buffers[j][idx]
                if j & 1:
                    wr += ds
                else:
                    wl += ds
                inp = audio[i]
                comb = inp + ds * feedback
                self._buffers[j][idx] = comb * (1.0 - damp) + ds * damp
                self._indices[j] = (idx + 1) % len(self._buffers[j])
            np_ = num // 2 if num >= 2 else 1
            out[i] = (wl / np_) * 0.5 + (wr / np_) * 0.5
        return out

    def reset(self):
        for b in self._buffers:
            b.fill(0.0)
        self._indices = [0] * len(self._indices)
