import numpy as np
from typing import Dict
from audio_engine.effects.base import EffectNode
from audio_engine.models.processing_node import NodeParameter


class NoiseReductionEffect(EffectNode):
    def __init__(self, node):
        super().__init__(node)
        self._noise_profile = np.zeros(256)

    def process(self, audio: np.ndarray, params: Dict[str, NodeParameter]) -> np.ndarray:
        strength = params.get("strength", NodeParameter("strength", 0.5)).value
        if strength <= 0:
            return audio
        floor = params.get("floor", NodeParameter("floor", 0.01)).value
        output = np.zeros_like(audio)

        for ch in range(min(audio.shape[1], 2)):
            channel = audio[:, ch]
            n = len(channel)
            fft_size = 256
            hop = fft_size // 4
            window = np.hanning(fft_size)

            for i in range(0, n - fft_size, hop):
                block = channel[i:i + fft_size] * window
                spec = np.fft.rfft(block)
                mag = np.abs(spec)
                phase = np.angle(spec)

                profile_len = min(len(self._noise_profile), len(mag))
                mask = np.maximum(1.0 - strength * (self._noise_profile[:profile_len] / (mag[:profile_len] + 1e-10)), floor)
                mag = mag * mask

                self._noise_profile = 0.99 * self._noise_profile + 0.01 * np.pad(mag, (0, max(0, len(self._noise_profile) - len(mag))))[:len(self._noise_profile)]

                spec = mag * np.exp(1j * phase)
                block_out = np.fft.irfft(spec)
                end = min(i + fft_size, n)
                output[i:end, ch] += block_out[:end - i]

        return np.clip(output, -1.0, 1.0)

    def reset(self):
        self._noise_profile = np.zeros(256)
