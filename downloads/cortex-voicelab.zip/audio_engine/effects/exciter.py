import numpy as np
from typing import Dict
from audio_engine.effects.base import EffectNode
from audio_engine.models.processing_node import NodeParameter


class ExciterEffect(EffectNode):
    """Voice exciter — generates subtle even-order harmonics for presence.

    Adds clarity and "air" without harshness by mixing a soft-clipped,
    high-pass-filtered copy back into the dry signal.

    """
    def __init__(self, node):
        super().__init__(node)
        self._hp_state = np.zeros(4)

    def process(self, audio: np.ndarray, params: Dict[str, NodeParameter]) -> np.ndarray:
        amount = params.get("amount", NodeParameter("amount", 0.3)).value
        tone = params.get("tone", NodeParameter("tone", 0.5)).value
        if amount <= 0:
            return audio

        # High-pass at ~2kHz for the exciter band
        from scipy import signal as sig
        sos = sig.butter(2, 2000.0 / (self._sample_rate / 2), btype='high', output='sos')

        output = np.zeros_like(audio)
        for ch in range(min(audio.shape[1], 2)):
            channel = audio[:, ch]

            # Extract high-frequency content
            high, self._hp_state = sig.sosfilt(sos, channel, zi=self._hp_state)

            bias = tone * 0.3
            # Soft clip to generate even-order harmonics
            harmonics = np.tanh((high + bias) * 3.0) * 0.5

            # Blend: dry + harmonics * amount
            output[:, ch] = channel + harmonics * amount

        return np.clip(output, -1.0, 1.0)

    def reset(self):
        self._hp_state.fill(0.0)
