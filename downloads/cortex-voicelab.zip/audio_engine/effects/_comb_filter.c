/* Comb filter — compiled to native code for zero-overhead DSP.
   Compile: gcc -shared -o _comb_filter.dll _comb_filter.c -O3 -ffast-math
*/

#include <stdint.h>
#include <stdlib.h>
#include <math.h>

/* Multi-channel comb filter for reverb.
   processes 'frames' samples across 'num_combs' comb filters in-place.

   Each comb: out[n] = in[n] + feedback * delay_buffer[idx]
              delay_buffer[idx] = out[n] * (1-damp) + delay_buffer[idx] * damp
              idx = (idx + 1) % delay_len
*/
__declspec(dllexport) void comb_filter_process(
    float* audio,           /* in/out: audio buffer, shape (frames, channels) */
    int frames,
    int channels,
    float** delay_bufs,     /* array of num_combs delay buffers */
    int* delay_lens,        /* array of num_combs delay lengths */
    int* indices,           /* array of num_combs read indices (in/out) */
    int num_combs,
    float feedback,
    float damp,
    float wet_mix,
    float dry_mix,
    float width
) {
    int i, j, ch, idx;
    float ds, inp, comb, wl, wr, npairs;
    float* buf;

    for (ch = 0; ch < channels && ch < 2; ch++) {
        for (i = 0; i < frames; i++) {
            wl = 0.0f;
            wr = 0.0f;
            inp = audio[i * channels + ch];

            for (j = 0; j < num_combs; j++) {
                idx = indices[j];
                buf = delay_bufs[j];
                ds = buf[idx];

                if (j & 1)
                    wr += ds;
                else
                    wl += ds;

                comb = inp + ds * feedback;
                buf[idx] = comb * (1.0f - damp) + ds * damp;
                indices[j] = (idx + 1) % delay_lens[j];
            }

            npairs = (float)(num_combs / 2);
            if (npairs < 1.0f) npairs = 1.0f;

            if (ch == 0 && channels > 1)
                audio[i * channels + ch] = inp * dry_mix + (wl / npairs) * wet_mix * (1.0f + width);
            else if (ch == 1)
                audio[i * channels + ch] = inp * dry_mix + (wr / npairs) * wet_mix * (1.0f - width);
            else
                audio[i * channels + ch] = inp * dry_mix + ((wl + wr) / npairs) * 0.5f * wet_mix;
        }
    }
}
