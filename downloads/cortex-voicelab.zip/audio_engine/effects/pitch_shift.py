import numpy as np
from typing import Dict
from scipy import signal as sig, fft as sfft
from audio_engine.effects.base import EffectNode
from audio_engine.models.processing_node import NodeParameter


class PitchShiftEffect(EffectNode):
    """Pitch shift — phase vocoder with anti-aliasing filter.

    Uses FFT overlap-add for time-stretching + resampling, followed
    by a low-pass anti-aliasing filter to prevent foldback artifacts.
    """

    def __init__(self, node):
        super().__init__(node)
        self._fft_size = 1024
        self._hop = 256
        self._window = np.hanning(1024).astype(np.float32)
        self._buf = np.zeros(8192, dtype=np.float32)
        self._wpos = 0
        self._init = False
        self._aa_state = np.zeros((2, 4))  # anti-alias filter state per channel

    def configure(self, sample_rate: int, buffer_size: int):
        super().configure(sample_rate, buffer_size)
        # Adaptive quality: larger FFT + more overlap for high-res, 
        # smaller FFT + less overlap for low-latency
        if buffer_size <= 128:
            self._fft_size = 512
            self._hop = 128  # 75% overlap
        elif buffer_size <= 256:
            self._fft_size = 1024
            self._hop = 256  # 75% overlap
        else:
            self._fft_size = 1024
            self._hop = 256  # 75% overlap
        self._window = np.hanning(self._fft_size).astype(np.float32)
        max_delay = int(0.3 * sample_rate)
        self._buf = np.zeros(max(8192, max_delay), dtype=np.float32)
        self._wpos = 0
        self._init = False
        self._aa_state = np.zeros((2, 4))

    def process(self, audio: np.ndarray, params: Dict[str, NodeParameter]) -> np.ndarray:
        semitones = params.get("semitones", NodeParameter("semitones", 0.0)).value
        mix = params.get("mix", NodeParameter("mix", 0.8)).value
        quality = params.get("formant", NodeParameter("formant", 1.0)).value

        if abs(semitones) < 0.1 or mix <= 0:
            return audio

        ratio = 2.0 ** (semitones / 12.0)
        output = np.zeros_like(audio)

        for ch in range(min(audio.shape[1], 2)):
            shifted = self._shift_channel(audio[:, ch], ratio, quality)
            output[:, ch] = audio[:, ch] * (1 - mix) + shifted[:len(audio)] * mix

        return np.clip(output, -1.0, 1.0)

    def _shift_channel(self, audio: np.ndarray, ratio: float, quality: float) -> np.ndarray:
        n = len(audio)
        fft_size = self._fft_size
        hop = self._hop
        hop_out = max(1, int(round(hop / ratio)))

        self._buf = np.roll(self._buf, -n)
        self._buf[-n:] = audio

        out_len = int(n / ratio) + fft_size
        out = np.zeros(out_len, dtype=np.float32)

        out_pos = 0
        read_pos = max(0, n - self._wpos)

        while read_pos + fft_size <= len(self._buf) and out_pos + fft_size < out_len:
            frame = self._buf[read_pos:read_pos + fft_size] * self._window
            spec = sfft.rfft(frame)
            mag = np.abs(spec)
            phase = np.angle(spec)

            if self._init:
                delta = phase - self._prev_phase
                delta -= 2 * np.pi * np.round(delta / (2 * np.pi))
                adjusted = self._prev_phase + delta * ratio
                phase = adjusted
                self._prev_phase = adjusted
            else:
                self._prev_phase = phase.copy()
                self._init = True

            if quality < 1.0:
                mag = np.convolve(mag, [0.25, 0.5, 0.25], mode='same')

            spec = mag * np.exp(1j * phase)
            frame_out = sfft.irfft(spec)[:fft_size] * self._window
            end = min(out_pos + fft_size, out_len)
            out[out_pos:end] += frame_out[:end - out_pos]
            read_pos += hop
            out_pos += hop_out

        self._wpos = (self._wpos + n) % len(self._buf)
        gain = fft_size / (hop_out * 4 + 1)
        result = (out / gain)[:n]

        # Anti-aliasing filter — low-pass at min(sr/2, sr/(2*ratio))
        if ratio > 1.0:  # pitch up → need to filter
            cutoff = min(self._sample_rate / 2.0, self._sample_rate / (2.0 * ratio))
            sos = sig.butter(4, cutoff / (self._sample_rate / 2), btype='low', output='sos')
            result = sig.sosfilt(sos, result)

        return result

    def reset(self):
        self._buf.fill(0.0)
        self._wpos = 0
        self._init = False
        self._aa_state.fill(0.0)
