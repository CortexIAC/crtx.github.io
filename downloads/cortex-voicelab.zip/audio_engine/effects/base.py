import numpy as np
from abc import ABC, abstractmethod
from typing import Dict, Optional
from audio_engine.models.processing_node import ProcessingNode, NodeParameter


class EffectNode(ABC):
    def __init__(self, node: ProcessingNode):
        self.node_id = node.id
        self.node_type = node.node_type
        self.bypass = node.bypass
        self._sample_rate: int = 48000
        self._buffer_size: int = 512

    def configure(self, sample_rate: int, buffer_size: int):
        self._sample_rate = sample_rate
        self._buffer_size = buffer_size

    @abstractmethod
    def process(self, audio: np.ndarray, params: Dict[str, NodeParameter]) -> np.ndarray:
        pass

    def reset(self):
        pass


class PassthroughNode(EffectNode):
    def process(self, audio: np.ndarray, params: Dict[str, NodeParameter]) -> np.ndarray:
        return audio
