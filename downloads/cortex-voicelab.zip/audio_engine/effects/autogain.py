import numpy as np
from typing import Dict
from audio_engine.effects.base import EffectNode
from audio_engine.models.processing_node import NodeParameter


class AutoGainEffect(EffectNode):
    """Automatic gain control — maintains consistent output level.

    Measures RMS over a sliding window and applies gentle makeup gain
    to reach the target level. Prevents volume jumps between profiles.
    """

    def __init__(self, node):
        super().__init__(node)
        self._rms = 0.0
        self._gain = 1.0

    def process(self, audio: np.ndarray, params: Dict[str, NodeParameter]) -> np.ndarray:
        target = params.get("target", NodeParameter("target", -16.0)).value
        attack = params.get("attack", NodeParameter("attack", 0.01)).value
        release = params.get("release", NodeParameter("release", 0.5)).value

        attack_c = np.exp(-1.0 / (self._sample_rate * attack + 1e-10))
        release_c = np.exp(-1.0 / (self._sample_rate * release + 1e-10))

        # Block RMS
        block_rms = np.sqrt(np.mean(audio ** 2))
        if block_rms.ndim > 0:
            block_rms = float(np.max(block_rms))

        # Smooth RMS
        if block_rms > self._rms:
            self._rms += (block_rms - self._rms) * (1 - attack_c)
        else:
            self._rms += (block_rms - self._rms) * (1 - release_c)

        # Target gain: current RMS should reach target dB
        if self._rms > 1e-10:
            current_db = 20.0 * np.log10(self._rms)
            makeup = target - current_db
            target_gain = 10.0 ** (makeup / 20.0)
            target_gain = max(0.1, min(10.0, target_gain))
        else:
            target_gain = 1.0

        # Smooth gain application
        n = len(audio)
        gs = self._gain
        ge = gs + (target_gain - gs) * (1 - release_c) if target_gain > gs else gs + (target_gain - gs) * (1 - attack_c)

        gains = np.linspace(gs, ge, n).astype(np.float32)
        if audio.ndim > 1:
            gains = gains[:, None]

        self._gain = ge
        return audio * gains

    def reset(self):
        self._rms = 0.0
        self._gain = 1.0
