import numpy as np
from typing import Dict, Optional
from audio_engine.effects.base import EffectNode
from audio_engine.models.processing_node import NodeParameter
from audio_engine.voice_conversion.rvc_inference import RVCInference
from audio_engine.voice_conversion.performance import PerformanceMonitor


class VoiceConversionEffect(EffectNode):
    """VOICE_CONVERSION node — wraps RVC ONNX inference.

    Internally uses RVCInference which abstracts the model session.
    Future: swap RVCInference for any other model wrapper.
    """

    def __init__(self, node):
        super().__init__(node)
        self._inference = RVCInference()
        self._perf = PerformanceMonitor()
        self._model_loaded = False
        self._noise_gate_active = True

        # Register perf on the node so the UI can read it
        node._perf = self._perf

    @property
    def inference(self) -> RVCInference:
        return self._inference

    @property
    def perf_monitor(self) -> PerformanceMonitor:
        return self._perf

    def set_model_session(self, session, model_name: str = "", hop_size: int = 320, sr: int = 48000):
        self._inference.set_session(session, model_name, hop_size, sr)
        self._model_loaded = session is not None

    def process(self, audio: np.ndarray, params: Dict[str, NodeParameter]) -> np.ndarray:
        import time
        start = time.perf_counter()

        # Noise gate pre-filter (lightweight, always on)
        noise_gate = params.get("noise_gate", NodeParameter("noise_gate", 1.0)).value
        if noise_gate > 0:
            threshold = 0.01
            rms = np.sqrt(np.mean(audio ** 2))
            if rms < threshold:
                return audio * 0

        # Voice conversion
        vc_mix = params.get("mix", NodeParameter("mix", 1.0)).value
        if self._model_loaded and vc_mix > 0:
            converted = self._inference.process(audio)
            audio = audio * (1 - vc_mix) + converted * vc_mix

        # Pitch shift (integrated, lightweight)
        semitones = params.get("semitones", NodeParameter("semitones", 0.0)).value
        if abs(semitones) > 0.1:
            ratio = 2.0 ** (semitones / 12.0)
            n = len(audio)
            indices = (np.arange(n) * ratio) % n
            audio = audio[indices.astype(int)]

        elapsed = (time.perf_counter() - start) * 1000
        self._perf.snapshot(
            inference_ms=self._inference.inference_time_ms,
            pipeline_ms=elapsed,
            total_latency_ms=elapsed + self._inference.inference_time_ms,
            provider="CUDA" if self._inference._session and "CUDA" in str(type(self._inference._session)) else "CPU",
        )

        return np.clip(audio, -1.0, 1.0)

    def reset(self):
        pass
