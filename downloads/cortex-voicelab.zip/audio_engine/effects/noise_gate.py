import numpy as np
from typing import Dict
from audio_engine.effects.base import EffectNode
from audio_engine.models.processing_node import NodeParameter


class NoiseGateEffect(EffectNode):
    """Adaptive noise gate — automatically tracks noise floor and sets
    threshold N dB above ambient. Eliminates manual tuning."""

    def __init__(self, node):
        super().__init__(node)
        self._rms = 0.0
        self._gain = 1.0
        self._floor = 0.0        # tracked noise floor
        self._floor_frames = 0   # samples since last floor update
        self._open = True

    def _update_floor(self, rms_val: float, sample: int, rate: int):
        """Track the noise floor during quiet periods."""
        # Exponential moving average of minimum RMS
        if rms_val < self._floor * 1.5:
            self._floor += (rms_val - self._floor) * 0.01
        elif self._floor_frames > int(0.5 * rate):
            # No quiet sample in 0.5s — floor might be stale, let it rise slowly
            self._floor += (rms_val - self._floor) * 0.0001

        if rms_val < self._floor * 1.2:
            self._floor_frames = 0
        else:
            self._floor_frames += sample

    def process(self, audio: np.ndarray, params: Dict[str, NodeParameter]) -> np.ndarray:
        ratio = params.get("ratio", NodeParameter("ratio", 3.0)).value
        attack = params.get("attack", NodeParameter("attack", 0.002)).value
        release = params.get("release", NodeParameter("release", 0.1)).value
        knee = params.get("knee", NodeParameter("knee", 6.0)).value
        floor_offset = params.get("floor_offset", NodeParameter("floor_offset", 6.0)).value

        attack_c = np.exp(-1.0 / (self._sample_rate * attack + 1e-10))
        release_c = np.exp(-1.0 / (self._sample_rate * release + 1e-10))

        # Block RMS
        block_rms = np.sqrt(np.mean(audio ** 2, axis=0))
        if block_rms.ndim == 0:
            block_rms = np.array([block_rms])
        rms_val = float(np.max(block_rms))

        # Track noise floor and set adaptive threshold
        self._update_floor(rms_val, len(audio), self._sample_rate)
        threshold = 20.0 * np.log10(max(self._floor, 1e-10)) + floor_offset
        th = threshold

        # Smooth RMS
        if rms_val > self._rms:
            self._rms += (rms_val - self._rms) * (1 - attack_c)
        else:
            self._rms += (rms_val - self._rms) * (1 - release_c)

        level_db = 20.0 * np.log10(max(self._rms, 1e-10))

        # Hysteresis
        open_th = th + 3.0
        close_th = th - 3.0
        if self._open:
            if level_db < close_th:
                self._open = False
        else:
            if level_db > open_th:
                self._open = True

        # Gain computer
        if not self._open:
            gain_db = (level_db - th) * (ratio - 1.0) if level_db < th else 0.0
        else:
            if level_db > th + knee / 2:
                gain_db = 0.0
            elif level_db > th - knee / 2:
                x = (level_db - th + knee / 2) / knee
                gain_db = -(x ** 2) * (ratio - 1.0) * knee * 0.5
            else:
                gain_db = (level_db - th) * (ratio - 1.0)

        target = 10.0 ** (gain_db / 20.0)
        target = max(target, 0.0)

        # Per-sample gain ramp
        n = len(audio)
        gs = self._gain
        ge = gs + (target - gs) * (1 - release_c) if target > gs else gs + (target - gs) * (1 - attack_c)
        gains = np.linspace(gs, ge, n).astype(np.float32)
        if audio.ndim > 1:
            gains = gains[:, None]

        self._gain = ge
        return audio * gains

    def reset(self):
        self._rms = 0.0
        self._gain = 1.0
        self._floor = 0.0
        self._floor_frames = 0
        self._open = True
