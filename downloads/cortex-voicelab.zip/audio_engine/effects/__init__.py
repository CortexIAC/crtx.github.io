from audio_engine.effects.base import EffectNode, PassthroughNode
from audio_engine.effects.noise_gate import NoiseGateEffect
from audio_engine.effects.noise_reduction import NoiseReductionEffect
from audio_engine.effects.equalizer import EqualizerEffect
from audio_engine.effects.compressor import CompressorEffect
from audio_engine.effects.pitch_shift import PitchShiftEffect
from audio_engine.effects.reverb import ReverbEffect
from audio_engine.effects.delay import DelayEffect
from audio_engine.effects.radio import RadioEffect
from audio_engine.effects.voice_conversion import VoiceConversionEffect
from audio_engine.effects.limiter import LimiterEffect
from audio_engine.effects.deesser import DeEsserEffect
from audio_engine.effects.multiband_comp import MultibandCompressorEffect
from audio_engine.effects.exciter import ExciterEffect
from audio_engine.effects.autogain import AutoGainEffect

__all__ = [
    "EffectNode", "PassthroughNode",
    "NoiseGateEffect", "NoiseReductionEffect", "EqualizerEffect",
    "CompressorEffect", "PitchShiftEffect", "ReverbEffect",
    "DelayEffect", "RadioEffect", "VoiceConversionEffect",
    "LimiterEffect", "DeEsserEffect", "MultibandCompressorEffect",
    "ExciterEffect", "AutoGainEffect",
]

EFFECT_REGISTRY = {
    "input": PassthroughNode,
    "output": PassthroughNode,
    "noise_gate": NoiseGateEffect,
    "noise_reduction": NoiseReductionEffect,
    "equalizer": EqualizerEffect,
    "compressor": CompressorEffect,
    "multiband_comp": MultibandCompressorEffect,
    "pitch_shift": PitchShiftEffect,
    "voice_conversion": VoiceConversionEffect,
    "limiter": LimiterEffect,
    "deesser": DeEsserEffect,
    "exciter": ExciterEffect,
    "autogain": AutoGainEffect,
    "reverb": ReverbEffect,
    "delay": DelayEffect,
    "radio": RadioEffect,
}
