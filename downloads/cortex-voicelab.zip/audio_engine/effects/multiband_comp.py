import numpy as np
from typing import Dict
from scipy import signal as sig
from audio_engine.effects.base import EffectNode
from audio_engine.models.processing_node import NodeParameter


class MultibandCompressorEffect(EffectNode):
    """3-band compressor with Linkwitz-Riley crossover filters.

    Splits audio into low (0-250Hz), mid (250-4000Hz), high (4000Hz+),
    compresses each band independently, and sums them back.

    Prevents low-frequency plosives from pumping the entire signal.
    """

    def __init__(self, node):
        super().__init__(node)
        self._sos_lp = None
        self._sos_hp = None
        self._state_low = np.zeros((2, 2))
        self._state_mid = np.zeros((4, 2))
        self._state_high = np.zeros((2, 2))
        self._env_low = 0.0
        self._env_mid = 0.0
        self._env_high = 0.0
        self._gain_low = 1.0
        self._gain_mid = 1.0
        self._gain_high = 1.0

    def configure(self, sample_rate: int, buffer_size: int):
        super().configure(sample_rate, buffer_size)
        # Linkwitz-Riley 24dB/oct crossover at 250Hz and 4000Hz
        self._sos_lp = sig.butter(4, 250.0 / (sample_rate / 2), btype='low', output='sos')
        self._sos_hp = sig.butter(4, 4000.0 / (sample_rate / 2), btype='high', output='sos')
        self._state_low = np.zeros((2, 2))
        self._state_mid = np.zeros((4, 2))
        self._state_high = np.zeros((2, 2))

    def _compress_band(self, audio, threshold, ratio, attack, release, knee, env, gain):
        """Single-band compressor. Same algorithm as CompressorEffect."""
        attack_c = np.exp(-1.0 / (self._sample_rate * attack + 1e-10))
        release_c = np.exp(-1.0 / (self._sample_rate * release + 1e-10))
        n = len(audio)

        rms = float(np.sqrt(np.mean(audio ** 2))) if len(audio) > 0 else 0.0
        if rms > env:
            env += (rms - env) * (1 - attack_c)
        else:
            env += (rms - env) * (1 - release_c)

        level_db = 20.0 * np.log10(max(env, 1e-10))
        th = threshold

        if level_db < th - knee / 2:
            gain_db = 0.0
        elif level_db < th + knee / 2:
            x = (level_db - th + knee / 2) / knee
            gain_db = (1.0 / ratio - 1.0) * (x ** 2) * knee * 0.5
        else:
            gain_db = (level_db - th) * (1.0 / ratio - 1.0)

        target = 10.0 ** (gain_db / 20.0)
        gs = gain
        ge = gs + (target - gs) * (1 - attack_c) if target < gs else gs + (target - gs) * (1 - release_c)
        gains = np.linspace(gs, ge, n).astype(np.float32)
        return audio * gains, env, ge

    def process(self, audio: np.ndarray, params: Dict[str, NodeParameter]) -> np.ndarray:
        threshold = params.get("threshold", NodeParameter("threshold", -25.0)).value
        ratio = params.get("ratio", NodeParameter("ratio", 3.0)).value
        attack = params.get("attack", NodeParameter("attack", 0.002)).value
        release = params.get("release", NodeParameter("release", 0.08)).value
        knee = params.get("knee", NodeParameter("knee", 6.0)).value

        output = np.zeros_like(audio)

        for ch in range(min(audio.shape[1], 2)):
            channel = audio[:, ch]

            # Crossover filters
            # Low band: 0-250Hz (LPF at 250)
            low, self._state_low = sig.sosfilt(self._sos_lp, channel, zi=self._state_low)

            # High band: 4000Hz+ (HPF at 4000)
            high, self._state_high = sig.sosfilt(self._sos_hp, channel, zi=self._state_high)

            # Mid band: 250-4000Hz (all-pass minus low and high)
            mid = channel - low - high

            # Compress each band
            low_out, self._env_low, self._gain_low = self._compress_band(
                low, threshold - 6, min(ratio * 1.5, 10), attack * 0.5, release * 0.5,
                knee, self._env_low, self._gain_low)

            mid_out, self._env_mid, self._gain_mid = self._compress_band(
                mid, threshold, ratio, attack, release,
                knee, self._env_mid, self._gain_mid)

            high_out, self._env_high, self._gain_high = self._compress_band(
                high, threshold - 3, min(ratio * 0.7, 8), attack * 0.3, release * 0.3,
                knee, self._env_high, self._gain_high)

            output[:, ch] = low_out + mid_out + high_out

        return np.clip(output, -1.0, 1.0)

    def reset(self):
        self._state_low.fill(0.0)
        self._state_mid.fill(0.0)
        self._state_high.fill(0.0)
        self._env_low = 0.0
        self._env_mid = 0.0
        self._env_high = 0.0
        self._gain_low = 1.0
        self._gain_mid = 1.0
        self._gain_high = 1.0
