import numpy as np
from typing import Dict
from audio_engine.effects.base import EffectNode
from audio_engine.models.processing_node import NodeParameter


class LimiterEffect(EffectNode):
    """Master output limiter with lookahead and optional soft clip.

    Prevents clipping and can optionally apply a warm saturation curve.
    """

    def __init__(self, node):
        super().__init__(node)
        self._lookahead = np.zeros(128)
        self._gain = 1.0

    def configure(self, sample_rate: int, buffer_size: int):
        super().configure(sample_rate, buffer_size)
        lookahead = min(128, max(16, int(0.003 * sample_rate)))
        self._lookahead = np.zeros(lookahead)
        self._gain = 1.0

    def process(self, audio: np.ndarray, params: Dict[str, NodeParameter]) -> np.ndarray:
        ceiling = params.get("ceiling", NodeParameter("ceiling", -1.0)).value
        release = params.get("release", NodeParameter("release", 0.05)).value
        soft_clip = params.get("soft_clip", NodeParameter("soft_clip", 0.0)).value

        ceiling_lin = 10.0 ** (ceiling / 20.0)
        release_c = np.exp(-1.0 / (self._sample_rate * release + 1e-10))
        output = np.zeros_like(audio)

        for i in range(len(audio)):
            sample = audio[i]
            peak = np.abs(sample).max()

            self._lookahead = np.roll(self._lookahead, -1)
            self._lookahead[-1] = peak
            future = np.max(self._lookahead)

            target = ceiling_lin / (future + 1e-10) if future > ceiling_lin else 1.0

            if target < self._gain:
                self._gain = target
            else:
                self._gain += (target - self._gain) * (1 - release_c)

            output[i] = sample * self._gain

        # Soft clip (warm saturation)
        if soft_clip > 0:
            threshold = 0.5 + (1.0 - soft_clip) * 0.5
            output = np.tanh(output / threshold) * threshold

        return np.clip(output, -1.0, 1.0)

    def reset(self):
        self._lookahead.fill(0.0)
        self._gain = 1.0
