import numpy as np
from typing import Dict
from audio_engine.effects.base import EffectNode
from audio_engine.models.processing_node import NodeParameter


class DelayEffect(EffectNode):
    """Delay — vectorized read/write, early exit on mix=0."""

    def __init__(self, node):
        super().__init__(node)
        self._buffer = np.zeros(0)
        self._write_pos = 0

    def configure(self, sample_rate, buffer_size):
        super().configure(sample_rate, buffer_size)
        self._buffer = np.zeros((int(2.0 * sample_rate), 2))
        self._write_pos = 0

    def process(self, audio: np.ndarray, params: Dict[str, NodeParameter]) -> np.ndarray:
        mix = params.get("mix", NodeParameter("mix", 0.3)).value
        if mix <= 0:
            return audio

        delay_time = params.get("delay_time", NodeParameter("delay_time", 0.25)).value
        feedback = params.get("feedback", NodeParameter("feedback", 0.3)).value
        n = len(audio)
        delay_samples = int(delay_time * self._sample_rate)
        if delay_samples < 1:
            return audio

        buf_len = len(self._buffer)
        read_start = (self._write_pos - delay_samples) % buf_len

        # Vectorized read
        if read_start + n <= buf_len:
            delayed = self._buffer[read_start:read_start + n]
        else:
            part1 = self._buffer[read_start:]
            part2 = self._buffer[:n - len(part1)]
            delayed = np.vstack([part1, part2])

        # Vectorized write
        write_end = self._write_pos + n
        if write_end <= buf_len:
            self._buffer[self._write_pos:write_end] = audio + delayed * feedback
        else:
            p1 = buf_len - self._write_pos
            self._buffer[self._write_pos:] = audio[:p1] + delayed[:p1] * feedback
            self._buffer[:n - p1] = audio[p1:] + delayed[p1:] * feedback

        self._write_pos = (self._write_pos + n) % buf_len

        return audio * (1 - mix) + delayed * mix
