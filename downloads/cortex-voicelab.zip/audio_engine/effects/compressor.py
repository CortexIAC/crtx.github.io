import numpy as np
from typing import Dict
from audio_engine.effects.base import EffectNode
from audio_engine.models.processing_node import NodeParameter


class CompressorEffect(EffectNode):
    """Compressor — block RMS with per-sample gain interpolation."""

    def __init__(self, node):
        super().__init__(node)
        self._rms = 0.0
        self._gain = 1.0

    def process(self, audio: np.ndarray, params: Dict[str, NodeParameter]) -> np.ndarray:
        threshold = params.get("threshold", NodeParameter("threshold", -20.0)).value
        ratio = params.get("ratio", NodeParameter("ratio", 4.0)).value
        attack = params.get("attack", NodeParameter("attack", 0.002)).value
        release = params.get("release", NodeParameter("release", 0.05)).value
        makeup = params.get("makeup_gain", NodeParameter("makeup_gain", 3.0)).value
        knee = params.get("knee", NodeParameter("knee", 6.0)).value

        attack_c = np.exp(-1.0 / (self._sample_rate * attack + 1e-10))
        release_c = np.exp(-1.0 / (self._sample_rate * release + 1e-10))
        fast_c = np.exp(-1.0 / (self._sample_rate * max(release * 0.1, 0.001) + 1e-10))
        makeup_lin = 10.0 ** (makeup / 20.0)

        # Block RMS
        block_rms = np.sqrt(np.mean(audio ** 2, axis=0))
        if block_rms.ndim == 0:
            block_rms = np.array([block_rms])
        rms_val = float(np.max(block_rms))

        # Smooth RMS
        if rms_val > self._rms:
            self._rms += (rms_val - self._rms) * (1 - attack_c)
        else:
            self._rms += (rms_val - self._rms) * (1 - release_c)

        level_db = 20.0 * np.log10(max(self._rms, 1e-10))
        th = threshold

        # Soft-knee gain computer
        if level_db < th - knee / 2:
            gain_db = 0.0
        elif level_db < th + knee / 2:
            x = (level_db - th + knee / 2) / knee
            gain_db = (1.0 / ratio - 1.0) * (x ** 2) * knee * 0.5
        else:
            gain_db = (level_db - th) * (1.0 / ratio - 1.0)

        target = 10.0 ** (gain_db / 20.0)

        # Per-sample gain interpolation
        n = len(audio)
        gs = self._gain
        if target < gs:
            ge = gs + (target - gs) * (1 - attack_c)
        elif target > gs * 1.5:
            ge = gs + (target - gs) * (1 - fast_c)
        else:
            ge = gs + (target - gs) * (1 - release_c)

        gains = np.linspace(gs, ge, n).astype(np.float32)
        if audio.ndim > 1:
            gains = gains[:, None]

        self._gain = ge
        return audio * gains * makeup_lin
