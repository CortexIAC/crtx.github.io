import numpy as np
from typing import Dict
from audio_engine.effects.base import EffectNode
from audio_engine.models.processing_node import NodeParameter


class DeEsserEffect(EffectNode):
    """De-esser — reduces sibilance (excessive 's' and 'sh' sounds).

    Detects energy in the 5-8kHz band and applies gain reduction
    when sibilance exceeds the threshold.
    """

    def __init__(self, node):
        super().__init__(node)
        self._gain = 1.0

    def process(self, audio: np.ndarray, params: Dict[str, NodeParameter]) -> np.ndarray:
        threshold = params.get("threshold", NodeParameter("threshold", -25.0)).value
        ratio = params.get("ratio", NodeParameter("ratio", 5.0)).value
        freq = params.get("frequency", NodeParameter("frequency", 6000.0)).value
        attack = params.get("attack", NodeParameter("attack", 0.001)).value
        release = params.get("release", NodeParameter("release", 0.05)).value

        attack_c = np.exp(-1.0 / (self._sample_rate * attack + 1e-10))
        release_c = np.exp(-1.0 / (self._sample_rate * release + 1e-10))

        output = np.zeros_like(audio)

        for ch in range(min(audio.shape[1], 2)):
            channel = audio[:, ch]
            n = len(channel)

            # Detect sibilance: energy ratio of high band vs full band
            fft_size = 256
            hop = 64
            window = np.hanning(fft_size)
            sib_energy = 0.0

            for i in range(0, n - fft_size, hop):
                block = channel[i:i + fft_size] * window
                spec = np.fft.rfft(block)
                mag = np.abs(spec)
                freqs = np.fft.rfftfreq(fft_size, 1.0 / self._sample_rate)

                # Energy in sibilance band (freq ± 1kHz)
                band = (freqs > freq - 1000) & (freqs < freq + 1000)
                sib = np.sum(mag[band] ** 2)
                total = np.sum(mag ** 2) + 1e-10
                ratio_energy = sib / total

                if ratio_energy > 0.15:  # significant sibilance
                    reduction = (ratio_energy - 0.15) / 0.85 * (ratio - 1)
                    target = 10.0 ** (-min(reduction, 12.0) / 20.0)
                else:
                    target = 1.0

                # Smooth gain
                if target < self._gain:
                    self._gain += (target - self._gain) * (1 - attack_c)
                else:
                    self._gain += (target - self._gain) * (1 - release_c)

                # Apply to block
                end = min(i + fft_size, n)
                output[i:end, ch] = channel[i:end] * self._gain

        return np.clip(output, -1.0, 1.0)

    def reset(self):
        self._gain = 1.0
