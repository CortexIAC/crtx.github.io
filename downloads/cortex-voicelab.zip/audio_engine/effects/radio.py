import numpy as np
from typing import Dict
from scipy import signal
from audio_engine.effects.base import EffectNode
from audio_engine.models.processing_node import NodeParameter


class RadioEffect(EffectNode):
    def process(self, audio: np.ndarray, params: Dict[str, NodeParameter]) -> np.ndarray:
        low_cut = params.get("low_cut", NodeParameter("low_cut", 300.0)).value
        high_cut = params.get("high_cut", NodeParameter("high_cut", 3400.0)).value
        distortion = params.get("distortion", NodeParameter("distortion", 0.2)).value
        noise_floor = params.get("noise_floor", NodeParameter("noise_floor", 0.01)).value

        nyquist = self._sample_rate / 2.0
        sos = signal.butter(4, [low_cut / nyquist, high_cut / nyquist], btype="band", output="sos")
        output = signal.sosfilt(sos, audio, axis=0)

        if distortion > 0:
            gain = 1.0 + distortion * 4.0
            output = np.tanh(output * gain) / np.tanh(gain)

        if noise_floor > 0:
            output = output + np.random.randn(*output.shape) * noise_floor * 0.1

        return np.clip(output, -1.0, 1.0)
