import numpy as np
from typing import Dict
from scipy import signal as sig
from audio_engine.effects.base import EffectNode
from audio_engine.models.processing_node import NodeParameter


class EqualizerEffect(EffectNode):
    """EQ — vectorized via scipy.signal.sosfilt, no per-sample loop."""

    def __init__(self, node):
        super().__init__(node)
        self._sos = None
        self._zi = None

    def configure(self, sample_rate: int, buffer_size: int):
        super().configure(sample_rate, buffer_size)
        self._update_filters(0.0, 0.0, 0.0, 250.0, 4000.0)

    def _update_filters(self, low_gain, mid_gain, high_gain, low_freq, high_freq):
        sections = []

        # Low shelf
        if abs(low_gain) >= 0.5:
            sections.append(self._biquad_shelf(low_gain, low_freq, True))
        # Peak
        if abs(mid_gain) >= 0.5:
            sections.append(self._biquad_peak(mid_gain, 1000.0, 0.7))
        # High shelf
        if abs(high_gain) >= 0.5:
            sections.append(self._biquad_shelf(high_gain, high_freq, False))

        if sections:
            self._sos = np.array(sections)
            n_sections = len(sections)
            self._zi = np.zeros((n_sections, 2))
        else:
            self._sos = None
            self._zi = None

    def process(self, audio: np.ndarray, params: Dict[str, NodeParameter]) -> np.ndarray:
        low_gain = params.get("low_gain", NodeParameter("low_gain", 0.0)).value
        mid_gain = params.get("mid_gain", NodeParameter("mid_gain", 0.0)).value
        high_gain = params.get("high_gain", NodeParameter("high_gain", 0.0)).value

        if abs(low_gain) < 0.5 and abs(mid_gain) < 0.5 and abs(high_gain) < 0.5:
            return audio

        low_freq = params.get("low_freq", NodeParameter("low_freq", 250.0)).value
        high_freq = params.get("high_freq", NodeParameter("high_freq", 4000.0)).value

        self._update_filters(low_gain, mid_gain, high_gain, low_freq, high_freq)

        if self._sos is None:
            return audio

        output = np.zeros_like(audio)
        for ch in range(min(audio.shape[1], 2)):
            out, self._zi = sig.sosfilt(self._sos, audio[:, ch], zi=self._zi)
            output[:, ch] = out

        return np.clip(output, -1.0, 1.0)

    def _biquad_shelf(self, gain_db, fc, is_low):
        A = 10 ** (abs(gain_db) / 40.0)
        w0 = 2 * np.pi * fc / self._sample_rate
        alpha = np.sin(w0) / (2 * np.sqrt(A))
        cos_w0 = np.cos(w0)
        b = np.zeros(3)
        a = np.zeros(3)
        if is_low:
            b[0] = A * ((A + 1) - (A - 1) * cos_w0 + 2 * np.sqrt(A) * alpha)
            b[1] = 2 * A * ((A - 1) - (A + 1) * cos_w0)
            b[2] = A * ((A + 1) - (A - 1) * cos_w0 - 2 * np.sqrt(A) * alpha)
            a[0] = (A + 1) + (A - 1) * cos_w0 + 2 * np.sqrt(A) * alpha
            a[1] = -2 * ((A - 1) + (A + 1) * cos_w0)
            a[2] = (A + 1) + (A - 1) * cos_w0 - 2 * np.sqrt(A) * alpha
        else:
            b[0] = A * ((A + 1) + (A - 1) * cos_w0 + 2 * np.sqrt(A) * alpha)
            b[1] = -2 * A * ((A - 1) + (A + 1) * cos_w0)
            b[2] = A * ((A + 1) + (A - 1) * cos_w0 - 2 * np.sqrt(A) * alpha)
            a[0] = (A + 1) - (A - 1) * cos_w0 + 2 * np.sqrt(A) * alpha
            a[1] = 2 * ((A - 1) - (A + 1) * cos_w0)
            a[2] = (A + 1) - (A - 1) * cos_w0 - 2 * np.sqrt(A) * alpha
        return [b[0]/a[0], b[1]/a[0], b[2]/a[0], 1.0, a[1]/a[0], a[2]/a[0]]

    def _biquad_peak(self, gain_db, fc, q):
        if abs(gain_db) < 0.5:
            return None
        A = 10 ** (gain_db / 40.0)
        w0 = 2 * np.pi * fc / self._sample_rate
        alpha = np.sin(w0) / (2 * q)
        cos_w0 = np.cos(w0)
        b0 = 1 + alpha * A
        b1 = -2 * cos_w0
        b2 = 1 - alpha * A
        a0 = 1 + alpha / A
        a1 = -2 * cos_w0
        a2 = 1 - alpha / A
        return [b0/a0, b1/a0, b2/a0, 1.0, a1/a0, a2/a0]

    def reset(self):
        self._zi = None
