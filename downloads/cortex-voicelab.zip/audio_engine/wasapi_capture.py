"""
WASAPI Loopback Capture — captures system-wide audio (like Voicemod).
Only works on Windows. Falls back to microphone-only capture on other platforms.
"""
import os, sys, platform, threading, numpy as np

class SystemAudioCapture:
    """Captures all system audio output using WASAPI loopback."""

    def __init__(self, sample_rate=48000, block_size=512):
        self.sample_rate = sample_rate
        self.block_size = block_size
        self.stream = None
        self.running = False
        self._callback = None

    def start(self, callback):
        """Start capturing system audio. callback receives numpy arrays."""
        self._callback = callback
        self.running = True

        if platform.system() == "Windows":
            self._start_wasapi()
        else:
            self._start_microphone()

    def _start_wasapi(self):
        """Use WASAPI loopback on Windows to capture all system audio."""
        try:
            import pyaudio
            p = pyaudio.PyAudio()

            # Find the WASAPI loopback device
            loopback_device = None
            for i in range(p.get_device_count()):
                info = p.get_device_info_by_index(i)
                if "loopback" in info["name"].lower() or "mix" in info["name"].lower():
                    loopback_device = i
                    break

            if loopback_device is None:
                # Fall back to default input
                loopback_device = p.get_default_input_device_info()["index"]

            def callback(in_data, frame_count, time_info, status):
                if self.running and self._callback:
                    audio = np.frombuffer(in_data, dtype=np.int16).astype(np.float32) / 32768.0
                    self._callback(audio)
                return (None, pyaudio.paContinue)

            self.stream = p.open(
                format=pyaudio.paInt16,
                channels=1,
                rate=self.sample_rate,
                input=True,
                input_device_index=loopback_device,
                frames_per_buffer=self.block_size,
                stream_callback=callback,
                as_loopback=True,
            )
            self.stream.start_stream()
        except ImportError:
            self._start_microphone()
        except Exception as e:
            print(f"WASAPI capture failed: {e}")
            self._start_microphone()

    def _start_microphone(self):
        """Fall back to microphone capture."""
        try:
            import sounddevice as sd

            def callback(indata, frames, time_info, status):
                if self.running and self._callback:
                    self._callback(indata[:, 0])

            self.stream = sd.InputStream(
                samplerate=self.sample_rate,
                blocksize=self.block_size,
                channels=1,
                callback=callback,
            )
            self.stream.start()
        except Exception as e:
            print(f"Microphone capture failed: {e}")

    def stop(self):
        self.running = False
        if self.stream:
            try:
                self.stream.stop()
                self.stream.close()
            except:
                pass
