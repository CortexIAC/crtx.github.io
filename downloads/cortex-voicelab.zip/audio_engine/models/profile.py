from dataclasses import dataclass, field
from typing import Optional


@dataclass
class Profile:
    name: str
    display_name: str
    description: str = ""
    blueprint_name: str = ""
    icon: str = "mic"
    category: str = "voice"
    tags: list = field(default_factory=list)
    is_favorite: bool = False
    is_builtin: bool = False

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "display_name": self.display_name,
            "description": self.description,
            "blueprint_name": self.blueprint_name,
            "icon": self.icon,
            "category": self.category,
            "tags": self.tags,
            "is_favorite": self.is_favorite,
            "is_builtin": self.is_builtin,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "Profile":
        return cls(
            name=data.get("name", ""),
            display_name=data.get("display_name", data.get("name", "")),
            description=data.get("description", ""),
            blueprint_name=data.get("blueprint_name", data.get("name", "")),
            icon=data.get("icon", "mic"),
            category=data.get("category", "voice"),
            tags=data.get("tags", []),
            is_favorite=data.get("is_favorite", False),
            is_builtin=data.get("is_builtin", False),
        )
