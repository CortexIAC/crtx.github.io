from dataclasses import dataclass, field
from enum import Enum


class DeviceType(Enum):
    INPUT = "input"
    OUTPUT = "output"
    DUPLEX = "duplex"


@dataclass
class AudioDevice:
    id: str
    name: str
    device_type: DeviceType
    channels: int = 2
    input_channels: int = 0
    output_channels: int = 0
    sample_rate: int = 48000
    is_default: bool = False
    host_api: str = ""

    @property
    def is_input(self) -> bool:
        return self.device_type in (DeviceType.INPUT, DeviceType.DUPLEX)

    @property
    def is_output(self) -> bool:
        return self.device_type in (DeviceType.OUTPUT, DeviceType.DUPLEX)


@dataclass
class AudioLevel:
    left: float = 0.0
    right: float = 0.0
    peak: float = 0.0
    rms: float = 0.0
    is_clipping: bool = False


@dataclass
class StreamConfig:
    sample_rate: int = 44100
    buffer_size: int = 256
    channels: int = 2
    dtype: str = "float32"
    latency: float = 0.005  # seconds — "low" string also accepted by sd.Stream


@dataclass
class StreamMetrics:
    input_level: AudioLevel = field(default_factory=AudioLevel)
    output_level: AudioLevel = field(default_factory=AudioLevel)
    latency_ms: float = 0.0
    dropped_frames: int = 0
    is_active: bool = False
