import json
import os
from dataclasses import dataclass, field, asdict
from typing import Optional


SETTINGS_FILE = "settings.json"


@dataclass
class AppSettings:
    # Audio
    sample_rate: int = 44100
    buffer_size: int = 256
    latency: float = 0.005
    input_gain: float = 1.5

    # Behaviour
    auto_start_engine: bool = False
    start_minimized: bool = False
    live_playback_on_start: bool = False

    # Voice Conversion
    vc_enabled: bool = False
    vc_cuda: bool = False
    vc_model: str = ""
    vc_models_dir: str = ""

    # Last used
    last_profile: str = ""
    last_input_device: str = ""
    last_output_device: str = ""

    @classmethod
    def load(cls, path: str = "") -> "AppSettings":
        if not path:
            path = SETTINGS_FILE
        if not os.path.exists(path):
            return cls()
        try:
            with open(path, encoding="utf-8") as f:
                data = json.load(f)
            return cls(**{k: data.get(k, v) for k, v in asdict(cls()).items()})
        except Exception:
            return cls()

    def save(self, path: str = ""):
        if not path:
            path = SETTINGS_FILE
        try:
            with open(path, "w", encoding="utf-8") as f:
                json.dump(asdict(self), f, indent=2)
        except Exception:
            pass
