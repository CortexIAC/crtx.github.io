from dataclasses import dataclass, field
from typing import List, Optional, Dict, Any
from audio_engine.models.processing_node import ProcessingNode, NodeConnection, NodeType


@dataclass
class Blueprint:
    name: str
    description: str = ""
    nodes: List[ProcessingNode] = field(default_factory=list)
    connections: List[NodeConnection] = field(default_factory=list)
    sample_rate: int = 48000
    buffer_size: int = 512
    metadata: Dict[str, Any] = field(default_factory=dict)

    def add_node(self, node: ProcessingNode):
        if node not in self.nodes:
            self.nodes.append(node)

    def remove_node(self, node_id: str):
        self.nodes = [n for n in self.nodes if n.id != node_id]
        self.connections = [
            c for c in self.connections
            if c.source_id != node_id and c.target_id != node_id
        ]

    def add_connection(self, conn: NodeConnection):
        if conn not in self.connections:
            self.connections.append(conn)

    def remove_connection(self, conn: NodeConnection):
        if conn in self.connections:
            self.connections.remove(conn)

    def get_node(self, node_id: str) -> Optional[ProcessingNode]:
        for n in self.nodes:
            if n.id == node_id:
                return n
        return None

    def get_nodes_by_type(self, node_type: NodeType) -> List[ProcessingNode]:
        return [n for n in self.nodes if n.node_type == node_type]

    def has_input(self) -> bool:
        return len(self.get_nodes_by_type(NodeType.INPUT)) > 0

    def has_output(self) -> bool:
        return len(self.get_nodes_by_type(NodeType.OUTPUT)) > 0

    def validate(self) -> List[str]:
        errors = []
        if not self.has_input():
            errors.append("Blueprint must have an input node")
        if not self.has_output():
            errors.append("Blueprint must have an output node")
        for conn in self.connections:
            if not self.get_node(conn.source_id):
                errors.append(f"Connection source '{conn.source_id}' not found")
            if not self.get_node(conn.target_id):
                errors.append(f"Connection target '{conn.target_id}' not found")
        return errors

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "description": self.description,
            "sample_rate": self.sample_rate,
            "buffer_size": self.buffer_size,
            "nodes": [
                {
                    "id": n.id,
                    "node_type": n.node_type.value,
                    "label": n.label,
                    "parameters": {k: v.value for k, v in n.parameters.items()},
                    "bypass": n.bypass,
                    "position_x": n.position_x,
                    "position_y": n.position_y,
                }
                for n in self.nodes
            ],
            "connections": [
                {"source_id": c.source_id, "target_id": c.target_id}
                for c in self.connections
            ],
            "metadata": self.metadata,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "Blueprint":
        from audio_engine.models.processing_node import NodeParameter
        type_map = {e.value: e for e in NodeType}
        # Legacy display-name fallback mapping
        legacy_map = {
            "Input": NodeType.INPUT, "Output": NodeType.OUTPUT,
            "Noise Gate": NodeType.NOISE_GATE, "Noise Reduction": NodeType.NOISE_REDUCTION,
            "Equalizer": NodeType.EQUALIZER, "Compressor": NodeType.COMPRESSOR,
            "Pitch Shift": NodeType.PITCH_SHIFT, "Reverb": NodeType.REVERB,
            "Delay": NodeType.DELAY, "Radio Filter": NodeType.RADIO,
            "Radio Effect": NodeType.RADIO, "Voice Conversion": NodeType.VOICE_CONVERSION,
            "Limiter": NodeType.LIMITER, "De-esser": NodeType.DEESSER, "DeEsser": NodeType.DEESSER,
            "MultibandComp": NodeType.MULTIBAND_COMP, "Exciter": NodeType.EXCITER, "AutoGain": NodeType.AUTOGAIN,
        }
        nodes = []
        for nd in data.get("nodes", []):
            raw = nd["node_type"]
            node_type = type_map.get(raw) or legacy_map.get(raw, NodeType.INPUT)
            params = {}
            for k, v in nd.get("parameters", {}).items():
                params[k] = NodeParameter(name=k, value=float(v))
            nodes.append(ProcessingNode(
                id=nd["id"],
                node_type=node_type,
                label=nd.get("label", ""),
                parameters=params,
                bypass=nd.get("bypass", False),
                position_x=nd.get("position_x", 0),
                position_y=nd.get("position_y", 0),
            ))
        connections = []
        for cd in data.get("connections", []):
            # Support both new (source_id/target_id) and old (source_node/target_node) formats
            source_id = cd.get("source_id") or cd.get("source_node", "")
            target_id = cd.get("target_id") or cd.get("target_node", "")
            if source_id and target_id:
                connections.append(NodeConnection(source_id=source_id, target_id=target_id))
        return cls(
            name=data.get("name", "Untitled"),
            description=data.get("description", ""),
            nodes=nodes,
            connections=connections,
            sample_rate=data.get("sample_rate", 48000),
            buffer_size=data.get("buffer_size", 512),
            metadata=data.get("metadata", {}),
        )
