from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Optional, Any


class NodeType(Enum):
    INPUT = "input"
    OUTPUT = "output"
    NOISE_GATE = "noise_gate"
    NOISE_REDUCTION = "noise_reduction"
    EQUALIZER = "equalizer"
    COMPRESSOR = "compressor"
    PITCH_SHIFT = "pitch_shift"
    VOICE_CONVERSION = "voice_conversion"
    LIMITER = "limiter"
    DEESSER = "deesser"
    MULTIBAND_COMP = "multiband_comp"
    EXCITER = "exciter"
    AUTOGAIN = "autogain"
    REVERB = "reverb"
    DELAY = "delay"
    RADIO = "radio"


@dataclass
class NodeParameter:
    name: str
    value: float
    min_value: float = 0.0
    max_value: float = 1.0
    step: float = 0.01
    unit: str = ""
    label: str = ""


@dataclass
class ProcessingNode:
    id: str
    node_type: NodeType
    label: str = ""
    parameters: Dict[str, NodeParameter] = field(default_factory=dict)
    bypass: bool = False
    position_x: float = 0.0
    position_y: float = 0.0

    def get_param(self, name: str) -> float:
        return self.parameters.get(name, NodeParameter(name, 0.0)).value

    def set_param(self, name: str, value: float):
        if name in self.parameters:
            p = self.parameters[name]
            p.value = max(p.min_value, min(p.max_value, value))

    @property
    def display_name(self) -> str:
        return self.label or self.node_type.value.replace("_", " ").title()


@dataclass
class NodeConnection:
    source_id: str
    target_id: str

    def inverted(self) -> "NodeConnection":
        return NodeConnection(source_id=self.target_id, target_id=self.source_id)
