import json
import os
from typing import List, Optional
from audio_engine.models.blueprint import Blueprint
from audio_engine.models.processing_node import (
    ProcessingNode, NodeConnection, NodeType, NodeParameter,
)


class BlueprintManager:
    def __init__(self, blueprints_dir: str = ""):
        self._directory = blueprints_dir
        self._cache: dict[str, Blueprint] = {}

    @property
    def directory(self) -> str:
        return self._directory

    @directory.setter
    def directory(self, path: str):
        self._directory = path
        self.refresh()

    # --- CRUD ---

    def list(self) -> List[str]:
        if not self._directory or not os.path.exists(self._directory):
            return []
        return sorted([
            f.replace(".json", "")
            for f in os.listdir(self._directory)
            if f.endswith(".json")
        ])

    def load(self, name: str) -> Optional[Blueprint]:
        if name in self._cache:
            return self._cache[name]

        path = self._resolve_path(name)
        if not os.path.exists(path):
            return None

        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
            bp = Blueprint.from_dict(data)
            self._cache[name] = bp
            return bp
        except Exception:
            return None

    def save(self, blueprint: Blueprint):
        if not self._directory:
            return
        os.makedirs(self._directory, exist_ok=True)
        path = self._resolve_path(blueprint.name)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(blueprint.to_dict(), f, indent=2)
        self._cache[blueprint.name] = blueprint

    def delete(self, name: str):
        path = self._resolve_path(name)
        if os.path.exists(path):
            os.remove(path)
        self._cache.pop(name, None)

    def rename(self, old_name: str, new_name: str) -> bool:
        bp = self.load(old_name)
        if bp is None:
            return False
        old_path = self._resolve_path(old_name)
        bp.name = new_name
        self.save(bp)
        if os.path.exists(old_path):
            os.remove(old_path)
        self._cache.pop(old_name, None)
        return True

    def duplicate(self, name: str, new_name: str) -> Optional[Blueprint]:
        bp = self.load(name)
        if bp is None:
            return None
        import copy
        new_bp = copy.deepcopy(bp)
        new_bp.name = new_name
        for i, node in enumerate(new_bp.nodes):
            node.id = f"{node.node_type.value}_{i}_{new_name[:4]}"
        self.save(new_bp)
        return new_bp

    def create_default(self, name: str) -> Blueprint:
        bp = Blueprint(name=name)
        bp.add_node(ProcessingNode(
            id="input",
            node_type=NodeType.INPUT,
            label="Input",
            position_x=50, position_y=200,
        ))
        bp.add_node(ProcessingNode(
            id="output",
            node_type=NodeType.OUTPUT,
            label="Output",
            position_x=600, position_y=200,
        ))
        bp.add_connection(NodeConnection(source_id="input", target_id="output"))
        self.save(bp)
        return bp

    # --- Import / Export ---

    def export(self, name: str, filepath: str):
        bp = self.load(name)
        if bp:
            with open(filepath, "w", encoding="utf-8") as f:
                json.dump(bp.to_dict(), f, indent=2)

    def import_bp(self, filepath: str) -> Optional[Blueprint]:
        if not os.path.exists(filepath):
            return None
        try:
            with open(filepath, "r", encoding="utf-8") as f:
                data = json.load(f)
            bp = Blueprint.from_dict(data)
            self.save(bp)
            return bp
        except Exception:
            return None

    # --- Validation ---

    def validate(self, name: str) -> List[str]:
        bp = self.load(name)
        if bp is None:
            return ["Blueprint not found"]
        return bp.validate()

    # --- Cache ---

    def refresh(self):
        self._cache.clear()

    def _resolve_path(self, name: str) -> str:
        return os.path.join(self._directory or "", f"{name}.json")
