╔══════════════════════════════════════════════╗
║        Cortex VoiceLab - Quick Start         ║
╚══════════════════════════════════════════════╝

AI voice changer and audio processing platform.

=== Quick Start ===

1. Install dependencies:
   pip install -r requirements.txt

2. Run:
   python run.py

=== Features ===
- 16 real-time audio effects
- AI voice conversion (RVC/ONNX)
- Soundboard with multi-sample playback
- Blueprint/preset system (9 presets)
- Voicemod bridge integration

=== Requirements ===
- Python 3.9+
- Windows (CoreAudio loopback support)
