# Cortex VoiceLab

AI-powered voice changer and audio processing platform.

## What's New
- CIE integration: describe a voice style in natural language → generates optimal effect chain
- System-wide audio capture (WASAPI loopback, like Voicemod)
- 16 real-time audio effects
- RVC AI voice conversion
- Soundboard with multi-sample playback
- Blueprint/preset system

## Quick Start
pip install -r requirements.txt
python run.py

For system-wide audio capture, install VB-CABLE or use Windows WASAPI.
