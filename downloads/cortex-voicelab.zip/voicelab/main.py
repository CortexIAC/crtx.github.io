"""
Cortex VoiceLab - Entry Point
A local-first AI voice changer and audio utility platform.
"""

import sys
import traceback


def main():
    try:
        from voicelab.app import VoiceLabApp
        app = VoiceLabApp()
        app.initialize()
        sys.exit(app.run())
    except Exception as e:
        print(f"Fatal error: {e}")
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
