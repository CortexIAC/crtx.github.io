"""
CIE Integration for VoiceLab — AI-powered voice profile generation.
Routes natural language descriptions through CIE's Router to generate effect settings.
"""
import sys, os, json

# Add CIE to path
sys.path.insert(0, os.path.expanduser("~/Desktop/programming/synapse-cie"))

class CIEVoiceEngine:
    """Bridge between VoiceLab and CIE's multi-model router."""

    def __init__(self):
        self.router = None

    def _init_router(self):
        try:
            from cie.router import Router
            self.router = Router()
        except ImportError:
            self.router = None

    def available(self):
        if not self.router: self._init_router()
        if not self.router: return {"local": {"available": False}}
        return self.router.available()

    def generate_blueprint(self, description):
        """
        Take a natural language voice description and return effect settings.
        Example: "make me sound like a robot from the 1950s"
        Returns: dict with effect chain settings matching VoiceLab's Blueprint format
        """
        if not self.router: self._init_router()
        if not self.router:
            return self._fallback_blueprint(description)

        prompt = f"""You are generating voice effect settings for VoiceLab.
Voice description: {description}

Available effects: pitch_shift, reverb, delay, equalizer, compressor, noise_gate, limiter, exciter, radio, autogain, deesser, multiband_comp, noise_reduction

Return a JSON object with:
1. effect_chain: list of effect names in processing order
2. name: a short name for this preset
3. Settings for each effect (reasonable defaults):
   - pitch_shift: {{"semitones": 0, "formant_preserve": true}}
   - reverb: {{"room_size": 0.5, "damping": 0.5, "wet": 0.3, "dry": 0.7}}
   - delay: {{"delay_time": 0.3, "feedback": 0.3, "wet": 0.2}}
   - equalizer: {{"low_gain": 0, "mid_gain": 0, "high_gain": 0}}
   - compressor: {{"threshold": -20, "ratio": 4, "attack": 5, "release": 50}}
   - radio: {{"frequency": 1000, "bandwidth": 200, "gain": 0}}
   - noise_gate: {{"threshold": -40, "attack": 1, "release": 50}}
   - limiter: {{"threshold": -2, "release": 10}}
   - exciter: {{"amount": 0.3, "frequency": 4000}}
   - autogain: {{"target_level": -3, "attack": 10, "release": 100}}

Return ONLY valid JSON, no explanation."""

        try:
            route_info, response = self.router.call(prompt, task_type="code", quality="medium")
            if response and response.startswith("{"):
                settings = json.loads(response)
                settings["_cie_generated"] = True
                settings["_cie_prompt"] = description
                settings["_cie_model"] = route_info
                return settings
        except:
            pass

        return self._fallback_blueprint(description)

    def _fallback_blueprint(self, description):
        """Keyword-based fallback when CIE is unavailable."""
        desc = description.lower()
        blueprint = {
            "name": description[:30],
            "effect_chain": ["pitch_shift"],
            "effects": {"pitch_shift": {"semitones": 0, "formant_preserve": True}},
            "_cie_generated": False,
            "_cie_prompt": description,
        }

        if "robot" in desc:
            blueprint["effect_chain"] = ["pitch_shift", "radio", "equalizer"]
            blueprint["effects"] = {
                "pitch_shift": {"semitones": 3, "formant_preserve": True},
                "radio": {"frequency": 800, "bandwidth": 400, "gain": 2},
                "equalizer": {"low_gain": -6, "mid_gain": 4, "high_gain": -3},
            }
        elif "monster" in desc or "demon" in desc:
            blueprint["effect_chain"] = ["pitch_shift", "reverb", "equalizer"]
            blueprint["effects"] = {
                "pitch_shift": {"semitones": -8, "formant_preserve": False},
                "reverb": {"room_size": 0.9, "damping": 0.3, "wet": 0.5},
                "equalizer": {"low_gain": 6, "mid_gain": -2, "high_gain": -4},
            }
        elif "radio" in desc or "broadcast" in desc:
            blueprint["effect_chain"] = ["radio", "compressor"]
            blueprint["effects"] = {
                "radio": {"frequency": 1200, "bandwidth": 300, "gain": 3},
                "compressor": {"threshold": -18, "ratio": 6, "attack": 3, "release": 40},
            }
        elif "echo" in desc or "cave" in desc:
            blueprint["effect_chain"] = ["delay", "reverb"]
            blueprint["effects"] = {
                "delay": {"delay_time": 0.4, "feedback": 0.5, "wet": 0.4},
                "reverb": {"room_size": 0.95, "damping": 0.2, "wet": 0.6},
            }
        elif "chipmunk" in desc or "high" in desc or "helium" in desc:
            blueprint["effect_chain"] = ["pitch_shift"]
            blueprint["effects"] = {
                "pitch_shift": {"semitones": 12, "formant_preserve": True},
            }
        elif "deep" in desc or "low" in desc or "giant" in desc:
            blueprint["effect_chain"] = ["pitch_shift", "limiter"]
            blueprint["effects"] = {
                "pitch_shift": {"semitones": -6, "formant_preserve": False},
                "limiter": {"threshold": -3, "release": 15},
            }

        return blueprint

    def analyze_voice(self, audio_data, sample_rate=48000):
        """Placeholder for future CIE voice analysis."""
        return {"status": "Voice analysis requires CIE + Whisper integration"}
