from typing import Optional, Callable, List
from audio_engine import AudioEngine
from audio_engine.models.blueprint import Blueprint
from audio_engine.models.profile import Profile as EngineProfile


class EngineController:
    """Adapts the Cortex Audio Engine for the VoiceLab UI layer."""

    def __init__(self):
        self.engine = AudioEngine()
        self._on_profile_changed: Optional[Callable] = None
        self._on_metrics: Optional[Callable] = None
        self._on_blueprint_list_changed: Optional[Callable] = None

    def initialize(self, blueprints_dir: str, profiles_dir: str):
        self.engine.initialize(blueprints_dir, profiles_dir)
        self.engine.router.on_metrics(self._handle_metrics)

    def _handle_metrics(self, metrics):
        if self._on_metrics:
            self._on_metrics(metrics)

    # --- Devices ---

    def get_devices(self):
        return self.engine.devices.all()

    def get_input_devices(self):
        return self.engine.devices.inputs()

    def get_output_devices(self):
        return self.engine.devices.outputs()

    def select_input(self, device_id: str):
        self.engine.devices.select_input(device_id)

    def select_output(self, device_id: str):
        self.engine.devices.select_output(device_id)

    def get_default_input(self):
        return self.engine.devices.default_input()

    def get_default_output(self):
        return self.engine.devices.default_output()

    # --- Profiles ---

    @property
    def profiles(self) -> list:
        return self.engine.profiles.all

    @property
    def current_profile_name(self) -> Optional[str]:
        return self.engine.current_profile

    def apply_profile(self, name: str):
        success = self.engine.set_profile(name)
        if success and self._on_profile_changed:
            profile = self.engine.profiles.get(name)
            self._on_profile_changed(profile)

    # --- Blueprints ---

    @property
    def current_blueprint_name(self) -> Optional[str]:
        return self.engine.current_blueprint

    def get_blueprint_names(self) -> List[str]:
        return self.engine.blueprints.list()

    def load_blueprint(self, name: str) -> Optional[Blueprint]:
        return self.engine.blueprints.load(name)

    def save_blueprint(self, blueprint: Blueprint):
        self.engine.blueprints.save(blueprint)

    def create_default_blueprint(self, name: str) -> Blueprint:
        return self.engine.blueprints.create_default(name)

    def apply_blueprint(self, blueprint: Blueprint):
        self.engine.pipeline.set_blueprint(blueprint)

    def export_blueprint(self, name: str, path: str):
        self.engine.blueprints.export(name, path)

    def import_blueprint(self, path: str) -> Optional[Blueprint]:
        return self.engine.blueprints.import_bp(path)

    # --- Engine Lifecycle ---

    def start_engine(self):
        self.engine.start()

    def stop_engine(self):
        self.engine.stop()

    @property
    def is_engine_running(self) -> bool:
        return self.engine.is_active

    # --- Live Playback ---

    @property
    def live_playback(self) -> bool:
        return self.engine.live_playback

    @live_playback.setter
    def live_playback(self, enabled: bool):
        self.engine.live_playback = enabled

    @property
    def bypass(self) -> bool:
        return self.engine.bypass

    @bypass.setter
    def bypass(self, enabled: bool):
        self.engine.bypass = enabled

    # --- Low Latency Mode ---

    @property
    def low_latency_mode(self) -> bool:
        return self.engine.low_latency_mode

    @low_latency_mode.setter
    def low_latency_mode(self, enabled: bool):
        self.engine.low_latency_mode = enabled

    # --- Input Gain ---

    @property
    def input_gain(self) -> float:
        return self.engine.input_gain

    @input_gain.setter
    def input_gain(self, value: float):
        self.engine.input_gain = value

    # --- Voice Conversion ---

    @property
    def vc_models(self):
        return self.engine.vc_models

    def load_vc_model(self, name: str) -> bool:
        return self.engine.vc_models.load(name)

    # --- Settings Persistence ---

    def load_settings(self, path: str = ""):
        s = self.engine.settings.__class__.load(path)
        self.engine.settings = s
        self.engine.input_gain = s.input_gain
        if s.last_profile:
            self.apply_profile(s.last_profile)
        return s

    def save_settings(self, path: str = ""):
        s = self.engine.settings
        s.last_profile = self.engine.current_profile or ""
        s.last_input_device = self.engine.devices.selected_input_id or ""
        s.last_output_device = self.engine.devices.selected_output_id or ""
        s.input_gain = self.engine.input_gain
        s.buffer_size = self.engine.router._config.buffer_size
        s.sample_rate = self.engine.router._config.sample_rate
        s.save(path)

    # --- Event Listeners ---

    def on_profile_changed(self, callback: Callable):
        self._on_profile_changed = callback

    def on_metrics(self, callback: Callable):
        self._on_metrics = callback

    def on_blueprint_list_changed(self, callback: Callable):
        self._on_blueprint_list_changed = callback

    # --- Shutdown ---

    def shutdown(self):
        self.engine.shutdown()
