import os
import sys
from PySide6.QtWidgets import QApplication
from PySide6.QtCore import Qt
from voicelab.ui.main_window import MainWindow
from voicelab.controllers.engine_controller import EngineController


class VoiceLabApp:
    def __init__(self):
        self._app: QApplication = None
        self._window: MainWindow = None
        self._controller = EngineController()

    def initialize(self):
        self._app = QApplication(sys.argv)
        self._app.setApplicationName("Cortex VoiceLab")
        self._app.setOrganizationName("Cortex Intelligence")
        self._app.setStyle("Fusion")

        app_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        blueprints_dir = os.path.join(app_dir, "blueprints")
        profiles_dir = os.path.join(app_dir, "profiles")

        self._controller.initialize(blueprints_dir, profiles_dir)
        self._window = MainWindow(self._controller)
        self._window.show()

    def run(self):
        if self._app is None:
            self.initialize()
        return self._app.exec()

    def shutdown(self):
        if self._controller:
            self._controller.shutdown()
