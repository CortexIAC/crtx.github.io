from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QComboBox, QFrame, QProgressBar, QSlider
)
from PySide6.QtCore import Qt, QTimer


def _api_name(host_api_id: str) -> str:
    try:
        import sounddevice as sd
        apis = sd.query_hostapis()
        return apis[int(host_api_id)]["name"] if apis else ""
    except Exception:
        return ""


def _format_dev(dev) -> str:
    api = _api_name(dev.host_api)
    tag = f" [{api}]" if api else ""
    return f"{dev.name[:40]}{tag}"


class DevicesPanel(QWidget):
    def __init__(self, controller, parent=None):
        super().__init__(parent)
        self._controller = controller
        self._setup_ui()
        self._refresh()

    def _setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 24, 24, 24)
        layout.setSpacing(16)

        title = QLabel("Devices")
        title.setStyleSheet("color: #ffffff; font-size: 22px; font-weight: bold;")
        layout.addWidget(title)

        # Input
        in_frame = QFrame()
        in_frame.setStyleSheet("QFrame { background-color: #252736; border: 1px solid #2a2d3a; border-radius: 10px; padding: 16px; }")
        in_layout = QVBoxLayout(in_frame)
        in_layout.setSpacing(8)

        in_header = QHBoxLayout()
        in_header.addWidget(QLabel("Microphone (Input)", styleSheet="color: #ffffff; font-size: 14px; font-weight: bold;"))
        in_header.addStretch()

        ref_btn = QPushButton("Refresh")
        ref_btn.setFixedHeight(28)
        ref_btn.setStyleSheet("QPushButton { background: #2a2d3a; color: #d1d5db; border: 1px solid #3a3d5c; border-radius: 5px; padding: 4px 12px; font-size: 11px; } QPushButton:hover { background: #3a3d5c; }")
        ref_btn.clicked.connect(self._refresh)
        in_header.addWidget(ref_btn)
        in_layout.addLayout(in_header)

        self._input_combo = QComboBox()
        self._input_combo.setStyleSheet("QComboBox { background: #1a1b2a; color: #fff; border: 1px solid #2a2d3a; border-radius: 5px; padding: 6px 10px; } QComboBox::drop-down { border: none; } QComboBox QAbstractItemView { background: #1a1b2a; color: #fff; selection-background-color: #3a3d5c; }")
        self._input_combo.currentIndexChanged.connect(self._on_input)
        in_layout.addWidget(self._input_combo)

        self._input_level = QProgressBar()
        self._input_level.setRange(0, 100)
        self._input_level.setTextVisible(False)
        self._input_level.setFixedHeight(6)
        self._input_level.setStyleSheet("QProgressBar { background: #1a1b2a; border-radius: 3px; } QProgressBar::chunk { background: #4ade80; border-radius: 3px; }")
        in_layout.addWidget(self._input_level)
        layout.addWidget(in_frame)

        # Output
        out_frame = QFrame()
        out_frame.setStyleSheet("QFrame { background-color: #252736; border: 1px solid #2a2d3a; border-radius: 10px; padding: 16px; }")
        out_layout = QVBoxLayout(out_frame)
        out_layout.setSpacing(8)
        out_layout.addWidget(QLabel("Speaker (Output)", styleSheet="color: #ffffff; font-size: 14px; font-weight: bold;"))

        self._output_combo = QComboBox()
        self._output_combo.setStyleSheet("QComboBox { background: #1a1b2a; color: #fff; border: 1px solid #2a2d3a; border-radius: 5px; padding: 6px 10px; } QComboBox::drop-down { border: none; } QComboBox QAbstractItemView { background: #1a1b2a; color: #fff; selection-background-color: #3a3d5c; }")
        self._output_combo.currentIndexChanged.connect(self._on_output)
        out_layout.addWidget(self._output_combo)

        self._output_level = QProgressBar()
        self._output_level.setRange(0, 100)
        self._output_level.setTextVisible(False)
        self._output_level.setFixedHeight(6)
        self._output_level.setStyleSheet("QProgressBar { background: #1a1b2a; border-radius: 3px; } QProgressBar::chunk { background: #7c7aff; border-radius: 3px; }")
        out_layout.addWidget(self._output_level)
        layout.addWidget(out_frame)

        # Gain
        gain_frame = QFrame()
        gain_frame.setStyleSheet("QFrame { background-color: #252736; border: 1px solid #2a2d3a; border-radius: 10px; padding: 12px 16px; }")
        gain_layout = QHBoxLayout(gain_frame)
        gain_layout.setSpacing(12)
        gain_layout.addWidget(QLabel("Mic Gain", styleSheet="color: #d1d5db; font-size: 13px;"))
        self._gain_slider = QSlider(Qt.Horizontal)
        self._gain_slider.setRange(0, 300)
        self._gain_slider.setValue(150)
        self._gain_slider.setFixedWidth(150)
        self._gain_slider.setStyleSheet("QSlider::groove:horizontal { height: 4px; background: #2a2d3a; border-radius: 2px; } QSlider::handle:horizontal { background: #7c7aff; width: 14px; height: 14px; margin: -5px 0; border-radius: 7px; } QSlider::sub-page:horizontal { background: #7c7aff; border-radius: 2px; }")
        self._gain_slider.valueChanged.connect(self._on_gain)
        gain_layout.addWidget(self._gain_slider)
        self._gain_lbl = QLabel("1.5x")
        self._gain_lbl.setStyleSheet("color: #d1d5db; font-size: 12px; min-width: 30px;")
        gain_layout.addWidget(self._gain_lbl)
        gain_layout.addStretch()
        layout.addWidget(gain_frame)

        # Engine controls
        eng_frame = QFrame()
        eng_frame.setStyleSheet("QFrame { background-color: #252736; border: 1px solid #2a2d3a; border-radius: 10px; padding: 16px; }")
        eng_layout = QHBoxLayout(eng_frame)
        eng_layout.setSpacing(12)

        self._start_btn = QPushButton("Start Engine")
        self._start_btn.setFixedHeight(36)
        self._start_btn.setStyleSheet("QPushButton { background: #4ade80; color: #000; border: none; border-radius: 6px; padding: 8px 20px; font-size: 13px; font-weight: bold; } QPushButton:hover { background: #34d399; }")
        self._start_btn.clicked.connect(self._toggle)
        eng_layout.addWidget(self._start_btn)

        self._live_cb = QPushButton("Live Playback")
        self._live_cb.setFixedHeight(36)
        self._live_cb.setCheckable(True)
        self._live_cb.setStyleSheet("QPushButton { background: #2a2d3a; color: #9ca3af; border: 1px solid #3a3d5c; border-radius: 6px; padding: 8px 14px; font-size: 12px; } QPushButton:hover { background: #3a3d5c; color: #fff; } QPushButton:checked { background: #4ade80; color: #000; border-color: #4ade80; }")
        self._live_cb.clicked.connect(lambda c: setattr(self._controller, 'live_playback', c))
        eng_layout.addWidget(self._live_cb)

        self._status_lbl = QLabel("Stopped")
        self._status_lbl.setStyleSheet("color: #f87171; font-size: 13px; font-weight: bold;")
        eng_layout.addWidget(self._status_lbl)
        eng_layout.addStretch()
        layout.addWidget(eng_frame)
        layout.addStretch()

        self._timer = QTimer()
        self._timer.timeout.connect(self._update_levels)
        self._timer.start(80)

    def _on_gain(self, value: int):
        gain = value / 100.0
        self._gain_lbl.setText(f"{gain:.1f}x")
        self._controller.input_gain = gain

    def _refresh(self):
        dm = self._controller.engine.devices
        dm.refresh()

        # Use smart pairing to suggest best input/output
        suggested_in, suggested_out = dm.suggest_pair()

        curr_in = self._input_combo.currentData() if self._input_combo.count() > 0 else suggested_in
        default_in = dm.default_input()

        self._input_combo.blockSignals(True)
        self._input_combo.clear()
        sel_idx = 0
        for i, dev in enumerate(dm.inputs()):
            self._input_combo.addItem(_format_dev(dev), dev.id)
            if curr_in and dev.id == curr_in:
                sel_idx = i
            elif not curr_in and suggested_in and dev.id == suggested_in:
                sel_idx = i
            elif default_in and dev.id == default_in.id:
                sel_idx = i
        self._input_combo.setCurrentIndex(sel_idx)
        self._input_combo.blockSignals(False)

        curr_out = self._output_combo.currentData() if self._output_combo.count() > 0 else suggested_out
        default_out = dm.default_output()

        self._output_combo.blockSignals(True)
        self._output_combo.clear()
        sel_idx = 0
        for i, dev in enumerate(dm.outputs()):
            self._output_combo.addItem(_format_dev(dev), dev.id)
            if curr_out and dev.id == curr_out:
                sel_idx = i
            elif not curr_out and suggested_out and dev.id == suggested_out:
                sel_idx = i
            elif default_out and dev.id == default_out.id:
                sel_idx = i
        self._output_combo.setCurrentIndex(sel_idx)
        self._output_combo.blockSignals(False)

        self._on_input(self._input_combo.currentIndex())
        self._on_output(self._output_combo.currentIndex())

    def _on_input(self, idx):
        if idx >= 0:
            did = self._input_combo.currentData()
            if did:
                self._controller.select_input(did)
                if self._controller.is_engine_running:
                    self._auto_restart()

    def _on_output(self, idx):
        if idx >= 0:
            did = self._output_combo.currentData()
            if did:
                self._controller.select_output(did)
                if self._controller.is_engine_running:
                    self._auto_restart()

    def _auto_restart(self):
        """Restart the engine with new device settings."""
        was_running = self._controller.is_engine_running
        if was_running:
            self._controller.stop_engine()
            try:
                self._controller.start_engine()
                self._start_btn.setText("Stop Engine")
                self._status_lbl.setText("Running")
                self._status_lbl.setStyleSheet("color: #4ade80; font-size: 13px; font-weight: bold;")
            except Exception as e:
                self._status_lbl.setText(f"Error: {e}")
                self._status_lbl.setStyleSheet("color: #f87171; font-size: 12px;")

    def _toggle(self):
        if self._controller.is_engine_running:
            self._controller.stop_engine()
            self._start_btn.setText("Start Engine")
            self._status_lbl.setText("Stopped")
            self._status_lbl.setStyleSheet("color: #f87171; font-size: 13px; font-weight: bold;")
        else:
            try:
                self._controller.start_engine()
                self._start_btn.setText("Stop Engine")
                self._status_lbl.setText("Running")
                self._status_lbl.setStyleSheet("color: #4ade80; font-size: 13px; font-weight: bold;")
            except Exception as e:
                self._status_lbl.setText(f"Error: {e}")
                self._status_lbl.setStyleSheet("color: #f87171; font-size: 12px;")

    def _update_levels(self):
        m = getattr(self._controller.engine.router, '_metrics', None)
        if m is None:
            return
        self._input_level.setValue(int(min(m.input_level.peak * 100, 100)))
        self._output_level.setValue(int(min(m.output_level.peak * 100, 100)))
