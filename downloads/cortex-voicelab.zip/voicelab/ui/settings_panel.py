import os
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QFrame,
    QSlider, QComboBox, QLineEdit, QCheckBox, QSpinBox, QGroupBox,
    QFileDialog, QMessageBox,
)
from PySide6.QtCore import Qt


def _app_dir():
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


SETTINGS_PATH = os.path.join(_app_dir(), "settings.json")


class SettingsPanel(QWidget):
    def __init__(self, controller, parent=None):
        super().__init__(parent)
        self._controller = controller
        self._dirty = False
        self._setup_ui()
        self._load()

    def _setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 24, 24, 24)
        layout.setSpacing(16)

        # Title row with save button
        header = QHBoxLayout()
        header.addWidget(QLabel("Settings", styleSheet="color: #ffffff; font-size: 22px; font-weight: bold;"))
        header.addStretch()

        self._save_btn = QPushButton("💾 Save Settings")
        self._save_btn.setStyleSheet("QPushButton { background: #7c7aff; color: #fff; border: none; border-radius: 6px; padding: 6px 16px; font-size: 12px; font-weight: bold; } QPushButton:hover { background: #6b6aff; }")
        self._save_btn.clicked.connect(self._save)
        header.addWidget(self._save_btn)

        self._status_lbl = QLabel("")
        self._status_lbl.setStyleSheet("color: #6b7280; font-size: 11px;")
        header.addWidget(self._status_lbl)

        layout.addLayout(header)

        # ── Audio ────────────────────────────────────────────────────────
        ag = QGroupBox("Audio")
        ag.setStyleSheet("QGroupBox { color: #fff; font-size: 13px; font-weight: bold; background: #252736; border: 1px solid #2a2d3a; border-radius: 10px; padding: 16px; padding-top: 32px; }")
        al = QVBoxLayout(ag)
        al.setSpacing(10)

        # Sample rate
        sr_row = QHBoxLayout()
        sr_row.addWidget(QLabel("Sample Rate", styleSheet="color: #d1d5db; font-size: 12px;"))
        sr_row.addStretch()
        self._sr_combo = QComboBox()
        self._sr_combo.addItems(["44100", "48000", "96000"])
        self._sr_combo.setStyleSheet("QComboBox { background: #1a1b2a; color: #fff; border: 1px solid #2a2d3a; border-radius: 4px; padding: 4px 8px; } QComboBox::drop-down { border: none; }")
        self._sr_combo.currentTextChanged.connect(lambda _: setattr(self, '_dirty', True))
        sr_row.addWidget(self._sr_combo)
        al.addLayout(sr_row)

        # Buffer size
        bs_row = QHBoxLayout()
        bs_row.addWidget(QLabel("Buffer Size", styleSheet="color: #d1d5db; font-size: 12px;"))
        bs_row.addStretch()
        self._buffer_spin = QSpinBox()
        self._buffer_spin.setRange(64, 2048)
        self._buffer_spin.setValue(512)
        self._buffer_spin.setSingleStep(64)
        self._buffer_spin.setStyleSheet("QSpinBox { background: #1a1b2a; color: #fff; border: 1px solid #2a2d3a; border-radius: 4px; padding: 4px 8px; }")
        self._buffer_spin.valueChanged.connect(lambda _: setattr(self, '_dirty', True))
        bs_row.addWidget(self._buffer_spin)
        al.addLayout(bs_row)

        # Latency
        lat_row = QHBoxLayout()
        lat_row.addWidget(QLabel("Target Latency", styleSheet="color: #d1d5db; font-size: 12px;"))
        lat_row.addStretch()
        self._latency_combo = QComboBox()
        self._latency_combo.addItems(["Low (5ms)", "Medium (10ms)", "High (20ms)"])
        self._latency_combo.setStyleSheet("QComboBox { background: #1a1b2a; color: #fff; border: 1px solid #2a2d3a; border-radius: 4px; padding: 4px 8px; } QComboBox::drop-down { border: none; }")
        self._latency_combo.currentIndexChanged.connect(lambda _: setattr(self, '_dirty', True))
        lat_row.addWidget(self._latency_combo)
        al.addLayout(lat_row)

        # Input gain
        gain_row = QHBoxLayout()
        gain_row.addWidget(QLabel("Mic Gain", styleSheet="color: #d1d5db; font-size: 12px;"))
        gain_row.addStretch()
        self._gain_slider = QSlider(Qt.Horizontal)
        self._gain_slider.setRange(0, 300)
        self._gain_slider.setValue(150)
        self._gain_slider.setFixedWidth(120)
        self._gain_slider.setStyleSheet("QSlider::groove:horizontal { height: 3px; background: #2a2d3a; } QSlider::handle:horizontal { background: #7c7aff; width: 12px; height: 12px; margin: -5px 0; border-radius: 6px; } QSlider::sub-page:horizontal { background: #7c7aff; }")
        self._gain_slider.valueChanged.connect(lambda v: (setattr(self, '_dirty', True), self._gain_lbl.setText(f"{v/100:.1f}x")))
        gain_row.addWidget(self._gain_slider)
        self._gain_lbl = QLabel("1.5x")
        self._gain_lbl.setStyleSheet("color: #d1d5db; font-size: 11px; min-width: 28px;")
        gain_row.addWidget(self._gain_lbl)
        al.addLayout(gain_row)

        layout.addWidget(ag)

        # ── Voice Conversion ─────────────────────────────────────────────
        vg = QGroupBox("Voice Conversion")
        vg.setStyleSheet("QGroupBox { color: #fff; font-size: 13px; font-weight: bold; background: #252736; border: 1px solid #2a2d3a; border-radius: 10px; padding: 16px; padding-top: 32px; }")
        vl = QVBoxLayout(vg)
        vl.setSpacing(10)

        self._vc_cuda = QCheckBox("CUDA Acceleration (if available)")
        self._vc_cuda.setStyleSheet("QCheckBox { color: #d1d5db; font-size: 12px; } QCheckBox::indicator { width: 16px; height: 16px; border-radius: 3px; border: 2px solid #3a3d5c; } QCheckBox::indicator:checked { background: #7c7aff; border-color: #7c7aff; }")
        self._vc_cuda.toggled.connect(lambda _: setattr(self, '_dirty', True))
        vl.addWidget(self._vc_cuda)

        # Models dir
        md_row = QHBoxLayout()
        md_row.addWidget(QLabel("Models Folder", styleSheet="color: #d1d5db; font-size: 12px;"))
        md_row.addStretch()
        self._models_dir_edit = QLineEdit()
        self._models_dir_edit.setPlaceholderText("Select folder with .onnx models…")
        self._models_dir_edit.setStyleSheet("QLineEdit { background: #1a1b2a; color: #fff; border: 1px solid #2a2d3a; border-radius: 4px; padding: 4px 8px; }")
        self._models_dir_edit.textChanged.connect(lambda _: setattr(self, '_dirty', True))
        md_row.addWidget(self._models_dir_edit, 1)
        browse_btn = QPushButton("Browse")
        browse_btn.setFixedHeight(26)
        browse_btn.setStyleSheet("QPushButton { background: #2a2d3a; color: #d1d5db; border: 1px solid #3a3d5c; border-radius: 4px; padding: 3px 10px; font-size: 11px; } QPushButton:hover { background: #3a3d5c; }")
        browse_btn.clicked.connect(self._browse_models)
        md_row.addWidget(browse_btn)
        vl.addLayout(md_row)

        # Model selector
        model_row = QHBoxLayout()
        model_row.addWidget(QLabel("Active Model", styleSheet="color: #d1d5db; font-size: 12px;"))
        model_row.addStretch()
        self._model_combo = QComboBox()
        self._model_combo.setMinimumWidth(180)
        self._model_combo.setStyleSheet("QComboBox { background: #1a1b2a; color: #fff; border: 1px solid #2a2d3a; border-radius: 4px; padding: 4px 8px; } QComboBox::drop-down { border: none; } QComboBox QAbstractItemView { background: #1a1b2a; color: #fff; selection-background-color: #3a3d5c; }")
        model_row.addWidget(self._model_combo)
        vl.addLayout(model_row)

        # Provider + perf info
        self._provider_lbl = QLabel("Provider: CPU")
        self._provider_lbl.setStyleSheet("color: #6b7280; font-size: 11px;")
        vl.addWidget(self._provider_lbl)

        self._perf_lbl = QLabel("")
        self._perf_lbl.setStyleSheet("color: #6b7280; font-size: 11px;")
        vl.addWidget(self._perf_lbl)

        layout.addWidget(vg)

        # ── General ──────────────────────────────────────────────────────
        gg = QGroupBox("General")
        gg.setStyleSheet("QGroupBox { color: #fff; font-size: 13px; font-weight: bold; background: #252736; border: 1px solid #2a2d3a; border-radius: 10px; padding: 16px; padding-top: 32px; }")
        gl = QVBoxLayout(gg)
        gl.setSpacing(10)

        self._auto_start_cb = QCheckBox("Auto-start audio engine on launch")
        self._auto_start_cb.setStyleSheet("QCheckBox { color: #d1d5db; font-size: 12px; } QCheckBox::indicator { width: 16px; height: 16px; border-radius: 3px; border: 2px solid #3a3d5c; } QCheckBox::indicator:checked { background: #7c7aff; border-color: #7c7aff; }")
        self._auto_start_cb.toggled.connect(lambda _: setattr(self, '_dirty', True))
        gl.addWidget(self._auto_start_cb)

        self._minimized_cb = QCheckBox("Start minimized to system tray")
        self._minimized_cb.setStyleSheet("QCheckBox { color: #d1d5db; font-size: 12px; } QCheckBox::indicator { width: 16px; height: 16px; border-radius: 3px; border: 2px solid #3a3d5c; } QCheckBox::indicator:checked { background: #7c7aff; border-color: #7c7aff; }")
        self._minimized_cb.toggled.connect(lambda _: setattr(self, '_dirty', True))
        gl.addWidget(self._minimized_cb)

        self._live_cb = QCheckBox("Enable live playback on start")
        self._live_cb.setStyleSheet("QCheckBox { color: #d1d5db; font-size: 12px; } QCheckBox::indicator { width: 16px; height: 16px; border-radius: 3px; border: 2px solid #3a3d5c; } QCheckBox::indicator:checked { background: #7c7aff; border-color: #7c7aff; }")
        self._live_cb.toggled.connect(lambda _: setattr(self, '_dirty', True))
        gl.addWidget(self._live_cb)

        layout.addWidget(gg)
        layout.addStretch()

    # ── load / save ─────────────────────────────────────────────────────

    def _load(self):
        s = self._controller.load_settings(SETTINGS_PATH)

        self._sr_combo.setCurrentText(str(s.sample_rate))
        self._buffer_spin.setValue(s.buffer_size)
        lat_map = {0.005: 0, 0.01: 1, 0.02: 2}
        self._latency_combo.setCurrentIndex(lat_map.get(s.latency, 1))
        self._gain_slider.setValue(int(s.input_gain * 100))
        self._gain_lbl.setText(f"{s.input_gain:.1f}x")
        self._vc_cuda.setChecked(s.vc_cuda)
        self._models_dir_edit.setText(s.vc_models_dir)
        self._auto_start_cb.setChecked(s.auto_start_engine)
        self._minimized_cb.setChecked(s.start_minimized)
        self._live_cb.setChecked(s.live_playback_on_start)

        # Refresh model list from dir
        if s.vc_models_dir:
            self._controller.vc_models.set_models_dir(s.vc_models_dir)
        self._refresh_model_list(s.vc_model)

        cuda_ok = self._controller.vc_models.cuda_available
        is_cuda = s.vc_cuda and cuda_ok
        self._provider_lbl.setText(f"Provider: {'CUDA' if is_cuda else 'CPU'} {'✓' if cuda_ok else '(CUDA unavailable)'}")

        self._dirty = False

    def _save(self):
        s = self._controller.engine.settings
        s.sample_rate = int(self._sr_combo.currentText())
        s.buffer_size = self._buffer_spin.value()
        lat_map = {0: 0.005, 1: 0.01, 2: 0.02}
        s.latency = lat_map.get(self._latency_combo.currentIndex(), 0.01)
        s.input_gain = self._gain_slider.value() / 100.0
        s.vc_cuda = self._vc_cuda.isChecked()
        s.vc_models_dir = self._models_dir_edit.text()
        s.vc_model = self._model_combo.currentText()
        s.auto_start_engine = self._auto_start_cb.isChecked()
        s.start_minimized = self._minimized_cb.isChecked()
        s.live_playback_on_start = self._live_cb.isChecked()

        # Apply to engine
        self._controller.engine.input_gain = s.input_gain
        self._controller.engine.router._config.buffer_size = s.buffer_size
        self._controller.engine.router._config.sample_rate = s.sample_rate
        self._controller.engine.router._config.latency = s.latency

        self._controller.save_settings(SETTINGS_PATH)
        self._dirty = False
        self._status_lbl.setText("💾 Settings saved")
        self._status_lbl.setStyleSheet("color: #4ade80; font-size: 11px;")

    def _browse_models(self):
        d = QFileDialog.getExistingDirectory(self, "Select Models Folder")
        if d:
            self._models_dir_edit.setText(d)
            self._controller.vc_models.set_models_dir(d)
            self._refresh_model_list("")
            self._dirty = True

    def _refresh_model_list(self, select: str = ""):
        self._model_combo.clear()
        names = self._controller.vc_models.model_names()
        if names:
            self._model_combo.addItems(names)
            if select in names:
                self._model_combo.setCurrentText(select)
        else:
            self._model_combo.addItem("— no models found —")
