from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QScrollArea,
    QGridLayout, QFrame, QSlider
)
from PySide6.QtCore import Qt


EFFECTS = [
    ("Radio", "📻", "Narrow bandwidth radio communication"),
    ("Walkie Talkie", "📡", "Push-to-talk walkie talkie sound"),
    ("Military", "🎖️", "Military grade tactical comms"),
    ("Broadcast", "📺", "Professional broadcast quality"),
    ("Robot", "🤖", "Mechanical robotic voice"),
    ("Megaphone", "📣", "Loud megaphone projection"),
    ("Cyberpunk", "💻", "Futuristic cybernetic filter"),
    ("Intercom", "🔊", "Intercom speaker system"),
]


class EffectCard(QFrame):
    def __init__(self, name: str, icon: str, desc: str, parent=None):
        super().__init__(parent)
        self.effect_name = name
        self.setFixedSize(200, 140)
        self.setCursor(Qt.PointingHandCursor)
        self.setStyleSheet("""
            EffectCard {
                background-color: #252736; border: 2px solid #2a2d3a;
                border-radius: 12px; padding: 12px;
            }
            EffectCard:hover {
                border-color: #7c7aff; background-color: #2a2d3a;
            }
        """)
        layout = QVBoxLayout(self)
        layout.setSpacing(8)
        layout.setAlignment(Qt.AlignCenter)

        icon_lbl = QLabel(icon)
        icon_lbl.setStyleSheet("color: #7c7aff; font-size: 28px;")
        icon_lbl.setAlignment(Qt.AlignCenter)
        layout.addWidget(icon_lbl)

        name_lbl = QLabel(name)
        name_lbl.setStyleSheet("color: #ffffff; font-size: 14px; font-weight: bold;")
        name_lbl.setAlignment(Qt.AlignCenter)
        layout.addWidget(name_lbl)

        desc_lbl = QLabel(desc)
        desc_lbl.setStyleSheet("color: #6b7280; font-size: 10px;")
        desc_lbl.setAlignment(Qt.AlignCenter)
        desc_lbl.setWordWrap(True)
        layout.addWidget(desc_lbl)


class EffectsPanel(QWidget):
    def __init__(self, controller, parent=None):
        super().__init__(parent)
        self._controller = controller
        self._setup_ui()

    def _setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(32, 32, 32, 32)
        layout.setSpacing(24)

        title = QLabel("Audio Effects")
        title.setStyleSheet("color: #ffffff; font-size: 24px; font-weight: bold;")
        layout.addWidget(title)

        desc = QLabel("Apply standalone audio effects to your voice")
        desc.setStyleSheet("color: #6b7280; font-size: 13px;")
        layout.addWidget(desc)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setStyleSheet("QScrollArea { border: none; background: transparent; }")

        scroll_content = QWidget()
        scroll_content.setStyleSheet("background: transparent;")

        grid = QGridLayout(scroll_content)
        grid.setSpacing(16)

        row, col = 0, 0
        for name, icon, desc_text in EFFECTS:
            card = EffectCard(name, icon, desc_text)
            grid.addWidget(card, row, col)
            col += 1
            if col > 3:
                col = 0
                row += 1

        scroll.setWidget(scroll_content)
        layout.addWidget(scroll)
