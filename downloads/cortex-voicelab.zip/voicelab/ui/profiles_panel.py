from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QScrollArea,
    QGridLayout, QFrame, QLineEdit, QPushButton,
)
from PySide6.QtCore import Qt, QTimer
from audio_engine.models.profile import Profile


CATEGORY_ICONS = {
    "volume-down": "🔊", "volume-up": "🔉", "military-tech": "🎖️",
    "radio": "📻", "storm": "🌪️", "android": "🤖", "cyber": "💻",
    "record-voice-over": "🎙️", "mic": "🎤",
}

CATEGORY_NAMES = {"voice": "Voice", "character": "Character"}


class ActiveBar(QFrame):
    def __init__(self, controller, parent=None):
        super().__init__(parent)
        self._controller = controller
        self.setFixedHeight(80)
        self.setStyleSheet("ActiveBar { background-color: #252736; border: 1px solid #2a2d3a; border-radius: 10px; padding: 12px 20px; }")
        layout = QHBoxLayout(self)
        layout.setSpacing(24)
        pi = QVBoxLayout()
        pi.setSpacing(2)
        pi.addWidget(QLabel("ACTIVE PROFILE", styleSheet="color: #6b7280; font-size: 9px; letter-spacing: 1px;"))
        self._profile_lbl = QLabel("None")
        self._profile_lbl.setStyleSheet("color: #ffffff; font-size: 18px; font-weight: bold;")
        pi.addWidget(self._profile_lbl)
        self._blueprint_lbl = QLabel("")
        self._blueprint_lbl.setStyleSheet("color: #7c7aff; font-size: 11px;")
        pi.addWidget(self._blueprint_lbl)
        layout.addLayout(pi)
        s = QFrame()
        s.setFrameShape(QFrame.VLine)
        s.setStyleSheet("background: #2a2d3a; max-width: 1px;")
        layout.addWidget(s)
        ei = QVBoxLayout()
        ei.setSpacing(2)
        ei.addWidget(QLabel("ENGINE", styleSheet="color: #6b7280; font-size: 9px; letter-spacing: 1px;"))
        self._input_lbl = QLabel("Input: \u2014")
        self._input_lbl.setStyleSheet("color: #9ca3af; font-size: 11px;")
        ei.addWidget(self._input_lbl)
        self._output_lbl = QLabel("Output: \u2014")
        self._output_lbl.setStyleSheet("color: #9ca3af; font-size: 11px;")
        ei.addWidget(self._output_lbl)
        self._latency_lbl = QLabel("Latency: \u2014")
        self._latency_lbl.setStyleSheet("color: #9ca3af; font-size: 11px;")
        ei.addWidget(self._latency_lbl)
        layout.addLayout(ei)
        layout.addStretch()
        self._status_badge = QLabel("\u25cf Idle")
        self._status_badge.setStyleSheet("color: #6b7280; font-size: 12px; font-weight: bold; padding: 4px 12px; border: 1px solid #2a2d3a; border-radius: 12px;")
        layout.addWidget(self._status_badge)
        self._timer = QTimer()
        self._timer.timeout.connect(self._refresh)
        self._timer.start(200)

    def _refresh(self):
        engine = self._controller.engine
        profile = engine.current_profile
        blueprint = engine.current_blueprint
        metrics = engine.router._metrics if hasattr(engine.router, '_metrics') else None
        self._profile_lbl.setText(profile or "None")
        self._blueprint_lbl.setText(blueprint or "")
        dev_in = engine.devices.get(engine.devices.selected_input_id)
        dev_out = engine.devices.get(engine.devices.selected_output_id)
        em = "\u2014"
        self._input_lbl.setText(f"Input:  {dev_in.name[:35] if dev_in else em}")
        self._output_lbl.setText(f"Output: {dev_out.name[:35] if dev_out else em}")
        if metrics:
            self._latency_lbl.setText(f"Latency: {metrics.latency_ms:.1f} ms")
            if metrics.is_active:
                self._status_badge.setText("\u25cf Running")
                self._status_badge.setStyleSheet("color: #4ade80; font-size: 12px; font-weight: bold; padding: 4px 12px; border: 1px solid #4ade80; border-radius: 12px;")
            else:
                self._status_badge.setText("\u25cf Idle")
                self._status_badge.setStyleSheet("color: #6b7280; font-size: 12px; font-weight: bold; padding: 4px 12px; border: 1px solid #2a2d3a; border-radius: 12px;")


class ProfileCard(QFrame):
    def __init__(self, profile: Profile, is_active: bool, on_click, parent=None):
        super().__init__(parent)
        self.profile = profile
        self._on_click = on_click
        self._is_active = is_active
        self.setFixedSize(200, 170)
        self.setCursor(Qt.PointingHandCursor)
        self.setStyleSheet(self._style())
        self._build()

    def _style(self) -> str:
        border = "#7c7aff" if self._is_active else "#2a2d3a"
        bg = "#2a2d3a" if self._is_active else "#252736"
        return f"ProfileCard {{ background-color: {bg}; border: 2px solid {border}; border-radius: 14px; padding: 16px; }} ProfileCard:hover {{ border-color: #7c7aff; background-color: #2a2d3a; }}"

    def _build(self):
        layout = QVBoxLayout(self)
        layout.setSpacing(6)
        layout.setAlignment(Qt.AlignCenter)
        if self._is_active:
            badge = QLabel("\u25cf ACTIVE")
            badge.setStyleSheet("color: #7c7aff; font-size: 9px; font-weight: bold; letter-spacing: 1px;")
            badge.setAlignment(Qt.AlignCenter)
            layout.addWidget(badge)
        icon = CATEGORY_ICONS.get(self.profile.icon, "\U0001f3a4")
        icon_lbl = QLabel(icon)
        icon_lbl.setStyleSheet("font-size: 32px;")
        icon_lbl.setAlignment(Qt.AlignCenter)
        layout.addWidget(icon_lbl)
        name_lbl = QLabel(self.profile.display_name)
        name_lbl.setStyleSheet("color: #ffffff; font-size: 15px; font-weight: bold;")
        name_lbl.setAlignment(Qt.AlignCenter)
        layout.addWidget(name_lbl)
        desc = self.profile.description[:45]
        if len(self.profile.description) > 45:
            desc += "\u2026"
        desc_lbl = QLabel(desc)
        desc_lbl.setStyleSheet("color: #6b7280; font-size: 10px;")
        desc_lbl.setAlignment(Qt.AlignCenter)
        desc_lbl.setWordWrap(True)
        layout.addWidget(desc_lbl)
        cat = CATEGORY_NAMES.get(self.profile.category, self.profile.category.capitalize())
        cat_lbl = QLabel(cat)
        cat_lbl.setStyleSheet("color: #4b5563; font-size: 9px; padding: 2px 8px; border: 1px solid #2a2d3a; border-radius: 8px;")
        cat_lbl.setAlignment(Qt.AlignCenter)
        layout.addWidget(cat_lbl)

    def set_active(self, active: bool):
        self._is_active = active
        self.setStyleSheet(self._style())

    def mousePressEvent(self, event):
        if self._on_click:
            self._on_click(self.profile.name)
        super().mousePressEvent(event)


class CategoryTab(QPushButton):
    def __init__(self, label: str, key: str, parent=None):
        super().__init__(label, parent)
        self.cat_key = key
        self.setCheckable(True)
        self.setFixedHeight(30)
        self.setCursor(Qt.PointingHandCursor)
        self.setStyleSheet("QPushButton { background: transparent; color: #6b7280; border: none; border-radius: 6px; padding: 4px 14px; font-size: 12px; } QPushButton:hover { color: #d1d5db; background: #2a2d3a; } QPushButton:checked { color: #ffffff; background: #3a3d5c; font-weight: bold; }")


class ProfilesPanel(QWidget):
    def __init__(self, controller, parent=None):
        super().__init__(parent)
        self._controller = controller
        self._category = "all"
        self._search = ""
        self._cards: list[ProfileCard] = []
        self._setup_ui()

    def _setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 24, 24, 24)
        layout.setSpacing(16)
        layout.addWidget(QLabel("Voice Profiles", styleSheet="color: #ffffff; font-size: 22px; font-weight: bold;"))
        self._active_bar = ActiveBar(self._controller)
        layout.addWidget(self._active_bar)

        filter_row = QHBoxLayout()
        filter_row.setSpacing(12)
        self._search_input = QLineEdit()
        self._search_input.setPlaceholderText("Search profiles\u2026")
        self._search_input.setFixedHeight(32)
        self._search_input.setStyleSheet("QLineEdit { background: #252736; color: #ffffff; border: 1px solid #2a2d3a; border-radius: 8px; padding: 6px 14px; font-size: 13px; } QLineEdit:focus { border-color: #7c7aff; }")
        self._search_input.textChanged.connect(self._on_search)
        filter_row.addWidget(self._search_input)
        self._cat_tabs = {}
        for label, key in [("All", "all"), ("Voice", "voice"), ("Character", "character")]:
            tab = CategoryTab(label, key)
            tab.clicked.connect(lambda _, k=key: self._set_category(k))
            filter_row.addWidget(tab)
            self._cat_tabs[key] = tab
        filter_row.addStretch()
        layout.addLayout(filter_row)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setStyleSheet("QScrollArea { border: none; background: transparent; }")
        self._grid_content = QWidget()
        self._grid_content.setStyleSheet("background: transparent;")
        self._grid = QGridLayout(self._grid_content)
        self._grid.setSpacing(16)
        self._grid.setAlignment(Qt.AlignLeft | Qt.AlignTop)
        scroll.setWidget(self._grid_content)
        layout.addWidget(scroll, 1)

        self._cat_tabs["all"].setChecked(True)
        self._rebuild_grid()

    def _on_search(self, text: str):
        self._search = text.lower().strip()
        self._rebuild_grid()

    def _set_category(self, key: str):
        self._category = key
        for k, tab in self._cat_tabs.items():
            tab.setChecked(k == key)
        self._rebuild_grid()

    def _rebuild_grid(self):
        # Remove all widgets from grid
        for card in self._cards:
            self._grid.removeWidget(card)
            card.deleteLater()
        self._cards.clear()

        engine = self._controller.engine
        active_name = engine.current_profile
        active_name_lower = active_name.lower() if active_name else ""

        profiles = engine.profiles.all
        row, col = 0, 0
        for profile in profiles:
            if self._category != "all" and profile.category != self._category:
                continue
            if self._search:
                haystack = f"{profile.display_name} {profile.description} {profile.category}".lower()
                if self._search not in haystack:
                    continue
            is_active = bool(active_name) and profile.display_name.lower() == active_name_lower
            card = ProfileCard(profile, is_active, self._on_card_clicked)
            self._grid.addWidget(card, row, col)
            self._cards.append(card)
            col += 1
            if col > 3:
                col = 0
                row += 1

    def _on_card_clicked(self, name: str):
        self._controller.apply_profile(name)
        self._rebuild_grid()
