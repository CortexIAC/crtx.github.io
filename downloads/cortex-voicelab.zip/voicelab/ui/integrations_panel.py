from PySide6.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QFrame, QCheckBox
from PySide6.QtCore import Qt, QTimer


class IntegrationCard(QFrame):
    def __init__(self, title: str, icon: str, desc: str, parent=None):
        super().__init__(parent)
        self.setStyleSheet("QFrame { background-color: #252736; border: 1px solid #2a2d3a; border-radius: 10px; padding: 20px; }")
        layout = QVBoxLayout(self)
        layout.setSpacing(8)

        hl = QHBoxLayout()
        hl.addWidget(QLabel(icon, styleSheet="font-size: 28px;"))
        hl.addWidget(QLabel(title, styleSheet="color: #ffffff; font-size: 16px; font-weight: bold;"))
        hl.addStretch()

        self._status = QLabel("\u25cf Disconnected")
        self._status.setStyleSheet("color: #6b7280; font-size: 11px; font-weight: bold;")
        hl.addWidget(self._status)
        layout.addLayout(hl)

        self._desc = QLabel(desc)
        self._desc.setStyleSheet("color: #9ca3af; font-size: 12px;")
        self._desc.setWordWrap(True)
        layout.addWidget(self._desc)

    def set_status(self, text: str, color: str = "#6b7280"):
        self._status.setText(f"\u25cf {text}")
        self._status.setStyleSheet(f"color: {color}; font-size: 11px; font-weight: bold;")


class VoiceModCard(IntegrationCard):
    def __init__(self, bridge, parent=None):
        self._bridge = bridge
        super().__init__(
            "VoiceMod", "\U0001f3a4",
            "Route audio through VoiceMod for professional voice processing.\n"
            "Requires VoiceMod to be installed and running.",
            parent,
        )

        self._toggle = QPushButton("Enable VoiceMod Bridge")
        self._toggle.setCheckable(True)
        self._toggle.setFixedHeight(36)
        self._toggle.setStyleSheet(
            "QPushButton { background: #2a2d3a; color: #9ca3af; border: 1px solid #3a3d5c; "
            "border-radius: 6px; padding: 8px 20px; font-size: 13px; } "
            "QPushButton:hover { background: #3a3d5c; color: #fff; } "
            "QPushButton:checked { background: #7c7aff; color: #fff; border-color: #7c7aff; }"
        )
        self._toggle.toggled.connect(self._on_toggle)
        self.layout().addWidget(self._toggle)
        self._detected = False

        self._info = QLabel("")
        self._info.setStyleSheet("color: #6b7280; font-size: 11px;")
        self.layout().addWidget(self._info)

        self._timer = QTimer()
        self._timer.timeout.connect(self._refresh)
        self._timer.start(2000)

    def _refresh(self):
        engine = self._bridge
        if engine is None:
            return
        installed = engine.is_installed
        self._detected = installed
        if installed:
            name = engine.device_name
            self._info.setText(f"Detected: {name}")
            self._info.setStyleSheet("color: #4ade80; font-size: 11px;")
            self.set_status("Ready", "#4ade80")
        else:
            self._info.setText("VoiceMod virtual devices not found. Install VoiceMod first.")
            self._info.setStyleSheet("color: #f87171; font-size: 11px;")
            self.set_status("Not detected", "#f87171")
            self._toggle.setChecked(False)

    def _on_toggle(self, checked):
        if not self._detected and checked:
            self._toggle.setChecked(False)
            return
        self._bridge.enabled = checked


class IntegrationsPanel(QWidget):
    def __init__(self, controller, parent=None):
        super().__init__(parent)
        self._controller = controller
        self._setup_ui()

    def _setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 24, 24, 24)
        layout.setSpacing(16)

        layout.addWidget(QLabel("Integrations", styleSheet="color: #ffffff; font-size: 22px; font-weight: bold;"))
        layout.addWidget(QLabel("Connect VoiceLab with external audio applications",
                                styleSheet="color: #6b7280; font-size: 13px;"))

        vm_card = VoiceModCard(self._controller.engine.voicemod)
        layout.addWidget(vm_card)

        obs_card = IntegrationCard(
            "OBS Studio", "\U0001f4fa",
            "Automatic profile switching when OBS is recording or streaming.\n"
            "Detects OBS running status and switches profiles seamlessly.",
        )
        layout.addWidget(obs_card)

        discord_card = IntegrationCard(
            "Discord", "\U0001f4ac",
            "Virtual microphone integration for Discord voice channels.\n"
            "Route processed audio directly to Discord as a microphone.",
        )
        layout.addWidget(discord_card)

        layout.addStretch()
