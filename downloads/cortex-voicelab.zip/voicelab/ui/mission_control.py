"""Mission Control — live telemetry dashboard for the audio engine."""

import time
import threading
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QFrame, QGridLayout,
    QProgressBar,
)
from PySide6.QtCore import Qt, QTimer, QRectF, QPointF
from PySide6.QtGui import QPainter, QPen, QBrush, QColor, QFont, QLinearGradient


# ---------------------------------------------------------------------------
# Gauge widget — circular / arc gauge for live values
# ---------------------------------------------------------------------------

class ArcGauge(QWidget):
    """A compact arc gauge showing a value on a coloured arc."""

    def __init__(self, label: str, unit: str = "", min_v: float = 0, max_v: float = 100,
                 warn: float = 70, crit: float = 90, parent=None):
        super().__init__(parent)
        self.setFixedSize(100, 100)
        self._label = label
        self._unit = unit
        self._min = min_v
        self._max = max_v
        self._warn = warn
        self._crit = crit
        self._value = 0.0
        self._text = "—"

    def set_value(self, v: float, text: str = ""):
        self._value = max(self._min, min(self._max, v))
        self._text = text or f"{v:.1f}"
        self.update()

    def paintEvent(self, event):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        w, h = self.width(), self.height()
        cx, cy, r = w / 2, h / 2 + 4, 38

        # Background arc
        p.setPen(QPen(QColor("#2a2d3a"), 6, Qt.SolidLine, Qt.RoundCap))
        p.drawArc(QRectF(cx - r, cy - r, r * 2, r * 2), 210 * 16, 120 * 16)

        # Value arc
        pct = (self._value - self._min) / (self._max - self._min) if self._max > self._min else 0
        span = int(min(1.0, max(0.0, pct)) * 120 * 16)

        if pct >= self._crit / 100:
            color = "#f87171"
        elif pct >= self._warn / 100:
            color = "#fbbf24"
        else:
            color = "#4ade80"
        p.setPen(QPen(QColor(color), 6, Qt.SolidLine, Qt.RoundCap))
        p.drawArc(QRectF(cx - r, cy - r, r * 2, r * 2), 210 * 16, span)

        # Centre text
        p.setPen(QPen(QColor("#ffffff")))
        font = QFont("Segoe UI", 14, QFont.Bold)
        p.setFont(font)
        p.drawText(QRectF(0, cy - 22, w, 24), Qt.AlignCenter, self._text)

        # Unit
        p.setPen(QPen(QColor("#6b7280")))
        font_s = QFont("Segoe UI", 8)
        p.setFont(font_s)
        p.drawText(QRectF(0, cy + 2, w, 14), Qt.AlignCenter, self._unit)

        # Label
        p.drawText(QRectF(0, h - 18, w, 14), Qt.AlignCenter, self._label)


# ---------------------------------------------------------------------------
# MetricCard — a compact stat card with label + value + optional mini bar
# ---------------------------------------------------------------------------

class MetricCard(QFrame):
    def __init__(self, label: str, value: str = "—", accent: str = "#7c7aff", parent=None):
        super().__init__(parent)
        self.setStyleSheet(f"MetricCard {{ background-color: #1e1f2e; border: 1px solid #2a2d3a; border-radius: 10px; padding: 12px; }}")
        self._accent = accent
        layout = QVBoxLayout(self)
        layout.setSpacing(4)
        layout.setContentsMargins(12, 10, 12, 10)

        self._label_w = QLabel(label)
        self._label_w.setStyleSheet("color: #6b7280; font-size: 9px; letter-spacing: 0.5px;")
        layout.addWidget(self._label_w)

        self._value_w = QLabel(value)
        self._value_w.setStyleSheet(f"color: #ffffff; font-size: 20px; font-weight: bold;")
        layout.addWidget(self._value_w)

        self._sub_w = QLabel("")
        self._sub_w.setStyleSheet("color: #4b5563; font-size: 10px;")
        layout.addWidget(self._sub_w)

    def set(self, value: str, sub: str = ""):
        self._value_w.setText(value)
        self._sub_w.setText(sub)


# ---------------------------------------------------------------------------
# HealthBadge — coloured status indicator
# ---------------------------------------------------------------------------

class HealthBadge(QFrame):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedSize(140, 48)
        self._status = "offline"
        self._text = "Offline"
        self._color = "#6b7280"

    def set_health(self, status: str, text: str = ""):
        self._status = status
        self._text = text or status.capitalize()
        colors = {"critical": "#f87171", "warn": "#fbbf24", "good": "#4ade80", "offline": "#6b7280"}
        self._color = colors.get(status, "#6b7280")
        self.update()

    def paintEvent(self, event):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        w, h = self.width(), self.height()

        # Background
        p.setBrush(QBrush(QColor(self._color + "18" if len(self._color) == 7 else "#1e1f2e")))
        p.setPen(QPen(QColor(self._color), 1))
        p.drawRoundedRect(0, 0, w, h, 8, 8)

        # Dot
        p.setBrush(QBrush(QColor(self._color)))
        p.setPen(Qt.NoPen)
        p.drawEllipse(14, h / 2 - 5, 10, 10)

        # Text
        p.setPen(QPen(QColor("#ffffff")))
        font = QFont("Segoe UI", 12, QFont.Bold)
        p.setFont(font)
        p.drawText(QRectF(32, 0, w - 36, h), Qt.AlignVCenter, self._text.upper())


# ---------------------------------------------------------------------------
# MissionControl — the full telemetry panel
# ---------------------------------------------------------------------------

class MissionControlPanel(QWidget):
    def __init__(self, controller, parent=None):
        super().__init__(parent)
        self._controller = controller
        self._prev_dropped = 0
        self._cpu_times = []
        self._setup_ui()
        self._timer = QTimer()
        self._timer.timeout.connect(self._refresh)
        self._timer.start(200)

    def _setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 24, 24, 24)
        layout.setSpacing(16)

        # ── Header ──────────────────────────────────────────────────────
        header = QHBoxLayout()
        title = QLabel("MISSION CONTROL")
        title.setStyleSheet("color: #ffffff; font-size: 22px; font-weight: bold; letter-spacing: 2px;")
        header.addWidget(title)

        self._health = HealthBadge()
        header.addWidget(self._health)
        header.addStretch()
        layout.addLayout(header)

        # ── Status row ──────────────────────────────────────────────────
        status_row = QHBoxLayout()
        status_row.setSpacing(12)

        self._profile_card = MetricCard("PROFILE", "—", "#a78bfa")
        status_row.addWidget(self._profile_card)

        self._blueprint_card = MetricCard("BLUEPRINT", "—", "#7c7aff")
        status_row.addWidget(self._blueprint_card)

        self._model_card = MetricCard("VC MODEL", "—", "#ff6b9d")
        status_row.addWidget(self._model_card)

        self._engine_card = MetricCard("ENGINE", "Stopped", "#6b7280")
        status_row.addWidget(self._engine_card)

        layout.addLayout(status_row)

        # ── Devices row ─────────────────────────────────────────────────
        dev_row = QHBoxLayout()
        dev_row.setSpacing(12)

        self._input_card = MetricCard("INPUT DEVICE", "—", "#4ade80")
        dev_row.addWidget(self._input_card)

        self._output_card = MetricCard("OUTPUT DEVICE", "—", "#4ade80")
        dev_row.addWidget(self._output_card)

        layout.addLayout(dev_row)

        # ── Gauges row ──────────────────────────────────────────────────
        gauge_row = QHBoxLayout()
        gauge_row.setSpacing(8)
        gauge_row.setAlignment(Qt.AlignCenter)

        self._latency_gauge = ArcGauge("Latency", "ms", 0, 100, 50, 75)
        gauge_row.addWidget(self._latency_gauge)

        self._cpu_gauge = ArcGauge("CPU", "%", 0, 100, 70, 90)
        gauge_row.addWidget(self._cpu_gauge)

        self._gpu_gauge = ArcGauge("GPU", "%", 0, 100, 70, 90)
        gauge_row.addWidget(self._gpu_gauge)

        self._vram_gauge = ArcGauge("VRAM", "%", 0, 100, 70, 90)
        gauge_row.addWidget(self._vram_gauge)

        self._drop_gauge = ArcGauge("Drops", "fr", 0, 500, 50, 100)
        gauge_row.addWidget(self._drop_gauge)

        layout.addLayout(gauge_row)

        # ── Detail bars row ─────────────────────────────────────────────
        detail_row = QHBoxLayout()
        detail_row.setSpacing(12)

        # Latency bar
        lat_frame = QFrame()
        lat_frame.setStyleSheet("QFrame { background-color: #1e1f2e; border: 1px solid #2a2d3a; border-radius: 10px; padding: 12px; }")
        lat_l = QVBoxLayout(lat_frame)
        lat_l.setSpacing(4)
        lat_l.addWidget(QLabel("PIPELINE LATENCY", styleSheet="color: #6b7280; font-size: 9px; letter-spacing: 0.5px;"))
        self._latency_bar = QProgressBar()
        self._latency_bar.setRange(0, 100)
        self._latency_bar.setTextVisible(True)
        self._latency_bar.setFixedHeight(18)
        self._latency_bar.setStyleSheet("QProgressBar { background: #2a2d3a; border: none; border-radius: 4px; text-align: center; font-size: 10px; color: #fff; } QProgressBar::chunk { background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #4ade80, stop:0.5 #fbbf24, stop:1 #f87171); border-radius: 4px; }")
        lat_l.addWidget(self._latency_bar)
        self._latency_detail = QLabel("Processing: — | Buffer: — | Total: —")
        self._latency_detail.setStyleSheet("color: #4b5563; font-size: 10px;")
        lat_l.addWidget(self._latency_detail)
        detail_row.addWidget(lat_frame)

        # Dropped frames bar
        drop_frame = QFrame()
        drop_frame.setStyleSheet("QFrame { background-color: #1e1f2e; border: 1px solid #2a2d3a; border-radius: 10px; padding: 12px; }")
        drop_l = QVBoxLayout(drop_frame)
        drop_l.setSpacing(4)
        drop_l.addWidget(QLabel("DROPPED FRAMES", styleSheet="color: #6b7280; font-size: 9px; letter-spacing: 0.5px;"))
        self._drop_bar = QProgressBar()
        self._drop_bar.setRange(0, 500)
        self._drop_bar.setTextVisible(True)
        self._drop_bar.setFixedHeight(18)
        self._drop_bar.setStyleSheet("QProgressBar { background: #2a2d3a; border: none; border-radius: 4px; text-align: center; font-size: 10px; color: #fff; } QProgressBar::chunk { background: #f87171; border-radius: 4px; }")
        drop_l.addWidget(self._drop_bar)
        self._drop_detail = QLabel("Total: 0 | Rate: 0/s")
        self._drop_detail.setStyleSheet("color: #4b5563; font-size: 10px;")
        drop_l.addWidget(self._drop_detail)
        detail_row.addWidget(drop_frame)

        layout.addLayout(detail_row)
        layout.addStretch()

    # ── Refresh ─────────────────────────────────────────────────────────

    def _read_cpu(self) -> float:
        """Read CPU usage percentage."""
        try:
            import psutil
            return psutil.cpu_percent(interval=None)
        except ImportError:
            # Fallback: estimate from process time deltas
            t = time.process_time()
            self._cpu_times.append(t)
            if len(self._cpu_times) > 10:
                self._cpu_times.pop(0)
            if len(self._cpu_times) >= 2:
                dt = self._cpu_times[-1] - self._cpu_times[0]
                return min(100.0, dt / (len(self._cpu_times) * 0.2) * 100)
            return 0.0

    def _refresh(self):
        engine = self._controller.engine
        router = engine.router
        metrics = router._metrics if hasattr(router, '_metrics') else None

        # ── Profile / Blueprint / Model ─────────────────────────────────
        prof = engine.current_profile or "—"
        bp = engine.current_blueprint or "—"
        self._profile_card.set(prof)
        self._blueprint_card.set(bp)

        vcm = engine.vc_models.loaded_model
        if vcm:
            self._model_card.set(vcm.name, f"{vcm.file_size_mb} MB · {engine.vc_models.active_provider}")
        else:
            self._model_card.set("None", "No model loaded")

        # ── Engine ──────────────────────────────────────────────────────
        is_active = engine.is_active
        self._engine_card.set("Running" if is_active else "Stopped",
                              f"Buffer: {router._config.buffer_size} · {router._config.sample_rate} Hz")

        # ── Devices ─────────────────────────────────────────────────────
        dev_in = engine.devices.get(engine.devices.selected_input_id)
        dev_out = engine.devices.get(engine.devices.selected_output_id)
        self._input_card.set(dev_in.name[:35] if dev_in else "—")
        self._output_card.set(dev_out.name[:35] if dev_out else "—")

        # ── Metrics ─────────────────────────────────────────────────────
        if metrics:
            lat = metrics.latency_ms
            cum_drops = metrics.dropped_frames  # resets every 1000 frames
            recent_drops = cum_drops - self._prev_dropped
            self._prev_dropped = cum_drops
            if recent_drops < 0:
                recent_drops = cum_drops  # counter reset, use current

            self._latency_gauge.set_value(lat, f"{lat:.1f}")
            self._drop_gauge.set_value(min(cum_drops, 500), f"{cum_drops}")

            self._latency_bar.setValue(int(min(lat, 100)))
            self._latency_bar.setFormat(f"{lat:.1f} ms")
            infer_ms = getattr(metrics, 'inference_ms', 0)
            buf_ms = router._config.buffer_size / router._config.sample_rate * 1000
            self._latency_detail.setText(f"Processing: {lat:.1f} ms | Buffer: {buf_ms:.1f} ms | Total: {lat + buf_ms:.1f} ms")

            self._drop_bar.setValue(min(cum_drops, 500))
            self._drop_bar.setFormat(f"{cum_drops} in window")
            self._drop_detail.setText(f"In last 2s: {recent_drops * 5}/s (cumulative: {cum_drops})")
        else:
            self._latency_gauge.set_value(0, "—")
            self._drop_gauge.set_value(0, "0")

        # ── CPU ─────────────────────────────────────────────────────────
        cpu = self._read_cpu()
        self._cpu_gauge.set_value(cpu, f"{cpu:.0f}")

        # ── GPU / VRAM ──────────────────────────────────────────────────
        gpu_pct = 0.0
        vram_pct = 0.0
        # Try to read from VC performance monitor if available
        try:
            pipeline = engine.pipeline
            for eid in pipeline._effect_instances:
                eff = pipeline._effect_instances[eid]
                if hasattr(eff, 'perf_monitor'):
                    snap = eff.perf_monitor.last
                    gpu_pct = snap.gpu_util_pct
                    vram_pct = snap.vram_pct
                    break
        except Exception:
            pass

        self._gpu_gauge.set_value(gpu_pct, f"{gpu_pct:.0f}")
        self._vram_gauge.set_value(vram_pct, f"{vram_pct:.0f}")

        # ── Health ──────────────────────────────────────────────────────
        # Use recent drop rate (per-second) + latency for health
        drop_rate = recent_drops * 5  # recent_drops per 200ms -> per second
        if not is_active:
            self._health.set_health("offline", "Offline")
        elif drop_rate > 5 or lat > 75:
            self._health.set_health("critical", f"Critical ({drop_rate:.0f} drops/s)")
        elif drop_rate > 1 or lat > 50:
            self._health.set_health("warn", f"Warning ({drop_rate:.0f} drops/s)")
        else:
            self._health.set_health("good", f"Nominal ({drop_rate:.0f} drops/s)")
