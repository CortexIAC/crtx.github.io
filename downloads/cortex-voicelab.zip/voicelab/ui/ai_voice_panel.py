"""
AI Voice Panel — generates VoiceLab blueprints from natural language via CIE Router.
"""
import sys, os, json
from PySide6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel,
    QLineEdit, QPushButton, QTextEdit, QComboBox, QFrame, QMessageBox)
from PySide6.QtCore import Qt

sys.path.insert(0, os.path.expanduser("~/Desktop/programming/synapse-cie"))


class CIEVoicePanel(QWidget):
    """Panel for generating voice effects via CIE's multi-model Router."""

    def __init__(self, controller=None):
        super().__init__()
        self.controller = controller
        self.engine = None
        self._init_engine()
        self._build_ui()

    def _init_engine(self):
        try:
            from voicelab.cie_integration import CIEVoiceEngine
            self.engine = CIEVoiceEngine()
        except ImportError:
            self.engine = None

    def _build_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(12)

        # Header
        header = QLabel("AI Voice Generator")
        header.setStyleSheet("font-size:18px;font-weight:bold;color:#00ff9c;")
        layout.addWidget(header)

        desc = QLabel("Describe a voice style and CIE will generate the perfect effect chain.")
        desc.setStyleSheet("color:#888;font-size:12px;")
        desc.setWordWrap(True)
        layout.addWidget(desc)

        # Input
        layout.addWidget(QLabel("Voice Description"))
        self.input = QLineEdit()
        self.input.setPlaceholderText("e.g. 'make me sound like a robot from the 1950s'")
        self.input.setStyleSheet("padding:10px;background:#1a1a1a;color:#fff;border:1px solid #333;border-radius:6px;font-size:14px;")
        self.input.returnPressed.connect(self._generate)
        layout.addWidget(self.input)

        # Generate button
        btn_row = QHBoxLayout()
        self.gen_btn = QPushButton("Generate Blueprint")
        self.gen_btn.setStyleSheet("padding:10px 20px;background:#00ff9c;color:#000;font-weight:bold;border:none;border-radius:6px;")
        self.gen_btn.clicked.connect(self._generate)
        btn_row.addWidget(self.gen_btn)

        self.apply_btn = QPushButton("Apply to VoiceLab")
        self.apply_btn.setStyleSheet("padding:10px 20px;background:#1a1a1a;color:#888;border:1px solid #333;border-radius:6px;")
        self.apply_btn.clicked.connect(self._apply)
        self.apply_btn.setEnabled(False)
        btn_row.addWidget(self.apply_btn)
        layout.addLayout(btn_row)

        # Result display
        self.result = QTextEdit()
        self.result.setReadOnly(True)
        self.result.setStyleSheet("background:#0d0d0d;color:#ccc;border:1px solid #333;border-radius:6px;font-family:Courier New;font-size:12px;")
        self.result.setMinimumHeight(200)
        self.result.setText("Generated blueprint will appear here...")
        layout.addWidget(self.result)

        # Provider status
        status_frame = QFrame()
        status_frame.setStyleSheet("background:#111;border:1px solid #333;border-radius:6px;padding:8px;")
        status_layout = QHBoxLayout(status_frame)
        status_layout.setContentsMargins(8, 4, 8, 4)
        self.status_label = QLabel("CIE Router: checking...")
        self.status_label.setStyleSheet("color:#888;font-size:11px;")
        status_layout.addWidget(self.status_label)
        layout.addWidget(status_frame)

        self._update_status()

    def _update_status(self):
        if self.engine:
            avail = self.engine.available()
            providers = list(avail.keys())
            self.status_label.setText(f"CIE Router: {len(providers)} providers available ({', '.join(providers[:4])})")
        else:
            self.status_label.setText("CIE Router: not available")

    def _generate(self):
        text = self.input.text().strip()
        if not text:
            return

        self.result.setText("Generating with CIE Router...")
        self.gen_btn.setEnabled(False)
        self.gen_btn.setText("Generating...")

        try:
            if self.engine:
                blueprint = self.engine.generate_blueprint(text)
                self._current_blueprint = blueprint
                display = json.dumps(blueprint, indent=2)
                self.result.setText(display)
                self.apply_btn.setEnabled(True)
            else:
                self.result.setText("CIE engine unavailable. Install CIE or use manual presets.")
                self.apply_btn.setEnabled(False)
        except Exception as e:
            self.result.setText(f"Error: {e}")
        finally:
            self.gen_btn.setEnabled(True)
            self.gen_btn.setText("Generate Blueprint")

    def _apply(self):
        if not hasattr(self, '_current_blueprint') or not self.controller:
            return

        bp = self._current_blueprint
        try:
            # Create a blueprint file in VoiceLab's format
            app_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
            bp_dir = os.path.join(app_dir, "blueprints")
            os.makedirs(bp_dir, exist_ok=True)

            name = bp.get("name", self.input.text()[:20])
            filename = f"cie_{name.lower().replace(' ', '_')[:20]}.json"
            path = os.path.join(bp_dir, filename)

            # Convert to VoiceLab's Blueprint format
            voicelab_bp = {
                "name": name,
                "description": f"Generated by CIE: {self.input.text()}",
                "effects": {}
            }
            effect_chain = bp.get("effect_chain", [])
            effects = bp.get("effects", {})
            for effect_name in effect_chain:
                if effect_name in effects:
                    voicelab_bp["effects"][effect_name] = effects[effect_name]

            with open(path, "w") as f:
                json.dump(voicelab_bp, f, indent=2)

            QMessageBox.information(self, "Success", f"Blueprint saved as {filename}\nRestart VoiceLab or refresh to see it.")
            self.apply_btn.setText("Applied!")
        except Exception as e:
            QMessageBox.warning(self, "Error", str(e))
