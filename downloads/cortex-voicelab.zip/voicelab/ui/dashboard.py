from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QGridLayout,
    QProgressBar, QCheckBox, QSlider
)
from PySide6.QtCore import Qt, QTimer
import numpy as np


class LevelMeter(QWidget):
    def __init__(self, label: str, color: str = "#7c7aff", parent=None):
        super().__init__(parent)
        self.setFixedHeight(70)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(2)

        hl = QHBoxLayout()
        self.label = QLabel(label)
        self.label.setStyleSheet("color: #9ca3af; font-size: 11px;")
        hl.addWidget(self.label)
        self.value_lbl = QLabel("-inf dB")
        self.value_lbl.setStyleSheet("color: #6b7280; font-size: 10px;")
        hl.addWidget(self.value_lbl)
        hl.addStretch()
        layout.addLayout(hl)

        bar_layout = QHBoxLayout()
        self.left_bar = QProgressBar()
        self.left_bar.setRange(0, 100)
        self.left_bar.setTextVisible(False)
        self.left_bar.setFixedHeight(14)
        self.left_bar.setStyleSheet(f"QProgressBar {{ background: #2a2d3a; border-radius: 3px; }} QProgressBar::chunk {{ background: {color}; border-radius: 3px; }}")
        bar_layout.addWidget(self.left_bar)

        layout.addLayout(bar_layout)

    def set_level(self, left: float, right: float = 0.0):
        pct = int(min(max(left, right) * 100, 100))
        self.left_bar.setValue(pct)
        if max(left, right) > 0:
            db = 20 * np.log10(max(left, right))
            self.value_lbl.setText(f"{db:.1f} dB")
        else:
            self.value_lbl.setText("-inf dB")


class StatCard(QWidget):
    def __init__(self, title: str, value: str, parent=None):
        super().__init__(parent)
        self.setStyleSheet("background-color: #252736; border: 1px solid #2a2d3a; border-radius: 10px; padding: 12px;")
        layout = QVBoxLayout(self)
        layout.setSpacing(4)
        self.title_label = QLabel(title)
        self.title_label.setStyleSheet("color: #6b7280; font-size: 11px;")
        layout.addWidget(self.title_label)
        self.value_label = QLabel(value)
        self.value_label.setStyleSheet("color: #ffffff; font-size: 16px; font-weight: bold;")
        layout.addWidget(self.value_label)

    def set_value(self, value: str):
        self.value_label.setText(value)


class DashboardPanel(QWidget):
    def __init__(self, controller, parent=None):
        super().__init__(parent)
        self._controller = controller
        self._setup_ui()
        self._timer = QTimer()
        self._timer.timeout.connect(self._refresh)
        self._timer.start(50)

    def _setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 24, 24, 24)
        layout.setSpacing(16)

        title = QLabel("Dashboard")
        title.setStyleSheet("color: #ffffff; font-size: 22px; font-weight: bold;")
        layout.addWidget(title)

        # Status cards
        cards = QGridLayout()
        cards.setSpacing(10)
        self.profile_card = StatCard("Profile", "None")
        cards.addWidget(self.profile_card, 0, 0)
        self.blueprint_card = StatCard("Blueprint", "None")
        cards.addWidget(self.blueprint_card, 0, 1)
        self.input_card = StatCard("Input", "None")
        cards.addWidget(self.input_card, 1, 0)
        self.output_card = StatCard("Output", "None")
        cards.addWidget(self.output_card, 1, 1)
        self.latency_card = StatCard("Latency", "0 ms")
        cards.addWidget(self.latency_card, 2, 0)
        self.status_card = StatCard("Engine", "Stopped")
        cards.addWidget(self.status_card, 2, 1)
        layout.addLayout(cards)

        # Controls row
        ctrl = QHBoxLayout()
        ctrl.setSpacing(16)

        self._live_cb = QCheckBox("Live Playback")
        self._live_cb.setStyleSheet("QCheckBox { color: #d1d5db; font-size: 12px; } QCheckBox::indicator { width: 16px; height: 16px; border-radius: 3px; border: 2px solid #3a3d5c; } QCheckBox::indicator:checked { background-color: #4ade80; border-color: #4ade80; }")
        self._live_cb.stateChanged.connect(lambda s: setattr(self._controller.engine, 'live_playback', bool(s)))
        ctrl.addWidget(self._live_cb)

        self._bypass_cb = QCheckBox("Bypass")
        self._bypass_cb.setStyleSheet("QCheckBox { color: #d1d5db; font-size: 12px; } QCheckBox::indicator { width: 16px; height: 16px; border-radius: 3px; border: 2px solid #3a3d5c; } QCheckBox::indicator:checked { background-color: #f87171; border-color: #f87171; }")
        self._bypass_cb.stateChanged.connect(lambda s: setattr(self._controller.engine, 'bypass', bool(s)))
        ctrl.addWidget(self._bypass_cb)

        ctrl.addStretch()
        ctrl.addWidget(QLabel("Gain:", styleSheet="color: #9ca3af; font-size: 12px;"))

        self._gain_slider = QSlider(Qt.Horizontal)
        self._gain_slider.setRange(0, 300)
        self._gain_slider.setValue(100)
        self._gain_slider.setFixedWidth(120)
        self._gain_slider.setStyleSheet("QSlider::groove:horizontal { height: 4px; background: #2a2d3a; border-radius: 2px; } QSlider::handle:horizontal { background: #7c7aff; width: 14px; height: 14px; margin: -5px 0; border-radius: 7px; } QSlider::sub-page:horizontal { background: #7c7aff; border-radius: 2px; }")
        self._gain_slider.valueChanged.connect(self._on_gain)
        ctrl.addWidget(self._gain_slider)

        self._gain_lbl = QLabel("1.0x")
        self._gain_lbl.setStyleSheet("color: #d1d5db; font-size: 12px; min-width: 30px;")
        ctrl.addWidget(self._gain_lbl)

        layout.addLayout(ctrl)

        # Level meters
        layout.addWidget(QLabel("Input", styleSheet="color: #ffffff; font-size: 13px; font-weight: bold;"))
        self.input_meter = LevelMeter("Microphone", "#4ade80")
        layout.addWidget(self.input_meter)

        layout.addWidget(QLabel("Output", styleSheet="color: #ffffff; font-size: 13px; font-weight: bold;"))
        self.output_meter = LevelMeter("Processed", "#7c7aff")
        layout.addWidget(self.output_meter)

        layout.addStretch()

    def _on_gain(self, value: int):
        gain = value / 100.0
        self._gain_lbl.setText(f"{gain:.1f}x")
        self._controller.input_gain = gain

    def _refresh(self):
        engine = self._controller.engine
        if not hasattr(engine.router, '_metrics'):
            return
        m = engine.router._metrics

        self.input_meter.set_level(m.input_level.left, m.input_level.right)
        self.output_meter.set_level(m.output_level.left, m.output_level.right)
        self.latency_card.set_value(f"{m.latency_ms:.1f} ms")
        self.status_card.set_value("Running" if engine.is_active else "Stopped")

        dev_in = engine.devices.get(engine.devices.selected_input_id)
        dev_out = engine.devices.get(engine.devices.selected_output_id)
        self.input_card.set_value(dev_in.name[:30] if dev_in else "None")
        self.output_card.set_value(dev_out.name[:30] if dev_out else "None")
        self.profile_card.set_value(engine.current_profile or "None")
        self.blueprint_card.set_value(engine.current_blueprint or "None")

        self._live_cb.setChecked(engine.live_playback)
        self._bypass_cb.setChecked(engine.bypass)
