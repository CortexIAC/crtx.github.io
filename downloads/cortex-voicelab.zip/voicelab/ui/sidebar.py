from PySide6.QtWidgets import QWidget, QVBoxLayout, QPushButton, QLabel, QFrame
from PySide6.QtCore import Signal, Qt
from PySide6.QtGui import QFont


NAV_ITEMS = [
    ("mission_control", "Mission Control", "🛸"),
    ("dashboard", "Dashboard", "📊"),
    ("profiles", "Profiles", "🎤"),
    ("blueprint", "Blueprint Studio", "🔧"),
    ("soundboard", "Soundboard", "🔊"),
    ("devices", "Devices", "🎛️"),
    ("effects", "Effects", "✨"),
    ("integrations", "Integrations", "🔗"),
    ("settings", "Settings", "⚙️"),
]


class SidebarButton(QPushButton):
    def __init__(self, key: str, text: str, icon: str, parent=None):
        super().__init__(parent)
        self.key = key
        self.setText(f" {icon}  {text}")
        self.setFixedHeight(44)
        self.setCursor(Qt.PointingHandCursor)
        self.setCheckable(True)
        self.setStyleSheet("""
            QPushButton {
                background-color: transparent;
                border: none;
                border-radius: 8px;
                padding: 8px 16px;
                text-align: left;
                font-size: 14px;
                color: #b0b8c8;
            }
            QPushButton:hover {
                background-color: #2a2d3a;
                color: #ffffff;
            }
            QPushButton:checked {
                background-color: #3a3d5c;
                color: #ffffff;
                font-weight: bold;
            }
        """)


class Sidebar(QWidget):
    navigation_changed = Signal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedWidth(220)
        self.setStyleSheet("background-color: #1e1f2e; border-right: 1px solid #2a2d3a;")
        self._setup_ui()

    def _setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(8, 16, 8, 16)
        layout.setSpacing(2)

        # Logo / Title
        title = QLabel("CORTEX")
        title.setStyleSheet("color: #7c7aff; font-size: 18px; font-weight: bold; padding: 8px 16px;")
        layout.addWidget(title)

        subtitle = QLabel("VoiceLab")
        subtitle.setStyleSheet("color: #6b7280; font-size: 12px; padding: 0 16px 16px 16px;")
        layout.addWidget(subtitle)

        # Separator
        sep = QFrame()
        sep.setFrameShape(QFrame.HLine)
        sep.setStyleSheet("background-color: #2a2d3a; max-height: 1px; margin: 8px 16px;")
        layout.addWidget(sep)

        self._buttons = {}
        for key, text, icon in NAV_ITEMS:
            btn = SidebarButton(key, text, icon)
            btn.clicked.connect(lambda checked, k=key: self._on_navigate(k))
            layout.addWidget(btn)
            self._buttons[key] = btn

        layout.addStretch()

        # Version
        ver = QLabel("v1.0.0")
        ver.setStyleSheet("color: #4b5563; font-size: 11px; padding: 8px 16px;")
        layout.addWidget(ver)

        # Default selection
        self._buttons["dashboard"].setChecked(True)

    def _on_navigate(self, key: str):
        for btn in self._buttons.values():
            btn.setChecked(btn.key == key)
        self.navigation_changed.emit(key)
