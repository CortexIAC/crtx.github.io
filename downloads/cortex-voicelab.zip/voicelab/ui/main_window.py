from PySide6.QtWidgets import QMainWindow, QWidget, QHBoxLayout, QStackedWidget
from voicelab.ui.sidebar import Sidebar
from voicelab.ui.mission_control import MissionControlPanel
from voicelab.ui.dashboard import DashboardPanel
from voicelab.ui.profiles_panel import ProfilesPanel
from voicelab.ui.blueprint_editor import BlueprintEditorPanel
from voicelab.ui.soundboard_panel import SoundboardPanel
from voicelab.ui.devices_panel import DevicesPanel
from voicelab.ui.effects_panel import EffectsPanel
from voicelab.ui.integrations_panel import IntegrationsPanel
from voicelab.ui.settings_panel import SettingsPanel
from voicelab.controllers.engine_controller import EngineController


class MainWindow(QMainWindow):
    def __init__(self, controller: EngineController):
        super().__init__()
        self._controller = controller
        self.setWindowTitle("Cortex VoiceLab")
        self.setMinimumSize(1200, 750)
        self.setStyleSheet("background-color: #1a1b2a;")

        central = QWidget()
        self.setCentralWidget(central)
        layout = QHBoxLayout(central)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        self._sidebar = Sidebar()
        self._sidebar.navigation_changed.connect(self._on_navigate)
        layout.addWidget(self._sidebar)

        self._content = QStackedWidget()
        self._content.setStyleSheet("background-color: #1a1b2a;")
        layout.addWidget(self._content, 1)

        self._panels = {
            "mission_control": MissionControlPanel(self._controller),
            "dashboard": DashboardPanel(self._controller),
            "profiles": ProfilesPanel(self._controller),
            "blueprint": BlueprintEditorPanel(self._controller),
            "soundboard": SoundboardPanel(self._controller),
            "devices": DevicesPanel(self._controller),
            "effects": EffectsPanel(self._controller),
            "integrations": IntegrationsPanel(self._controller),
            "settings": SettingsPanel(self._controller),
        }

        for key in ["mission_control", "dashboard", "profiles", "blueprint", "soundboard",
                     "devices", "effects", "integrations", "settings"]:
            self._content.addWidget(self._panels[key])

        self._content.setCurrentWidget(self._panels["dashboard"])

    def _on_navigate(self, key: str):
        if key in self._panels:
            self._content.setCurrentWidget(self._panels[key])

    def closeEvent(self, event):
        self._controller.shutdown()
        super().closeEvent(event)
