from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QScrollArea,
    QGridLayout, QFrame, QLineEdit, QListWidget, QFileDialog
)
from PySide6.QtCore import Qt, Signal
from voicelab.models.soundboard_model import SoundClip


class SoundClipWidget(QFrame):
    play_clicked = Signal(str)

    def __init__(self, clip: SoundClip, parent=None):
        super().__init__(parent)
        self.clip = clip
        self.setFixedSize(140, 100)
        self.setCursor(Qt.PointingHandCursor)
        self.setStyleSheet("""
            SoundClipWidget {
                background-color: #252736; border: 1px solid #2a2d3a;
                border-radius: 10px; padding: 8px;
            }
            SoundClipWidget:hover {
                border-color: #7c7aff; background-color: #2a2d3a;
            }
        """)
        layout = QVBoxLayout(self)
        layout.setSpacing(4)
        layout.setAlignment(Qt.AlignCenter)

        icon = QLabel("🔊")
        icon.setStyleSheet("font-size: 24px;")
        icon.setAlignment(Qt.AlignCenter)
        layout.addWidget(icon)

        name = QLabel(clip.name)
        name.setStyleSheet("color: #ffffff; font-size: 11px; font-weight: bold;")
        name.setAlignment(Qt.AlignCenter)
        name.setWordWrap(True)
        layout.addWidget(name)

        if clip.hotkey:
            hotkey = QLabel(f"[{clip.hotkey}]")
            hotkey.setStyleSheet("color: #6b7280; font-size: 9px;")
            hotkey.setAlignment(Qt.AlignCenter)
            layout.addWidget(hotkey)

    def mouseReleaseEvent(self, event):
        self.play_clicked.emit(self.clip.id)
        super().mouseReleaseEvent(event)


class SoundboardPanel(QWidget):
    def __init__(self, controller, parent=None):
        super().__init__(parent)
        self._controller = controller
        self._clips: list = []
        self._setup_ui()

    def _setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(32, 32, 32, 32)
        layout.setSpacing(16)

        header = QHBoxLayout()
        title = QLabel("Soundboard")
        title.setStyleSheet("color: #ffffff; font-size: 24px; font-weight: bold;")
        header.addWidget(title)
        header.addStretch()

        search = QLineEdit()
        search.setPlaceholderText("Search clips...")
        search.setStyleSheet("""
            QLineEdit {
                background: #252736; color: #ffffff; border: 1px solid #2a2d3a;
                border-radius: 8px; padding: 8px 16px; min-width: 250px;
            }
            QLineEdit:focus { border-color: #7c7aff; }
        """)
        header.addWidget(search)

        import_btn = QPushButton("+ Import Clip")
        import_btn.setStyleSheet("""
            QPushButton {
                background: #7c7aff; color: #ffffff; border: none;
                border-radius: 8px; padding: 8px 16px; font-weight: bold;
            }
            QPushButton:hover { background: #6b6aff; }
        """)
        import_btn.clicked.connect(self._import_clip)
        header.addWidget(import_btn)

        layout.addLayout(header)

        # Categories list + clip grid
        content = QHBoxLayout()
        content.setSpacing(16)

        # Category sidebar
        category_frame = QFrame()
        category_frame.setFixedWidth(160)
        category_frame.setStyleSheet("""
            QFrame {
                background-color: #252736; border: 1px solid #2a2d3a;
                border-radius: 12px; padding: 8px;
            }
        """)
        cat_layout = QVBoxLayout(category_frame)
        cat_label = QLabel("Categories")
        cat_label.setStyleSheet("color: #9ca3af; font-size: 12px; font-weight: bold; padding: 8px;")
        cat_layout.addWidget(cat_label)

        self._category_list = QListWidget()
        self._category_list.setStyleSheet("""
            QListWidget {
                background: transparent; border: none; color: #d1d5db;
                font-size: 13px;
            }
            QListWidget::item {
                padding: 8px 12px; border-radius: 6px;
            }
            QListWidget::item:selected {
                background-color: #3a3d5c; color: #ffffff;
            }
            QListWidget::item:hover {
                background-color: #2a2d3a;
            }
        """)
        self._category_list.addItems(["All", "Uncategorized"])
        self._category_list.setCurrentRow(0)
        cat_layout.addWidget(self._category_list)
        content.addWidget(category_frame)

        # Clip grid
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setStyleSheet("QScrollArea { border: none; background: transparent; }")

        self._clip_grid = QWidget()
        self._clip_grid.setStyleSheet("background: transparent;")
        self._clip_layout = QGridLayout(self._clip_grid)
        self._clip_layout.setSpacing(12)
        self._clip_layout.setAlignment(Qt.AlignLeft | Qt.AlignTop)

        scroll.setWidget(self._clip_grid)
        content.addWidget(scroll, 1)

        layout.addLayout(content)

    def _import_clip(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Import Audio Clip", "", "Audio Files (*.wav *.mp3 *.ogg *.flac)"
        )
        if path:
            import uuid
            name = path.split("/")[-1].split("\\")[-1]
            clip = SoundClip(
                id=uuid.uuid4().hex[:8],
                name=name.rsplit(".", 1)[0],
                file_path=path,
            )
            self._clips.append(clip)
            self._refresh_clips()

    def _refresh_clips(self):
        for i in reversed(range(self._clip_layout.count())):
            widget = self._clip_layout.itemAt(i).widget()
            if widget:
                widget.deleteLater()

        row, col = 0, 0
        for clip in self._clips:
            w = SoundClipWidget(clip)
            w.play_clicked.connect(self._play_clip)
            self._clip_layout.addWidget(w, row, col)
            col += 1
            if col > 4:
                col = 0
                row += 1

    def _play_clip(self, clip_id: str):
        pass
