"""Blueprint Studio — visual node editor for building audio processing chains."""

import uuid
import math
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QFrame,
    QComboBox, QFileDialog, QScrollArea, QSlider, QCheckBox,
    QLineEdit,     QDoubleSpinBox, QListView, QSplitter,
    QMessageBox, QMenu, QInputDialog, QGridLayout, QGroupBox,
)
from PySide6.QtCore import Qt, Signal, QPointF, QRectF, QSize, QStringListModel
from PySide6.QtGui import (
    QPainter, QPen, QBrush, QColor, QFont, QPainterPath,
    QPolygonF, QAction, QFontMetrics,
)
from audio_engine.models.blueprint import Blueprint
from audio_engine.models.processing_node import ProcessingNode, NodeConnection, NodeType, NodeParameter

# ---------------------------------------------------------------------------
# Parameter templates — define default params, ranges, display names per type
# ---------------------------------------------------------------------------

NODE_PARAM_DEFS = {
    NodeType.INPUT: {},
    NodeType.OUTPUT: {},
    NodeType.NOISE_GATE: {
        "floor_offset":{"label": "Floor Offset","min": 0.0,   "max": 20.0,  "step": 1.0,   "default": 6.0,   "unit": "dB"},
        "ratio":      {"label": "Ratio",      "min": 1.0,   "max": 20.0,  "step": 0.5,   "default": 3.0},
        "attack":     {"label": "Attack",     "min": 0.001, "max": 0.1,   "step": 0.001, "default": 0.002, "unit": "s"},
        "release":    {"label": "Release",    "min": 0.01,  "max": 1.0,   "step": 0.01,  "default": 0.1,   "unit": "s"},
        "knee":       {"label": "Knee",       "min": 0.0,   "max": 12.0,  "step": 1.0,   "default": 6.0,   "unit": "dB"},
    },
    NodeType.NOISE_REDUCTION: {
        "strength":   {"label": "Strength",   "min": 0.0,   "max": 1.0,   "step": 0.01,  "default": 0.5},
        "floor":      {"label": "Floor",      "min": 0.0,   "max": 0.1,   "step": 0.001, "default": 0.01},
    },
    NodeType.EQUALIZER: {
        "low_gain":   {"label": "Low Gain",   "min": -12.0, "max": 12.0,  "step": 0.5,   "default": 0.0,  "unit": "dB"},
        "mid_gain":   {"label": "Mid Gain",   "min": -12.0, "max": 12.0,  "step": 0.5,   "default": 0.0,  "unit": "dB"},
        "high_gain":  {"label": "High Gain",  "min": -12.0, "max": 12.0,  "step": 0.5,   "default": 0.0,  "unit": "dB"},
        "low_freq":   {"label": "Low Freq",   "min": 20.0,  "max": 500.0, "step": 10.0,  "default": 250.0, "unit": "Hz"},
        "high_freq":  {"label": "High Freq",  "min": 1000.0,"max": 8000.0,"step": 100.0, "default": 4000.0,"unit": "Hz"},
    },
    NodeType.COMPRESSOR: {
        "threshold":  {"label": "Threshold",  "min": -60.0, "max": 0.0,   "step": 1.0,   "default": -20.0, "unit": "dB"},
        "ratio":      {"label": "Ratio",      "min": 1.0,   "max": 20.0,  "step": 0.5,   "default": 4.0},
        "attack":     {"label": "Attack",     "min": 0.001, "max": 0.05,  "step": 0.001, "default": 0.002, "unit": "s"},
        "release":    {"label": "Release",    "min": 0.01,  "max": 0.5,   "step": 0.01,  "default": 0.05,  "unit": "s"},
        "makeup_gain":{"label": "Makeup Gain","min": 0.0,   "max": 12.0,  "step": 0.5,   "default": 3.0,   "unit": "dB"},
        "knee":       {"label": "Knee",       "min": 0.0,   "max": 12.0,  "step": 1.0,   "default": 6.0,   "unit": "dB"},
    },
    NodeType.PITCH_SHIFT: {
        "semitones":  {"label": "Semitones",  "min": -12.0, "max": 12.0,  "step": 0.5,   "default": 0.0},
        "mix":        {"label": "Mix",        "min": 0.0,   "max": 1.0,   "step": 0.01,  "default": 0.8},
        "formant":    {"label": "Formant",    "min": 0.5,   "max": 2.0,   "step": 0.1,   "default": 1.0},
    },
    NodeType.REVERB: {
        "room_size":  {"label": "Room Size",  "min": 0.0,   "max": 1.0,   "step": 0.01,  "default": 0.5},
        "damping":    {"label": "Damping",    "min": 0.0,   "max": 1.0,   "step": 0.01,  "default": 0.5},
        "wet_mix":    {"label": "Wet Mix",    "min": 0.0,   "max": 1.0,   "step": 0.01,  "default": 0.3},
        "dry_mix":    {"label": "Dry Mix",    "min": 0.0,   "max": 1.0,   "step": 0.01,  "default": 0.7},
        "width":      {"label": "Width",      "min": 0.0,   "max": 1.0,   "step": 0.01,  "default": 0.5},
    },
    NodeType.DELAY: {
        "delay_time": {"label": "Delay",      "min": 0.01,  "max": 2.0,   "step": 0.01,  "default": 0.25, "unit": "s"},
        "feedback":   {"label": "Feedback",   "min": 0.0,   "max": 1.0,   "step": 0.01,  "default": 0.3},
        "mix":        {"label": "Mix",        "min": 0.0,   "max": 1.0,   "step": 0.01,  "default": 0.3},
    },
    NodeType.RADIO: {
        "low_cut":    {"label": "Low Cut",    "min": 100.0, "max": 1000.0,"step": 10.0,  "default": 300.0, "unit": "Hz"},
        "high_cut":   {"label": "High Cut",   "min": 2000.0,"max": 6000.0,"step": 50.0,  "default": 3400.0,"unit": "Hz"},
        "distortion": {"label": "Distortion", "min": 0.0,   "max": 1.0,   "step": 0.01,  "default": 0.2},
        "noise_floor":{"label": "Noise Floor","min": 0.0,   "max": 0.05,  "step": 0.001, "default": 0.01},
    },
    NodeType.VOICE_CONVERSION: {
        "mix":        {"label": "Mix",        "min": 0.0,   "max": 1.0,   "step": 0.01,  "default": 1.0},
        "semitones":  {"label": "Pitch",      "min": -12.0, "max": 12.0,  "step": 0.5,   "default": 0.0},
        "noise_gate": {"label": "Noise Gate", "min": 0.0,   "max": 1.0,   "step": 0.01,  "default": 1.0},
    },
    NodeType.LIMITER: {
        "ceiling":    {"label": "Ceiling",    "min": -6.0,  "max": 0.0,   "step": 0.5,   "default": -1.0, "unit": "dB"},
        "release":    {"label": "Release",    "min": 0.01,  "max": 0.5,   "step": 0.01,  "default": 0.05,  "unit": "s"},
        "soft_clip":  {"label": "Soft Clip",  "min": 0.0,   "max": 1.0,   "step": 0.01,  "default": 0.0},
    },
    NodeType.DEESSER: {
        "threshold":  {"label": "Threshold",  "min": -40.0, "max": -10.0, "step": 1.0,   "default": -25.0, "unit": "dB"},
        "ratio":      {"label": "Ratio",      "min": 2.0,   "max": 20.0,  "step": 1.0,   "default": 5.0},
        "frequency":  {"label": "Frequency",  "min": 3000.0,"max": 10000.0,"step": 500.0, "default": 6000.0,"unit": "Hz"},
        "attack":     {"label": "Attack",     "min": 0.001, "max": 0.01,  "step": 0.001, "default": 0.001, "unit": "s"},
        "release":    {"label": "Release",    "min": 0.01,  "max": 0.2,   "step": 0.01,  "default": 0.05,  "unit": "s"},
    },
    NodeType.MULTIBAND_COMP: {
        "threshold":  {"label": "Threshold",  "min": -40.0, "max": 0.0,   "step": 1.0,   "default": -25.0, "unit": "dB"},
        "ratio":      {"label": "Ratio",      "min": 1.0,   "max": 10.0,  "step": 0.5,   "default": 3.0},
        "attack":     {"label": "Attack",     "min": 0.001, "max": 0.05,  "step": 0.001, "default": 0.002, "unit": "s"},
        "release":    {"label": "Release",    "min": 0.01,  "max": 0.5,   "step": 0.01,  "default": 0.08,  "unit": "s"},
        "knee":       {"label": "Knee",       "min": 0.0,   "max": 12.0,  "step": 1.0,   "default": 6.0,   "unit": "dB"},
    },
    NodeType.EXCITER: {
        "amount":     {"label": "Amount",     "min": 0.0,   "max": 1.0,   "step": 0.01,  "default": 0.3},
        "tone":       {"label": "Tone",       "min": 0.0,   "max": 1.0,   "step": 0.01,  "default": 0.5},
    },
    NodeType.AUTOGAIN: {
        "target":     {"label": "Target",     "min": -30.0, "max": -6.0,  "step": 1.0,   "default": -16.0, "unit": "dB"},
        "attack":     {"label": "Attack",     "min": 0.001, "max": 0.1,   "step": 0.001, "default": 0.01,  "unit": "s"},
        "release":    {"label": "Release",    "min": 0.01,  "max": 2.0,   "step": 0.01,  "default": 0.5,   "unit": "s"},
    },
}

NODE_COLORS = {
    NodeType.INPUT:           "#4ade80",
    NodeType.OUTPUT:          "#f87171",
    NodeType.NOISE_GATE:      "#60a5fa",
    NodeType.NOISE_REDUCTION: "#60a5fa",
    NodeType.EQUALIZER:       "#f59e0b",
    NodeType.COMPRESSOR:      "#f59e0b",
    NodeType.PITCH_SHIFT:     "#a78bfa",
    NodeType.VOICE_CONVERSION:"#ff6b9d",
    NodeType.LIMITER:         "#f472b6",
    NodeType.DEESSER:         "#ec4899",
    NodeType.MULTIBAND_COMP:  "#f97316",
    NodeType.EXCITER:         "#facc15",
    NodeType.AUTOGAIN:        "#22d3ee",
    NodeType.REVERB:          "#34d399",
    NodeType.DELAY:           "#34d399",
    NodeType.RADIO:           "#fb923c",
}

NODE_ICONS = {
    NodeType.INPUT:           "⬅",
    NodeType.OUTPUT:          "➡",
    NodeType.NOISE_GATE:      "⊓",
    NodeType.NOISE_REDUCTION: "▽",
    NodeType.EQUALIZER:       "≡",
    NodeType.COMPRESSOR:      "◐",
    NodeType.PITCH_SHIFT:     "↕",
    NodeType.VOICE_CONVERSION:"◆",
    NodeType.LIMITER:         "▶",
    NodeType.DEESSER:         "✶",
    NodeType.MULTIBAND_COMP:  "≡",
    NodeType.EXCITER:         "✨",
    NodeType.AUTOGAIN:        "↔",
    NodeType.REVERB:          "≈",
    NodeType.DELAY:           "⏳",
    NodeType.RADIO:           "◉",
}

NODE_SIZE = QSize(160, 48)

INPUT_PORT_OFFSET  = QPointF(0,  24)
OUTPUT_PORT_OFFSET = QPointF(160, 24)
PORT_RADIUS = 6

# ---------------------------------------------------------------------------
# Helper: create a ProcessingNode with default parameters filled in
# ---------------------------------------------------------------------------

def make_node(node_type: NodeType, x: float, y: float) -> ProcessingNode:
    nid = f"{node_type.value}_{uuid.uuid4().hex[:6]}"
    params = {}
    defs = NODE_PARAM_DEFS.get(node_type, {})
    for key, d in defs.items():
        params[key] = NodeParameter(
            name=key,
            value=d["default"],
            min_value=d["min"],
            max_value=d["max"],
            step=d["step"],
            unit=d.get("unit", ""),
            label=d["label"],
        )
    label = node_type.value.replace("_", " ").title()
    return ProcessingNode(id=nid, node_type=node_type, label=label,
                          parameters=params, position_x=x, position_y=y)

# ---------------------------------------------------------------------------
# BlueprintCanvas — visual node editor
# ---------------------------------------------------------------------------

class BlueprintCanvas(QWidget):
    node_selected = Signal(str)          # node id (or empty)
    blueprint_changed = Signal()
    status_message = Signal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumSize(700, 400)
        self.setFocusPolicy(Qt.StrongFocus)
        self.setStyleSheet("background-color: #1a1b2a; border: 1px solid #2a2d3a; border-radius: 6px;")

        self._blueprint: Blueprint = Blueprint(name="Untitled")
        self._selected_node: str = ""
        self._hovered_port: tuple = ("", "")  # (node_id, "in"/"out")

        # Drag state
        self._dragging = False
        self._drag_node = ""
        self._drag_offset = QPointF()

        # Connection drawing state
        self._connecting = False
        self._conn_source = ("", "")          # (node_id, port_type)
        self._conn_end = QPointF()

    # -- public api ---------------------------------------------------------

    def set_blueprint(self, bp: Blueprint):
        self._blueprint = bp
        self._selected_node = ""
        self._connecting = False
        self.update()
        self.blueprint_changed.emit()

    def get_blueprint(self) -> Blueprint:
        return self._blueprint

    def selected_node_id(self) -> str:
        return self._selected_node

    def delete_selected(self):
        if self._selected_node:
            self._blueprint.remove_node(self._selected_node)
            self._selected_node = ""
            self.update()
            self.blueprint_changed.emit()
            self.status_message.emit("Node deleted")

    # -- node / port geometry helpers ---------------------------------------

    def _node_rect(self, node) -> QRectF:
        return QRectF(node.position_x, node.position_y, NODE_SIZE.width(), NODE_SIZE.height())

    def _input_port_pos(self, node) -> QPointF:
        r = self._node_rect(node)
        return QPointF(r.left(), r.center().y())

    def _output_port_pos(self, node) -> QPointF:
        r = self._node_rect(node)
        return QPointF(r.right(), r.center().y())

    def _hit_test_port(self, pos: QPointF):
        """Return (node_id, 'in'|'out') or ('', '') if no port hit."""
        for node in reversed(self._blueprint.nodes):
            in_pt = self._input_port_pos(node)
            if (pos - in_pt).manhattanLength() < 12:
                return (node.id, "in")
            out_pt = self._output_port_pos(node)
            if (pos - out_pt).manhattanLength() < 12:
                return (node.id, "out")
        return ("", "")

    def _hit_test_node(self, pos: QPointF):
        for node in reversed(self._blueprint.nodes):
            if self._node_rect(node).contains(pos):
                return node.id
        return ""

    # -- event handlers -----------------------------------------------------

    def mousePressEvent(self, event):
        pos = event.position()
        btn = event.button()

        # Right-click → delete
        if btn == Qt.RightButton:
            nid = self._hit_test_node(pos)
            if nid:
                self._blueprint.remove_node(nid)
                if self._selected_node == nid:
                    self._selected_node = ""
                self.update()
                self.blueprint_changed.emit()
                self.status_message.emit("Node removed")
            else:
                # Clear selection
                self._selected_node = ""
                self.update()
                self.node_selected.emit("")
            return

        if btn != Qt.LeftButton:
            return

        # Check port hit first
        port_hit = self._hit_test_port(pos)
        if port_hit[0]:
            self._connecting = True
            self._conn_source = port_hit  # (node_id, "in"|"out")
            self._conn_end = pos
            return

        # Check node hit → start drag
        nid = self._hit_test_node(pos)
        if nid:
            node = self._blueprint.get_node(nid)
            self._selected_node = nid
            self._dragging = True
            self._drag_node = nid
            self._drag_offset = QPointF(pos.x() - node.position_x, pos.y() - node.position_y)
            self.node_selected.emit(nid)
            self.update()
            return

        # Click on nothing → clear selection
        self._selected_node = ""
        self.node_selected.emit("")
        self.update()

    def mouseMoveEvent(self, event):
        pos = event.position()

        if self._connecting:
            self._conn_end = pos
            # Hover highlight
            self._hovered_port = self._hit_test_port(pos)
            self.update()
            return

        if self._dragging and self._drag_node:
            node = self._blueprint.get_node(self._drag_node)
            if node:
                node.position_x = max(0, pos.x() - self._drag_offset.x())
                node.position_y = max(0, pos.y() - self._drag_offset.y())
                self.update()
                self.blueprint_changed.emit()
            return

        # Update hover
        self._hovered_port = self._hit_test_port(pos)
        self.update()

    def mouseReleaseEvent(self, event):
        if self._connecting:
            src_nid, src_type = self._conn_source
            dst = self._hit_test_port(event.position())
            dst_nid, dst_type = dst

            if (src_nid and dst_nid and src_nid != dst_nid
                    and src_type != dst_type):  # must be out→in or in→out
                # Normalize to out→in
                out_id = src_nid if src_type == "out" else dst_nid
                in_id  = dst_nid if src_type == "out" else src_nid
                conn = NodeConnection(source_id=out_id, target_id=in_id)
                # Avoid duplicates
                if conn not in self._blueprint.connections:
                    self._blueprint.add_connection(conn)
                    self.status_message.emit("Connection added")
                    self.blueprint_changed.emit()
            self._connecting = False
            self._conn_source = ("", "")
            self._hovered_port = ("", "")
            self.update()
            return

        self._dragging = False
        self._drag_node = ""

    def keyPressEvent(self, event):
        if event.key() == Qt.Key_Delete or event.key() == Qt.Key_Backspace:
            self.delete_selected()
        elif event.key() == Qt.Key_Escape:
            self._connecting = False
            self._selected_node = ""
            self.update()
            self.node_selected.emit("")

    # -- painting -----------------------------------------------------------

    def paintEvent(self, event):
        super().paintEvent(event)
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)

        self._draw_grid(painter)
        self._draw_connections(painter)
        self._draw_in_progress_connection(painter)
        self._draw_nodes(painter)

    def _draw_grid(self, p: QPainter):
        p.setPen(QPen(QColor("#2a2d3a"), 1))
        w, h = self.width(), self.height()
        for x in range(0, w, 40):
            p.drawLine(x, 0, x, h)
        for y in range(0, h, 40):
            p.drawLine(0, y, w, y)

    def _draw_connections(self, p: QPainter):
        for conn in self._blueprint.connections:
            src = self._blueprint.get_node(conn.source_id)
            tgt = self._blueprint.get_node(conn.target_id)
            if not src or not tgt:
                continue
            p1 = self._output_port_pos(src)
            p2 = self._input_port_pos(tgt)
            color = QColor("#6b7280")
            selected = (conn.source_id == self._selected_node or conn.target_id == self._selected_node)
            if selected:
                color = QColor("#7c7aff")
            p.setPen(QPen(color, 2))
            path = QPainterPath()
            path.moveTo(p1)
            cp = (p1.x() + p2.x()) / 2
            path.cubicTo(cp, p1.y(), cp, p2.y(), p2.x(), p2.y())
            p.drawPath(path)

    def _draw_in_progress_connection(self, p: QPainter):
        if not self._connecting:
            return
        src_nid, src_type = self._conn_source
        src_node = self._blueprint.get_node(src_nid)
        if not src_node:
            return
        p1 = self._output_port_pos(src_node) if src_type == "out" else self._input_port_pos(src_node)
        p2 = self._conn_end
        p.setPen(QPen(QColor("#7c7aff"), 2, Qt.DashLine))
        path = QPainterPath()
        path.moveTo(p1)
        cp = (p1.x() + p2.x()) / 2
        path.cubicTo(cp, p1.y(), cp, p2.y(), p2.x(), p2.y())
        p.drawPath(path)

        # Draw ghost port at mouse
        p.setBrush(QBrush(QColor("#7c7aff")))
        p.setPen(Qt.NoPen)
        p.drawEllipse(p2, PORT_RADIUS, PORT_RADIUS)

    def _draw_nodes(self, p: QPainter):
        font = QFont("Segoe UI", 10)
        small_font = QFont("Segoe UI", 8)
        p.setFont(font)

        for node in self._blueprint.nodes:
            rect = self._node_rect(node)
            x, y, w, h = rect.x(), rect.y(), rect.width(), rect.height()
            color = NODE_COLORS.get(node.node_type, "#6b7280")
            is_selected = node.id == self._selected_node

            # Shadow
            p.setBrush(Qt.NoBrush)
            p.setPen(QPen(QColor(0, 0, 0, 60), 1))
            p.drawRoundedRect(QRectF(x + 2, y + 2, w, h), 8, 8)

            # Body
            p.setBrush(QBrush(QColor("#252736")))
            border_color = QColor(color) if is_selected else QColor("#3a3d5c")
            border_w = 2 if is_selected else 1
            p.setPen(QPen(border_color, border_w))
            p.drawRoundedRect(rect, 8, 8)

            # Colour stripe on left
            p.setBrush(QBrush(QColor(color)))
            p.setPen(Qt.NoPen)
            stripe = QRectF(x, y, 5, h)
            path = QPainterPath()
            path.addRoundedRect(stripe, 8, 8)
            p.drawPath(path)
            # Fill the left 5px area manually
            p.drawRoundedRect(QRectF(x, y, 5, h), 8, 8)

            # Icon
            icon = NODE_ICONS.get(node.node_type, "●")
            p.setPen(QPen(QColor(color)))
            p.setFont(small_font)
            p.drawText(QRectF(x + 10, y, 18, h), Qt.AlignCenter, icon)

            # Label
            p.setFont(font)
            p.setPen(QPen(QColor("#ffffff")))
            p.drawText(QRectF(x + 30, y, w - 40, h), Qt.AlignVCenter | Qt.AlignLeft, node.display_name)

            # Bypass indicator
            if node.bypass:
                p.setPen(QPen(QColor("#f87171")))
                p.setFont(small_font)
                p.drawText(QRectF(x, y - 14, w, 12), Qt.AlignCenter, "⏸ BYPASSED")

            # Input port
            port_pos = QPointF(x, y + h / 2)
            port_color = QColor("#4ade80") if (node.id, "in") == self._hovered_port else QColor("#3a3d5c")
            p.setBrush(QBrush(port_color))
            p.setPen(QPen(QColor("#6b7280"), 1))
            p.drawEllipse(port_pos, PORT_RADIUS, PORT_RADIUS)

            # Output port
            port_pos = QPointF(x + w, y + h / 2)
            port_color = QColor("#7c7aff") if (node.id, "out") == self._hovered_port else QColor("#3a3d5c")
            p.setBrush(QBrush(port_color))
            p.setPen(QPen(QColor("#6b7280"), 1))
            p.drawEllipse(port_pos, PORT_RADIUS, PORT_RADIUS)


# ---------------------------------------------------------------------------
# PropertyPanel — edit selected node's parameters
# ---------------------------------------------------------------------------

class PropertyPanel(QFrame):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedWidth(280)
        self.setStyleSheet("PropertyPanel { background-color: #1e1f2e; border: 1px solid #2a2d3a; border-radius: 8px; }")
        self._node: ProcessingNode = None
        self._widgets = {}
        self._layout = QVBoxLayout(self)
        self._layout.setContentsMargins(12, 12, 12, 12)
        self._layout.setSpacing(6)
        self._build_empty()

    def _clear(self):
        for i in reversed(range(self._layout.count())):
            item = self._layout.itemAt(i)
            if item and item.widget():
                item.widget().deleteLater()
            else:
                self._layout.takeAt(i)
        self._widgets = {}

    def _build_empty(self):
        self._clear()
        lbl = QLabel("Select a node\nto edit its parameters")
        lbl.setStyleSheet("color: #6b7280; font-size: 13px; padding: 20px;")
        lbl.setAlignment(Qt.AlignCenter)
        self._layout.addWidget(lbl)
        self._layout.addStretch()

    def set_node(self, node: ProcessingNode):
        self._node = node
        self._clear()
        if node is None:
            self._build_empty()
            return

        # Title
        title = QLabel(node.display_name)
        title.setStyleSheet("color: #ffffff; font-size: 15px; font-weight: bold;")
        self._layout.addWidget(title)

        type_lbl = QLabel(f"Type: {node.node_type.value}")
        type_lbl.setStyleSheet("color: #6b7280; font-size: 11px;")
        self._layout.addWidget(type_lbl)

        # Node ID (read-only)
        id_lbl = QLabel(f"ID: {node.id[:16]}…")
        id_lbl.setStyleSheet("color: #4b5563; font-size: 10px;")
        self._layout.addWidget(id_lbl)

        # Separator
        sep = QFrame()
        sep.setFrameShape(QFrame.HLine)
        sep.setStyleSheet("background: #2a2d3a; max-height: 1px;")
        self._layout.addWidget(sep)

        # Bypass toggle
        bypass_cb = QCheckBox("Bypass this node")
        bypass_cb.setChecked(node.bypass)
        bypass_cb.setStyleSheet("QCheckBox { color: #d1d5db; font-size: 12px; } QCheckBox::indicator { width: 16px; height: 16px; border-radius: 3px; border: 2px solid #3a3d5c; } QCheckBox::indicator:checked { background-color: #f87171; border-color: #f87171; }")
        bypass_cb.toggled.connect(self._on_bypass)
        self._layout.addWidget(bypass_cb)

        self._layout.addSpacing(8)

        # Parameters
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setStyleSheet("QScrollArea { border: none; background: transparent; }")
        scroll_content = QWidget()
        scroll_content.setStyleSheet("background: transparent;")
        scroll_layout = QVBoxLayout(scroll_content)
        scroll_layout.setSpacing(4)
        scroll_layout.setContentsMargins(0, 0, 0, 0)

        for key, param in node.parameters.items():
            self._add_param_widget(scroll_layout, key, param)

        scroll_layout.addStretch()
        scroll.setWidget(scroll_content)
        self._layout.addWidget(scroll, 1)

    def _add_param_widget(self, layout, key: str, param: NodeParameter):
        label = param.label or key.replace("_", " ").title()
        unit = param.unit
        fmt = f" {unit}" if unit else ""

        # Label row
        hl = QHBoxLayout()
        hl.setSpacing(4)
        lbl = QLabel(label)
        lbl.setStyleSheet("color: #9ca3af; font-size: 11px;")
        hl.addWidget(lbl)
        hl.addStretch()

        value_lbl = QLabel(f"{param.value:.2f}{fmt}")
        value_lbl.setStyleSheet("color: #d1d5db; font-size: 11px;")
        value_lbl.setObjectName(f"_val_{key}")
        hl.addWidget(value_lbl)
        layout.addLayout(hl)

        # Slider row
        slider = QSlider(Qt.Horizontal)
        slider.setMinimum(0)
        slider.setMaximum(1000)
        slider.setValue(int((param.value - param.min_value) / (param.max_value - param.min_value) * 1000))
        slider.setStyleSheet("QSlider::groove:horizontal { height: 3px; background: #2a2d3a; border-radius: 1px; } QSlider::handle:horizontal { background: #7c7aff; width: 12px; height: 12px; margin: -5px 0; border-radius: 6px; } QSlider::sub-page:horizontal { background: #7c7aff; border-radius: 1px; }")
        slider.valueChanged.connect(lambda v, k=key, vl=value_lbl, p=param, f=fmt: self._on_param_slider(k, v, vl, p, f))
        layout.addWidget(slider)

        # Store reference for programmatic updates
        self._widgets[key] = (slider, value_lbl, param)

    def _on_param_slider(self, key: str, value: int, value_lbl, param: NodeParameter, fmt: str):
        pct = value / 1000.0
        val = param.min_value + pct * (param.max_value - param.min_value)
        # Snap to step
        if param.step > 0:
            val = round(val / param.step) * param.step
        param.value = max(param.min_value, min(param.max_value, val))
        value_lbl.setText(f"{param.value:.2f}{fmt}")
        if self._node:
            self._node.set_param(key, param.value)

    def _on_bypass(self, checked: bool):
        if self._node:
            self._node.bypass = checked


# ---------------------------------------------------------------------------
# BlueprintEditorPanel — main panel combining palette, canvas, properties
# ---------------------------------------------------------------------------

class BlueprintEditorPanel(QWidget):
    def __init__(self, controller, parent=None):
        super().__init__(parent)
        self._controller = controller
        self._current_blueprint = Blueprint(name="New Blueprint")
        self._setup_ui()
        self._refresh_list()

    def _setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(16, 16, 16, 16)
        layout.setSpacing(8)

        # ── Top bar ────────────────────────────────────────────────────────
        top = QHBoxLayout()
        top.setSpacing(8)

        title = QLabel("Blueprint Studio")
        title.setStyleSheet("color: #ffffff; font-size: 20px; font-weight: bold;")
        top.addWidget(title)
        top.addSpacing(16)

        self._bp_selector = QComboBox()
        self._bp_selector.setMinimumWidth(200)
        self._bp_selector.setStyleSheet("QComboBox { background: #252736; color: #fff; border: 1px solid #2a2d3a; border-radius: 5px; padding: 4px 10px; } QComboBox::drop-down { border: none; } QComboBox QAbstractItemView { background: #252736; color: #fff; selection-background-color: #3a3d5c; }")
        self._bp_selector.currentTextChanged.connect(self._on_load)
        top.addWidget(self._bp_selector)

        btn_style = "QPushButton { background: #2a2d3a; color: #d1d5db; border: 1px solid #3a3d5c; border-radius: 5px; padding: 5px 12px; font-size: 12px; } QPushButton:hover { background: #3a3d5c; color: #fff; }"
        accent_style = "QPushButton { background: #7c7aff; color: #fff; border: none; border-radius: 5px; padding: 5px 14px; font-size: 12px; font-weight: bold; } QPushButton:hover { background: #6b6aff; }"
        green_style  = "QPushButton { background: #4ade80; color: #000; border: none; border-radius: 5px; padding: 5px 14px; font-size: 12px; font-weight: bold; } QPushButton:hover { background: #34d399; }"

        new_btn = QPushButton("＋ New")
        new_btn.setStyleSheet(accent_style)
        new_btn.clicked.connect(self._new_bp)
        top.addWidget(new_btn)

        save_btn = QPushButton("💾 Save")
        save_btn.setStyleSheet(accent_style)
        save_btn.clicked.connect(self._save_bp)
        top.addWidget(save_btn)

        export_btn = QPushButton("📤 Export")
        export_btn.setStyleSheet(btn_style)
        export_btn.clicked.connect(self._export_bp)
        top.addWidget(export_btn)

        import_btn = QPushButton("📥 Import")
        import_btn.setStyleSheet(btn_style)
        import_btn.clicked.connect(self._import_bp)
        top.addWidget(import_btn)

        apply_btn = QPushButton("▶ Apply")
        apply_btn.setStyleSheet(green_style)
        apply_btn.clicked.connect(self._apply_bp)
        top.addWidget(apply_btn)

        top.addStretch()

        # Status label
        self._status_lbl = QLabel("")
        self._status_lbl.setStyleSheet("color: #6b7280; font-size: 11px;")
        top.addWidget(self._status_lbl)

        layout.addLayout(top)

        # ── Node palette (horizontal scroll) ──────────────────────────────
        palette_layout = QHBoxLayout()
        palette_layout.setSpacing(4)
        palette_layout.addWidget(QLabel("Nodes:", styleSheet="color: #9ca3af; font-size: 11px;"))

        node_types = [
            ("Input", NodeType.INPUT), ("Noise Gate", NodeType.NOISE_GATE),
            ("Noise Reduct", NodeType.NOISE_REDUCTION), ("EQ", NodeType.EQUALIZER),
            ("Compressor", NodeType.COMPRESSOR), ("Pitch Shift", NodeType.PITCH_SHIFT),
            ("Voice Conv", NodeType.VOICE_CONVERSION), ("De-esser", NodeType.DEESSER),
            ("MB Comp", NodeType.MULTIBAND_COMP), ("Exciter", NodeType.EXCITER),
            ("AutoGain", NodeType.AUTOGAIN), ("Limiter", NodeType.LIMITER), ("Radio", NodeType.RADIO),
            ("Reverb", NodeType.REVERB), ("Delay", NodeType.DELAY), ("Output", NodeType.OUTPUT),
        ]
        for label, nt in node_types:
            color = NODE_COLORS.get(nt, "#6b7280")
            btn = QPushButton(label)
            btn.setFixedHeight(28)
            btn.setStyleSheet(f"QPushButton {{ background: #252736; color: #d1d5db; border: 1px solid {color}; border-radius: 4px; padding: 3px 10px; font-size: 11px; }} QPushButton:hover {{ background: {color}22; color: #fff; }}")
            btn.clicked.connect(lambda _, t=nt: self._add_node(t))
            palette_layout.addWidget(btn)

        palette_layout.addStretch()
        layout.addLayout(palette_layout)

        # ── Main content: canvas + properties ─────────────────────────────
        splitter = QSplitter(Qt.Horizontal)

        self._canvas = BlueprintCanvas()
        self._canvas.node_selected.connect(self._on_node_selected)
        self._canvas.blueprint_changed.connect(self._on_bp_changed)
        self._canvas.status_message.connect(self._status_lbl.setText)
        splitter.addWidget(self._canvas)

        self._property_panel = PropertyPanel()
        splitter.addWidget(self._property_panel)
        splitter.setStretchFactor(0, 3)
        splitter.setStretchFactor(1, 1)

        layout.addWidget(splitter, 1)

        # ── Bottom status bar ─────────────────────────────────────────────
        self._bottom_bar = QLabel("Ready")
        self._bottom_bar.setStyleSheet("color: #4b5563; font-size: 11px; padding: 2px 4px;")
        layout.addWidget(self._bottom_bar)

        # Initialise
        self._canvas.set_blueprint(self._current_blueprint)

    # -- actions ------------------------------------------------------------

    def _refresh_list(self):
        self._bp_selector.blockSignals(True)
        curr = self._bp_selector.currentText()
        self._bp_selector.clear()
        names = self._controller.get_blueprint_names()
        self._bp_selector.addItems(names)
        if curr in names:
            self._bp_selector.setCurrentText(curr)
        elif names:
            self._bp_selector.setCurrentIndex(0)
            self._on_load(names[0])
        self._bp_selector.blockSignals(False)

    def _on_load(self, name: str):
        if not name:
            return
        bp = self._controller.load_blueprint(name)
        if bp:
            self._current_blueprint = bp
            self._canvas.set_blueprint(bp)
            self._on_bp_changed()

    def _on_node_selected(self, node_id: str):
        if node_id:
            node = self._current_blueprint.get_node(node_id)
            self._property_panel.set_node(node)
        else:
            self._property_panel.set_node(None)

    def _on_bp_changed(self):
        bp = self._current_blueprint
        val = bp.validate()
        n = len(bp.nodes)
        c = len(bp.connections)
        status = f"{n} node{'s' if n != 1 else ''}, {c} connection{'s' if c != 1 else ''}"
        if val:
            status += f"  |  ⚠ {', '.join(val)}"
        self._bottom_bar.setText(status)

    def _add_node(self, node_type: NodeType):
        # Offset from existing nodes to avoid overlap
        ox = 60 + (len(self._current_blueprint.nodes) * 30) % 500
        oy = 60 + (len(self._current_blueprint.nodes) * 30) % 300
        node = make_node(node_type, float(ox), float(oy))
        self._current_blueprint.add_node(node)
        self._canvas.update()
        self._canvas.blueprint_changed.emit()

    def _save_bp(self):
        name, ok = QInputDialog.getText(self, "Save Blueprint", "Blueprint name:", text=self._current_blueprint.name)
        if not ok or not name.strip():
            return
        self._current_blueprint.name = name.strip()
        self._controller.save_blueprint(self._current_blueprint)
        self._refresh_list()
        self._bp_selector.setCurrentText(name.strip())
        self._status_lbl.setText(f"💾 Saved '{name.strip()}'")

    def _new_bp(self):
        name, ok = QInputDialog.getText(self, "New Blueprint", "Blueprint name:", text=f"Blueprint_{uuid.uuid4().hex[:4]}")
        if not ok or not name.strip():
            return
        bp = Blueprint(name=name.strip())
        bp.add_node(make_node(NodeType.INPUT, 60, 200))
        bp.add_node(make_node(NodeType.OUTPUT, 660, 200))
        bp.add_connection(NodeConnection(source_id=bp.nodes[0].id, target_id=bp.nodes[1].id))
        self._current_blueprint = bp
        self._canvas.set_blueprint(bp)
        self._controller.save_blueprint(bp)
        self._refresh_list()
        self._bp_selector.setCurrentText(bp.name)
        self._status_lbl.setText(f"New blueprint '{bp.name}' created")

    def _export_bp(self):
        path, _ = QFileDialog.getSaveFileName(self, "Export Blueprint", f"{self._current_blueprint.name}.json", "Blueprint Files (*.json)")
        if path:
            self._controller.export_blueprint(self._current_blueprint.name, path)
            self._status_lbl.setText(f"📤 Exported to {path}")

    def _import_bp(self):
        path, _ = QFileDialog.getOpenFileName(self, "Import Blueprint", "", "Blueprint Files (*.json)")
        if path:
            bp = self._controller.import_blueprint(path)
            if bp:
                self._current_blueprint = bp
                self._canvas.set_blueprint(bp)
                self._refresh_list()
                self._bp_selector.setCurrentText(bp.name)
                self._status_lbl.setText(f"📥 Imported '{bp.name}'")
            else:
                QMessageBox.warning(self, "Import Error", "Failed to import blueprint")

    def _apply_bp(self):
        self._controller.apply_blueprint(self._current_blueprint)
        self._status_lbl.setText("▶ Blueprint applied to engine")
