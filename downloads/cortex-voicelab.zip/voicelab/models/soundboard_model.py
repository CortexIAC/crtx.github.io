from dataclasses import dataclass, field
from typing import Optional


@dataclass
class SoundClip:
    id: str
    name: str
    file_path: str
    category: str = "Uncategorized"
    hotkey: Optional[str] = None
    volume: float = 1.0
    duration_ms: int = 0
    order: int = 0


@dataclass
class SoundCategory:
    name: str
    clips: list = field(default_factory=list)
    is_expanded: bool = True
    order: int = 0
