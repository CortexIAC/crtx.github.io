# Re-export from audio_engine for convenience
from audio_engine.models.profile import Profile

__all__ = ["Profile"]
