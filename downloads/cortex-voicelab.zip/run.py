#!/usr/bin/env python3
"""
Cortex VoiceLab - Quick Launch Script
"""

import os
import sys
import subprocess


def main():
    # Ensure we're in the right directory
    script_dir = os.path.dirname(os.path.abspath(__file__))
    os.chdir(script_dir)

    # Ensure the project is importable
    if script_dir not in sys.path:
        sys.path.insert(0, script_dir)

    # Install dependencies if needed
    try:
        import PySide6
        import sounddevice
        import numpy
    except ImportError:
        print("Installing dependencies...")
        subprocess.check_call([
            sys.executable, "-m", "pip", "install", "-r",
            os.path.join(script_dir, "requirements.txt")
        ])

    # Launch VoiceLab
    from voicelab.main import main as voicelab_main
    voicelab_main()


if __name__ == "__main__":
    main()
