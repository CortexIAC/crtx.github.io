╔══════════════════════════════════════════════╗
║          CIE Server - Quick Start            ║
╚══════════════════════════════════════════════╝

The Cortex Intelligence Engine as a REST API.

=== Quick Start ===

1. Install dependencies:
   pip install -r requirements.txt

2. Start the server:
   cd app && python server.py

3. Open in browser:
   http://localhost:8485

=== API Endpoints ===

GET  /health          - Server status
POST /cie/chat        - Send a chat message
GET  /cie/status      - Engine status
POST /cie/memory      - Store/retrieve memories
POST /cie/vision      - Analyze images

=== Test ===
   python app/test_chat.py
