"""Get the ngrok URL."""
import httpx
try:
    r = httpx.get("http://127.0.0.1:4040/api/tunnels", timeout=5)
    tunnels = r.json().get("tunnels", [])
    for t in tunnels:
        print(f"ngrok URL: {t['public_url']}")
        print(f"Chat:      {t['public_url']}/chat")
        print(f"Share this with your friends!")
except Exception as e:
    print(f"Could not get ngrok URL: {e}")
    print("Check the ngrok terminal window that opened.")
