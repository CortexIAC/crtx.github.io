/* Synapse PWA — unified service worker for all apps */
const CACHE = "synapse-v1";
const ASSETS = ["/chat", "/notes", "/nexus", "/"];

self.addEventListener("install", (e) => {
  e.waitUntil(caches.open(CACHE).then((c) => c.addAll(ASSETS)));
  self.skipWaiting();
});

self.addEventListener("activate", (e) => {
  e.waitUntil(clients.claim());
});

// Network-first: try network, fall back to cache
self.addEventListener("fetch", (e) => {
  if (e.request.method !== "GET") return;
  // Only cache our own pages
  const url = new URL(e.request.url);
  if (url.origin !== self.location.origin) return;

  e.respondWith(
    fetch(e.request)
      .then((r) => {
        // Cache successful responses
        if (r.status === 200) {
          const clone = r.clone();
          caches.open(CACHE).then((c) => c.put(e.request, clone));
        }
        return r;
      })
      .catch(() => caches.match(e.request))
  );
});
