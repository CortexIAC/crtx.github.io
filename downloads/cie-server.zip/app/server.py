"""CIE Runtime Server — exposes Cortex Intelligence Engine as a FastAPI service."""

import sys, os, json, uuid, time
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "synapse-cie"))
# Add FloraNode path for database access
_flora_path = os.path.join(os.path.dirname(__file__), "..", "FloraNode")
if os.path.exists(_flora_path):
    sys.path.insert(0, _flora_path)

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional, List
import subprocess, tempfile, textwrap

from cie.engine import get_cie
from cie.events import get_bus, EVENT_TYPES
from cie.scenes import SceneManager

app = FastAPI(title="CIE Runtime", version="0.1.0", description="Cortex Intelligence Engine — shared intelligence runtime")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

# Initialize event bus on startup
@app.on_event("startup")
def startup():
    bus = get_bus()
    # Built-in events are already registered in engine._init_events

cie = get_cie()

# ── Schemas ────────────────────────────────────────────────────────────

class ChatRequest(BaseModel):
    message: str
    application: str = "default"
    project: str = "default"
    conversation_id: Optional[str] = None
    model: str = ""
    plant_ids: Optional[List[str]] = None
    temperature: float = 0.2

class ChatResponse(BaseModel):
    response: str
    conversation_id: str
    message_count: int
    elapsed_seconds: float
    context_used: dict

class StoreMemoryRequest(BaseModel):
    namespace: str
    key: str
    value: str

class SearchMemoryRequest(BaseModel):
    namespace: str
    query: str

# ── Routes ─────────────────────────────────────────────────────────────

@app.get("/health")
def health():
    return {"status": "ok", "version": "0.1.0", "cie": "running"}

@app.post("/cie/chat", response_model=ChatResponse)
def chat(req: ChatRequest):
    start = time.time()
    try:
        result = cie.chat(
            message=req.message,
            application=req.application,
            project=req.project,
            conversation_id=req.conversation_id,
            model=req.model,
            plant_ids=req.plant_ids,
            temperature=req.temperature,
        )
        return ChatResponse(
            response=result["response"],
            conversation_id=result["conversation_id"],
            message_count=result["message_count"],
            elapsed_seconds=result["metrics"]["elapsed_seconds"],
            context_used=result["context_used"],
        )
    except Exception as e:
        raise HTTPException(500, str(e))

@app.get("/cie/status")
def status():
    return cie.get_stats()

@app.get("/cie/conversations")
def list_conversations(project: str = "default"):
    convs = cie.conversations.list(project)
    return [{"id": c.id, "project": c.project, "messages": c.message_count, "created": c.created_at} for c in convs]

@app.delete("/cie/conversations/{conv_id}")
def delete_conversation(conv_id: str):
    cie.conversations.delete(conv_id)
    return {"deleted": conv_id}

@app.get("/cie/conversations/{conv_id}")
def get_conversation(conv_id: str):
    conv = cie.conversations.get(conv_id)
    if not conv:
        raise HTTPException(404, "Conversation not found")
    return {"id": conv.id, "project": conv.project, "messages": conv.get_history(100), "message_count": conv.message_count}

@app.post("/cie/memory/store")
def store_memory(req: StoreMemoryRequest):
    cie.memory.store(req.namespace, req.key, req.value)
    return {"stored": True}

@app.get("/cie/memory/get")
def get_memory(namespace: str, key: str):
    val = cie.memory.get(namespace, key)
    if val is None:
        raise HTTPException(404, "Key not found")
    return {"namespace": namespace, "key": key, "value": val}

@app.post("/cie/memory/search")
def search_memory(req: SearchMemoryRequest):
    results = cie.memory.search(req.namespace, req.query)
    return {"results": results}

@app.get("/cie/memory/namespaces")
def list_namespaces():
    return {"namespaces": cie.memory.list_namespaces()}

@app.post("/cie/vision/analyze")
def vision_analyze(image_path: str):
    """Analyze a plant photo through CIE's Vision Engine."""
    result = cie.execute("vision.analyze", image_path=image_path)
    return result

@app.post("/cie/vision/compare")
def vision_compare(photo1_path: str, photo2_path: str):
    """Compare two plant photos."""
    result = cie.execute("vision.compare", photo1_path=photo1_path, photo2_path=photo2_path)
    return result

@app.get("/cie/capabilities")
def list_capabilities(subsystem: str = None):
    """List all registered capabilities."""
    caps = cie.registry.list(subsystem)
    return {"capabilities": [c.to_dict() for c in caps]}

@app.get("/cie/capabilities/search")
def search_capabilities(query: str):
    """Search capabilities by name or description."""
    caps = cie.registry.search(query)
    return {"capabilities": [c.to_dict() for c in caps]}

# ── Scenes ─────────────────────────────────────────────────────────────

@app.get("/cie/scenes")
def list_scenes():
    """List all available scenes."""
    scenes = cie.scenes.list() if cie.scenes else []
    return {"scenes": [s.to_dict() for s in scenes]}

class ActivateSceneRequest(BaseModel):
    scene_id: str

@app.post("/cie/scenes/activate")
def activate_scene(req: ActivateSceneRequest):
    """Activate a scene."""
    if not cie.scenes:
        return {"error": "Scene manager not available"}
    result = cie.scenes.activate(req.scene_id)
    return result

# ── Events ─────────────────────────────────────────────────────────────

class ExecPythonRequest(BaseModel):
    code: str
    timeout: int = 10

class SensorReading(BaseModel):
    device: str = "esp32_1"
    temperature: Optional[float] = None
    humidity: Optional[float] = None
    soil_moisture: Optional[int] = None
    light_ppfd: Optional[int] = None
    co2: Optional[int] = None
    plant_id: Optional[str] = None

class EmitEventRequest(BaseModel):
    type: str
    data: dict = {}
    source: str = "api"

@app.post("/cie/events/emit")
def emit_event(req: EmitEventRequest):
    """Emit an event to the bus."""
    get_bus().emit(req.type, req.data, req.source)
    return {"emitted": req.type}

@app.get("/cie/events/history")
def event_history(event_type: str = None, limit: int = 50):
    """Get recent event history."""
    events = get_bus().history(event_type, limit)
    return {"events": [e.to_dict() for e in events]}

@app.get("/cie/events/types")
def event_types():
    """List all built-in event types."""
    return {"event_types": EVENT_TYPES}

# ── Encrypted Chat ─────────────────────────────────────────────────────

import os, base64
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC

chat_rooms: dict = {}  # room_id -> list of messages

class SendChatMessage(BaseModel):
    room: str = "general"
    username: str
    message: str
    password: str = ""

@app.post("/cie/chat/send")
def chat_send(msg: SendChatMessage):
    """Send an encrypted chat message to a room."""
    if msg.password:
        salt = os.urandom(16)
        kdf = PBKDF2HMAC(algorithm=hashes.SHA256(), length=32, salt=salt, iterations=100000)
        key = base64.urlsafe_b64encode(kdf.derive(msg.password.encode()))
        f = Fernet(key)
        encrypted = f.encrypt(msg.message.encode())
        payload = base64.urlsafe_b64encode(salt + encrypted).decode()
    else:
        payload = msg.message

    if msg.room not in chat_rooms:
        chat_rooms[msg.room] = []
    chat_rooms[msg.room].append({
        "id": os.urandom(4).hex(),
        "username": msg.username,
        "payload": payload,
        "encrypted": bool(msg.password),
        "timestamp": time.time(),
    })
    # Keep last 200 messages
    if len(chat_rooms[msg.room]) > 200:
        chat_rooms[msg.room] = chat_rooms[msg.room][-200:]

    return {"sent": True, "message_count": len(chat_rooms[msg.room])}

class GetChatMessages(BaseModel):
    room: str = "general"
    password: str = ""
    since: float = 0

@app.post("/cie/chat/messages")
def chat_messages(req: GetChatMessages):
    """Get messages from a room, optionally decrypting."""
    msgs = chat_rooms.get(req.room, [])
    result = []
    for m in msgs:
        if m["timestamp"] < req.since:
            continue
        content = m["payload"]
        if m["encrypted"] and req.password:
            try:
                raw = base64.urlsafe_b64decode(content.encode())
                salt, token = raw[:16], raw[16:]
                kdf = PBKDF2HMAC(algorithm=hashes.SHA256(), length=32, salt=salt, iterations=100000)
                key = base64.urlsafe_b64encode(kdf.derive(req.password.encode()))
                f = Fernet(key)
                content = f.decrypt(token).decode()
            except Exception:
                content = "[🔒 Encrypted]"
        elif m["encrypted"]:
            content = "[🔒 Encrypted]"
        result.append({
            "id": m["id"],
            "username": m["username"],
            "message": content,
            "encrypted": m["encrypted"],
            "timestamp": m["timestamp"],
        })
    return {"messages": result, "room": req.room}

# ── Static Pages ───────────────────────────────────────────────────────

import os as _os
from fastapi.responses import HTMLResponse
_static_dir = _os.path.join(_os.path.dirname(__file__), "static")
_os.makedirs(_static_dir, exist_ok=True)

@app.get("/", include_in_schema=False)
@app.get("/nexus", include_in_schema=False)
def nexus_page():
    path = _os.path.join(_static_dir, "nexus.html")
    if _os.path.exists(path):
        content = open(path, encoding="utf-8").read()
        return HTMLResponse(content, headers={"Cache-Control": "no-cache"})
    return HTMLResponse("<h1>Nexus Hub not found</h1>")

@app.get("/connect", include_in_schema=False)
def connect_page():
    path = _os.path.join(_static_dir, "connect.html")
    if _os.path.exists(path):
        return HTMLResponse(open(path, encoding="utf-8").read(), headers={"Cache-Control": "no-cache"})
    return HTMLResponse("<h1>Connect not found</h1>")

@app.post("/cie/exec/python")
def exec_python(req: ExecPythonRequest):
    """Execute a Python snippet and return stdout/stderr."""
    import time, io, contextlib
    start = time.time()
    stdout = io.StringIO()
    stderr = io.StringIO()

    # Add common imports to namespace
    namespace = {
        "httpx": __import__("httpx"),
        "json": __import__("json"),
        "os": __import__("os"),
        "sys": __import__("sys"),
        "datetime": __import__("datetime"),
        "math": __import__("math"),
        "re": __import__("re"),
    }

    try:
        with contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr):
            exec(req.code, namespace)
        elapsed = round(time.time() - start, 2)
        out = stdout.getvalue()
        err = stderr.getvalue()
        return {
            "success": True,
            "stdout": out,
            "stderr": err,
            "elapsed": elapsed,
        }
    except Exception as e:
        elapsed = round(time.time() - start, 2)
        return {
            "success": False,
            "stdout": stdout.getvalue(),
            "stderr": stderr.getvalue(),
            "error": str(e),
            "elapsed": elapsed,
        }

@app.get("/exec", include_in_schema=False)
def exec_page():
    path = _os.path.join(_static_dir, "exec.html")
    if _os.path.exists(path):
        return HTMLResponse(open(path, encoding="utf-8").read(), headers={"Cache-Control": "no-cache"})
    return HTMLResponse("<h1>Exec not found</h1>")

@app.get("/notes", include_in_schema=False)
def notes_page():
    path = _os.path.join(_static_dir, "notes.html")
    if _os.path.exists(path):
        return HTMLResponse(open(path, encoding="utf-8").read(), headers={"Cache-Control": "no-cache"})
    return HTMLResponse("<h1>Notes not found</h1>")

@app.get("/chat", include_in_schema=False)
def chat_page():
    path = _os.path.join(_static_dir, "chat.html")
    if _os.path.exists(path):
        content = open(path, encoding="utf-8").read()
        return HTMLResponse(content, headers={"Cache-Control": "no-cache"})
    return HTMLResponse("<h1>Chat client not found</h1>")

@app.get("/chat-manifest.json", include_in_schema=False)
def chat_manifest():
    from fastapi.responses import FileResponse
    path = _os.path.join(_static_dir, "chat-manifest.json")
    if _os.path.exists(path):
        return FileResponse(path, media_type="application/manifest+json")
    return HTMLResponse("{}")

@app.get("/connect-manifest.json", include_in_schema=False)
def connect_manifest():
    from fastapi.responses import FileResponse
    path = _os.path.join(_static_dir, "connect-manifest.json")
    if _os.path.exists(path):
        return FileResponse(path, media_type="application/manifest+json")
    return HTMLResponse("{}")

@app.get("/notes-manifest.json", include_in_schema=False)
def notes_manifest():
    from fastapi.responses import FileResponse
    path = _os.path.join(_static_dir, "notes-manifest.json")
    if _os.path.exists(path):
        return FileResponse(path, media_type="application/manifest+json")
    return HTMLResponse("{}")

@app.get("/sw.js", include_in_schema=False)
def service_worker():
    path = _os.path.join(_static_dir, "sw.js")
    if _os.path.exists(path):
        from fastapi.responses import FileResponse
        return FileResponse(path, media_type="application/javascript")
    return HTMLResponse("")

# ── Main ───────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import uvicorn
    print(f"  CIE Runtime: http://127.0.0.1:8485")
    print(f"  Chat:        http://127.0.0.1:8485/chat")
    print(f"  Docs:        http://127.0.0.1:8485/docs")
    uvicorn.run(app, host="0.0.0.0", port=8485)
