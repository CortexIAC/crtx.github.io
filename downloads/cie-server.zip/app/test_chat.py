"""Test CIE Server chat endpoints."""
import httpx

BASE = "http://127.0.0.1:8485"

# Check server
r = httpx.get(f"{BASE}/health", timeout=5)
print(f"Server: {r.status_code}")

# Check chat page
r = httpx.get(f"{BASE}/chat", timeout=5)
print(f"Chat page: {r.status_code} ({len(r.text)} bytes)")

# Send unencrypted
r = httpx.post(f"{BASE}/cie/chat/send", json={"room": "test", "username": "Dom", "message": "Hello world"}, timeout=5)
print(f"Send: {r.status_code} {r.json()}")

# Get messages
r = httpx.post(f"{BASE}/cie/chat/messages", json={"room": "test", "since": 0}, timeout=5)
data = r.json()
print(f"Messages: {r.status_code} ({len(data['messages'])} msgs)")
for m in data["messages"]:
    print(f"  {m['username']}: {m['message']}")

# Send encrypted
r = httpx.post(f"{BASE}/cie/chat/send", json={"room": "test", "username": "Dom", "message": "Secret message", "password": "test123"}, timeout=5)
print(f"Encrypted send: {r.status_code}")

# Get encrypted (without password - should show lock)
r = httpx.post(f"{BASE}/cie/chat/messages", json={"room": "test", "since": 0}, timeout=5)
data = r.json()
for m in data["messages"]:
    badge = "🔒" if m["encrypted"] else "  "
    print(f"  {badge} {m['username']}: {m['message'][:40]}")

# Get encrypted (with password - should decrypt)
r = httpx.post(f"{BASE}/cie/chat/messages", json={"room": "test", "password": "test123", "since": 0}, timeout=5)
data = r.json()
for m in data["messages"]:
    if m["encrypted"]:
        print(f"  🔓 Decrypted: {m['message']}")

print("\nAll chat tests passed!")
