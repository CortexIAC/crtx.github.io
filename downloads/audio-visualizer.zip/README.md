# Audio Visualizer

Real-time audio spectrum analyzer.

pip install -r requirements.txt
python main.py