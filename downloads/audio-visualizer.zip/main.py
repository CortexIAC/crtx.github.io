import sys, numpy as np, colorsys
from PyQt6.QtWidgets import QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QPushButton
from PyQt6.QtCore import Qt, QTimer
from PyQt6.QtGui import QPainter, QColor, QPen, QFont

CHUNK, RATE = 1024, 44100
try:
    import pyaudio; AUDIO = True
except: AUDIO = False

class Viz(QWidget):
    def __init__(self):
        super().__init__()
        self.data = np.zeros(CHUNK//2); self.mode = 0
        self.setMinimumSize(600,300)

    def update_data(self, raw):
        if raw is None: return
        a = np.frombuffer(raw, dtype=np.int16).astype(np.float32)
        if len(a) < CHUNK: a = np.pad(a, (0, CHUNK-len(a)))
        self.data = 20 * np.log10(np.maximum(np.abs(np.fft.rfft(a[:CHUNK]))/CHUNK, 1e-10))
        self.update()

    def paintEvent(self, e):
        p = QPainter(self); w, h = self.width(), self.height()
        p.fillRect(0,0,w,h, QColor(10,10,10))
        p.setPen(QColor(100,100,100)); p.setFont(QFont("Courier New",10))
        p.drawText(10,20, ["Waveform","Spectrum","Waterfall"][self.mode])
        n = len(self.data)
        if n < 2: return
        if self.mode == 0:
            p.setPen(QPen(QColor(0,255,156),2))
            for i in range(n-1):
                x1 = int(i*w/n); y1 = int(h - max(0,min(1,self.data[i]/80))*h*0.9 - h*0.05)
                x2 = int((i+1)*w/n); y2 = int(h - max(0,min(1,self.data[i+1]/80))*h*0.9 - h*0.05)
                p.drawLine(x1,y1,x2,y2)
        elif self.mode == 1:
            bw = max(1, w//(n//2))
            for i in range(n//2):
                v = max(0,min(1,self.data[i]/80)); bh = int(v*h*0.9)
                r,g,b = [int(c*255) for c in colorsys.hsv_to_rgb(0.3+v*0.3,0.9,0.9)]
                p.fillRect(int(i*bw), h-bh, bw-1, bh, QColor(r,g,b))

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__(); self.setWindowTitle("Audio Visualizer"); self.resize(800,500)
        c = QWidget(); l = QVBoxLayout(c); self.setCentralWidget(c)
        self.v = Viz(); l.addWidget(self.v)
        h = QHBoxLayout()
        b = QPushButton("Toggle Mode"); b.clicked.connect(lambda: setattr(self.v,'mode',(self.v.mode+1)%3)); h.addWidget(b)
        self.cb = QPushButton("Start" if AUDIO else "No PyAudio")
        if AUDIO: self.cb.clicked.connect(self.toggle)
        h.addWidget(self.cb); h.addStretch(); l.addLayout(h)
        if AUDIO:
            self.audio = pyaudio.PyAudio(); self.stream = None; self.cap = False
            self.timer = QTimer(); self.timer.timeout.connect(self.read_a)

    def toggle(self):
        if self.cap:
            if self.stream: self.stream.stop_stream(); self.stream.close(); self.stream = None
            self.timer.stop(); self.cap = False; self.cb.setText("Start")
        else:
            try:
                self.stream = self.audio.open(format=pyaudio.paInt16,channels=1,rate=RATE,input=True,frames_per_buffer=CHUNK)
                self.cap = True; self.cb.setText("Stop"); self.timer.start(30)
            except Exception as e: self.cb.setText(str(e))

    def read_a(self):
        if self.stream and self.cap:
            try: self.v.update_data(self.stream.read(CHUNK,exception_on_overflow=False))
            except: pass

if __name__ == "__main__":
    app = QApplication(sys.argv); app.setStyle("Fusion")
    w = MainWindow(); w.show(); app.exec()