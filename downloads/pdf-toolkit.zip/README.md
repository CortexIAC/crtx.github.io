# PDF Toolkit

Merge and manage PDF files.

pip install -r requirements.txt
python main.py