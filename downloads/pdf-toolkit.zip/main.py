import sys, os
from PyQt6.QtWidgets import QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QListWidget, QFileDialog, QTextEdit, QLabel
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QFont

# Check for PDF libraries
try:
    import PyPDF2; PDF_AVAIL = True
except: PDF_AVAIL = False

class PDFToolkit(QMainWindow):
    def __init__(self):
        super().__init__(); self.setWindowTitle("PDF Toolkit"); self.resize(700,500)
        self.files = []
        c = QWidget(); l = QVBoxLayout(c); self.setCentralWidget(c)
        h = QHBoxLayout()
        btn_add = QPushButton("Add PDFs"); btn_add.clicked.connect(self.add_files); h.addWidget(btn_add)
        btn_merge = QPushButton("Merge"); btn_merge.clicked.connect(self.merge); h.addWidget(btn_merge)
        btn_clear = QPushButton("Clear"); btn_clear.clicked.connect(self.clear); h.addWidget(btn_clear)
        l.addLayout(h)
        self.list_w = QListWidget(); l.addWidget(self.list_w)
        self.status = QTextEdit(); self.status.setReadOnly(True); self.status.setMaximumHeight(100)
        self.status.setStyleSheet("background:#0d0d0d;color:#00ff9c;font-family:Courier New;")
        self.status.setText("PDF Toolkit v2.0.0\nAdd PDF files and use Merge to combine them.")
        l.addWidget(self.status)
        if not PDF_AVAIL:
            self.status.setText("PyPDF2 not installed.\nRun: pip install PyPDF2")

    def add_files(self):
        files, _ = QFileDialog.getOpenFileNames(self, "Select PDFs", "", "PDF Files (*.pdf)")
        for f in files:
            if f not in self.files:
                self.files.append(f)
                self.list_w.addItem(os.path.basename(f) + f" ({os.path.getsize(f)//1024} KB)")

    def merge(self):
        if len(self.files) < 2:
            self.status.setText("Add at least 2 PDF files to merge.")
            return
        if not PDF_AVAIL:
            self.status.setText("Install PyPDF2: pip install PyPDF2")
            return
        try:
            import PyPDF2
            merger = PyPDF2.PdfMerger()
            for f in self.files:
                merger.append(f)
            out, _ = QFileDialog.getSaveFileName(self, "Save Merged PDF", "merged.pdf", "PDF Files (*.pdf)")
            if out:
                merger.write(out)
                merger.close()
                self.status.setText(f"Merged {len(self.files)} files into:\n{out}")
        except Exception as e:
            self.status.setText(f"Error: {e}")

    def clear(self):
        self.files.clear(); self.list_w.clear(); self.status.setText("Cleared.")

if __name__ == "__main__":
    app = QApplication(sys.argv); app.setStyle("Fusion")
    w = PDFToolkit(); w.show(); app.exec()