import sys, socket, ipaddress, concurrent.futures
from PyQt6.QtWidgets import QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QLineEdit, QTextEdit, QLabel
from PyQt6.QtCore import Qt, QThread, pyqtSignal
from PyQt6.QtGui import QFont

class Scanner(QMainWindow):
    def __init__(self):
        super().__init__(); self.setWindowTitle("Network Scanner"); self.resize(700,500)
        c = QWidget(); l = QVBoxLayout(c); self.setCentralWidget(c)
        h = QHBoxLayout()
        self.input = QLineEdit(); self.input.setPlaceholderText("192.168.1.0/24")
        self.input.setStyleSheet("padding:8px;font-size:14px;")
        h.addWidget(QLabel("Subnet:")); h.addWidget(self.input)
        btn = QPushButton("Scan"); btn.clicked.connect(self.scan); h.addWidget(btn)
        l.addLayout(h)
        self.output = QTextEdit(); self.output.setReadOnly(True)
        self.output.setStyleSheet("background:#0d0d0d;color:#00ff9c;font-family:Courier New;font-size:13px;")
        l.addWidget(self.output)
        self.output.setText("Network Scanner v1.3.0\nEnter a subnet (e.g. 192.168.1.0/24) and click Scan.")

    def scan(self):
        subnet = self.input.text().strip()
        if not subnet:
            self.output.setText("Enter a subnet, e.g. 192.168.1.0/24"); return
        self.output.setText("Scanning...")
        QApplication.processEvents()
        try:
            net = ipaddress.ip_network(subnet, strict=False)
            hosts = []
            with concurrent.futures.ThreadPoolExecutor(max_workers=100) as ex:
                results = {ex.submit(self.ping, str(ip)): str(ip) for ip in net.hosts()}
                for f in concurrent.futures.as_completed(results):
                    if f.result(): hosts.append(results[f])
            hosts.sort(key=lambda x: [int(o) for o in x.split(".")])
            result = f"Scan complete: {len(hosts)} hosts found\n{'-'*40}\n"
            for h in hosts:
                try:
                    name = socket.gethostbyaddr(h)[0] if h else h
                except: name = h
                # Quick port check on common ports
                ports = []
                for p in [22,80,443,8080]:
                    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                    s.settimeout(0.3)
                    if s.connect_ex((h, p)) == 0: ports.append(str(p))
                    s.close()
                result += f"{h:15} {name:20} ports: {','.join(ports) if ports else 'none'}\n"
            self.output.setText(result)
        except Exception as e:
            self.output.setText(f"Error: {e}")

    def ping(self, ip):
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(0.3)
            r = s.connect_ex((ip, 80))
            s.close()
            return r == 0
        except: return False

if __name__ == "__main__":
    app = QApplication(sys.argv); app.setStyle("Fusion")
    w = Scanner(); w.show(); app.exec()