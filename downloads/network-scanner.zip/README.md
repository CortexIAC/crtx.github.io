# Network Scanner

LAN discovery and port scanner.

pip install -r requirements.txt
python main.py