import json
import os


class Storage:

    NOTES_DIR = "data/notes"

    @classmethod
    def save_note(cls, note_name, content):

        os.makedirs(
            cls.NOTES_DIR,
            exist_ok=True
        )

        path = os.path.join(
            cls.NOTES_DIR,
            f"{note_name}.cortexnote"
        )

        with open(
                path,
                "w",
                encoding="utf-8"
        ) as f:

            json.dump(
                {
                    "title": note_name,
                    "content": content
                },
                f,
                indent=4
            )

    @classmethod
    def load_note(cls, note_name):

        path = os.path.join(
            cls.NOTES_DIR,
            f"{note_name}.cortexnote"
        )

        if not os.path.exists(path):
            return ""

        with open(
                path,
                "r",
                encoding="utf-8"
        ) as f:

            data = json.load(f)

        return data.get(
            "content",
            ""
        )