from core.storage import Storage


class NoteManager:

    def save(
            self,
            title,
            content
    ):
        Storage.save_note(
            title,
            content
        )

    def load(
            self,
            title
    ):
        return Storage.load_note(
            title
        )