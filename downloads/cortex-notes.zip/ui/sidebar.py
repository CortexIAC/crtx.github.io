import tkinter as tk


class Sidebar(tk.Frame):

    def __init__(
            self,
            parent
    ):

        super().__init__(
            parent,
            bg="#16161a",
            width=220
        )

        self.pack_propagate(False)

        tk.Label(

            self,

            text="WORKSPACES",

            bg="#16161a",

            fg="#00ff88"

        ).pack(
            pady=10
        )

        self.workspace_list = tk.Listbox(

            self,

            bg="#1c1c22",

            fg="#e4e4e7"
        )

        self.workspace_list.pack(
            fill="both",
            expand=True,
            padx=5,
            pady=5
        )

        self.workspace_list.insert(
            "end",
            "Personal"
        )

        self.workspace_list.insert(
            "end",
            "Synapse Core"
        )

        self.workspace_list.insert(
            "end",
            "Nexus"
        )

        self.workspace_list.insert(
            "end",
            "WaveGuard"
        )