import tkinter as tk

from ui.sidebar import Sidebar
from ui.editor import Editor

from core.note_manager import NoteManager


class MainWindow(tk.Tk):

    def __init__(self):

        super().__init__()

        self.note_manager = NoteManager()

        self.title(
            "Cortex Notes"
        )

        self.geometry(
            "1200x800"
        )

        self.configure(
            bg="#0e0e11"
        )

        self.sidebar = Sidebar(
            self
        )

        self.sidebar.pack(
            side="left",
            fill="y"
        )

        right = tk.Frame(
            self,
            bg="#0e0e11"
        )

        right.pack(
            side="right",
            fill="both",
            expand=True
        )

        toolbar = tk.Frame(
            right,
            bg="#16161a"
        )

        toolbar.pack(
            fill="x"
        )

        tk.Button(

            toolbar,

            text="Save",

            command=self.save_note

        ).pack(
            side="left",
            padx=5,
            pady=5
        )

        self.editor = Editor(
            right
        )

        self.editor.pack(
            fill="both",
            expand=True
        )

    def save_note(self):

        content = self.editor.get(
            "1.0",
            "end"
        )

        self.note_manager.save(

            "Untitled",

            content

        )

        print(
            "NOTE SAVED"
        )