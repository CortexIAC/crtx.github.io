import tkinter as tk


class Editor(tk.Text):

    def __init__(
            self,
            parent
    ):

        super().__init__(

            parent,

            bg="#111111",
            fg="#e4e4e7",

            insertbackground="#00ff88",

            font=(
                "Consolas",
                11
            ),

            wrap="word"
        )