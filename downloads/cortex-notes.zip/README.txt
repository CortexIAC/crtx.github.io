╔══════════════════════════════════════════════╗
║          Cortex Notes - Quick Start          ║
╚══════════════════════════════════════════════╝

Simple note-taking app with persistent storage.

=== Quick Start ===

1. No dependencies needed! (uses built-in tkinter)
2. Run:
   python main.py

=== Features ===
- Create, edit, and organize notes
- Workspace management
- Persistent JSON storage
- Clean sidebar interface
