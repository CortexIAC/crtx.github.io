# Synapse Core Terminal

Unified terminal + file browser + CIE agent.

pip install -r requirements.txt
python main.py