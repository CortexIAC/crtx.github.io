import sys, os, subprocess, json, threading, queue, time
from PyQt6.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QSplitter, QTextEdit, QTreeWidget, QTreeWidgetItem, QPushButton, QLabel, QLineEdit,
    QTabWidget, QMenuBar, QMenu, QStatusBar, QInputDialog, QMessageBox, QFileDialog)
from PyQt6.QtCore import Qt, QTimer, pyqtSignal, QThread
from PyQt6.QtGui import QFont, QColor, QTextCursor, QAction, QKeySequence, QSyntaxHighlighter, QIcon

# ─── CIE Agent Integration ───
class CIEAgent:
    def __init__(self, status_callback=None):
        self.status_callback = status_callback

    def plan(self, goal):
        return {
            "goal": goal,
            "steps": [
                {"id": 1, "action": "think", "description": f"Analyzing request: {goal}", "details": goal},
                {"id": 2, "action": "search", "description": "Finding relevant files", "details": goal},
                {"id": 3, "action": "read", "description": "Reading matched files", "file": "."},
                {"id": 4, "action": "think", "description": "Planning implementation", "details": ""},
                {"id": 5, "action": "done", "description": "Complete", "details": ""}
            ]
        }

    def execute(self, plan, project_path="."):
        results = []
        for i, step in enumerate(plan["steps"]):
            if self.status_callback:
                self.status_callback(f"Step {i+1}/{len(plan['steps'])}: {step['description']}")
            if step["action"] == "search":
                q = step.get("details", "")
                out = []
                for r, d, f in os.walk(project_path):
                    for fn in f:
                        if fn.endswith((".py",".js",".html",".css",".json",".md",".txt")):
                            fp = os.path.join(r, fn)
                            try:
                                with open(fp, "r", encoding="utf-8", errors="replace") as fh:
                                    for ln, line in enumerate(fh, 1):
                                        if q.lower() in line.lower():
                                            out.append(f"{os.path.relpath(fp, project_path)}:{ln}")
                                            if len(out) >= 20: break
                            except: pass
                results.append({"step": i, "action": "search", "found": len(out), "matches": out[:10]})
            elif step["action"] == "read":
                files = []
                for r, d, f in os.walk(project_path):
                    for fn in f:
                        if fn.endswith((".py",".js",".json",".md",".txt")):
                            fp = os.path.join(r, fn)
                            rel = os.path.relpath(fp, project_path)
                            try:
                                content = open(fp, "r", encoding="utf-8", errors="replace").read()
                                files.append({"file": rel, "size": len(content), "preview": content[:200]})
                            except: pass
                results.append({"step": i, "action": "read", "files": files})
            elif step["action"] == "think":
                results.append({"step": i, "action": "think", "result": f"Analyzed: {step['details']}"})
            elif step["action"] == "done":
                results.append({"step": i, "action": "done"})
                break
        return {"plan": plan, "results": results, "status": "complete"}

# ─── MAIN WINDOW ───
class SynapseCore(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Synapse Core Terminal")
        self.resize(1200, 800)
        self.project_path = os.getcwd()
        self.agent = CIEAgent(self.status_message)
        self.init_ui()

    def status_message(self, msg):
        self.status_bar.showMessage(msg)
        QApplication.processEvents()

    def init_ui(self):
        # Menu
        mb = self.menuBar()
        file_menu = mb.addMenu("File")
        a = QAction("Open Project...", self); a.setShortcut(QKeySequence("Ctrl+O"))
        a.triggered.connect(self.open_project)
        file_menu.addAction(a)
        a2 = QAction("Exit", self); a2.setShortcut(QKeySequence("Ctrl+Q"))
        a2.triggered.connect(self.close)
        file_menu.addAction(a2)

        agent_menu = mb.addMenu("Agent")
        a3 = QAction("Run Agent...", self); a3.setShortcut(QKeySequence("Ctrl+R"))
        a3.triggered.connect(self.run_agent)
        agent_menu.addAction(a3)

        # Main splitter
        splitter = QSplitter(Qt.Orientation.Horizontal)

        # Left panel - file tree + terminal
        left = QWidget()
        left_layout = QVBoxLayout(left)
        left_layout.setContentsMargins(0, 0, 0, 0)

        self.file_tree = QTreeWidget()
        self.file_tree.setHeaderLabel("Project Files")
        self.file_tree.setStyleSheet("background:#0d0d0d;color:#ccc;font-family:Courier New;font-size:12px;")
        self.file_tree.itemClicked.connect(self.open_file)
        left_layout.addWidget(self.file_tree)

        # Terminal tab
        self.terminal = QTextEdit()
        self.terminal.setReadOnly(False)
        self.terminal.setFont(QFont("Courier New", 11))
        self.terminal.setStyleSheet("background:#0a0a0a;color:#00ff9c;border:none;")
        self.terminal.append("Synapse Core Terminal v0.1.0")
        self.terminal.append("Type commands or 'agent' to run CIE agent")
        self.terminal.append("-" * 50)
        self.terminal.installEventFilter(self)
        self.terminal.textChanged.connect(self.on_terminal_input)

        tabs = QTabWidget()
        tabs.addTab(self.terminal, "Terminal")
        left_layout.addWidget(tabs)

        # Right panel - agent output + file viewer
        right = QWidget()
        right_layout = QVBoxLayout(right)
        right_layout.setContentsMargins(0, 0, 0, 0)

        self.output = QTextEdit()
        self.output.setReadOnly(True)
        self.output.setFont(QFont("Courier New", 11))
        self.output.setStyleSheet("background:#0d0d0d;color:#ccc;border:none;")
        self.output.append("Agent Output")

        right_tabs = QTabWidget()
        right_tabs.addTab(self.output, "Agent")
        right_layout.addWidget(right_tabs)

        splitter.addWidget(left)
        splitter.addWidget(right)
        splitter.setSizes([600, 600])

        self.setCentralWidget(splitter)
        self.status_bar = QStatusBar()
        self.setStatusBar(self.status_bar)
        self.status_bar.showMessage("Ready")

        self.load_file_tree()

    def load_file_tree(self, path=None):
        self.file_tree.clear()
        path = path or self.project_path
        root = QTreeWidgetItem(self.file_tree, [os.path.basename(path) or "Project"])
        self._populate(root, path)
        root.setExpanded(True)

    def _populate(self, parent, path):
        try:
            for item in sorted(os.listdir(path)):
                if item.startswith(".") or item == "__pycache__": continue
                full = os.path.join(path, item)
                child = QTreeWidgetItem(parent, [item])
                if os.path.isdir(full):
                    self._populate(child, full)
                    child.setChildIndicatorPolicy(QTreeWidgetItem.ChildIndicatorPolicy.ShowIndicator)
        except: pass

    def open_file(self, item, col):
        path = os.path.join(self.project_path, item.text(0))
        if os.path.isfile(path):
            try:
                with open(path, "r", encoding="utf-8", errors="replace") as f:
                    content = f.read()
                self.output.setPlainText(content[:10000])
                self.output.setStyleSheet("background:#0d0d0d;color:#00ff9c;")
            except: pass

    def open_project(self):
        path = QFileDialog.getExistingDirectory(self, "Open Project")
        if path:
            self.project_path = path
            self.load_file_tree()
            self.status_bar.showMessage(f"Project: {path}")

    def run_agent(self):
        goal, ok = QInputDialog.getText(self, "CIE Agent", "What do you want to do?")
        if not ok or not goal.strip(): return
        self.output.clear()
        self.output.append(f"🤖 CIE Agent: {goal}")
        self.output.append("-" * 50 + "\n")
        QApplication.processEvents()

        plan = self.agent.plan(goal)
        self.output.append(f"📋 Plan ({len(plan['steps'])} steps):")
        for s in plan["steps"]:
            self.output.append(f"  {s['id']}. [{s['action']}] {s['description']}")
        self.output.append("")
        QApplication.processEvents()

        result = self.agent.execute(plan, self.project_path)
        for r in result["results"]:
            if r.get("action") == "search":
                self.output.append(f"🔍 Found {r.get('found', 0)} matches:")
                for m in r.get("matches", [])[:5]:
                    self.output.append(f"     {m}")
            elif r.get("action") == "read":
                self.output.append(f"📄 Scanned {len(r.get('files', []))} files")
            self.output.append("")

        self.output.append("-" * 50)
        self.output.append("✅ Agent complete")

    def on_terminal_input(self):
        cursor = self.terminal.textCursor()
        cursor.movePosition(QTextCursor.MoveOperation.StartOfBlock)
        cursor.movePosition(QTextCursor.MoveOperation.EndOfBlock, QTextCursor.MoveMode.KeepAnchor)
        line = cursor.selectedText().strip()

        if line == "agent":
            self.run_agent()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    app.setStyle("Fusion")
    w = SynapseCore()
    w.show()
    sys.exit(app.exec())