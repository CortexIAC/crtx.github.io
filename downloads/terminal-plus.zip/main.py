import sys, subprocess, os
from PyQt6.QtWidgets import (QApplication, QMainWindow, QTabWidget,
    QPlainTextEdit, QInputDialog, QWidget, QVBoxLayout)
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QFont, QTextCursor, QAction, QKeySequence

class Terminal(QPlainTextEdit):
    def __init__(self, name="local"):
        super().__init__()
        self.name = name; self.history = []; self.hi = -1
        self.prompt = f"{name}$ "
        self.setFont(QFont("Courier New", 11))
        self.setStyleSheet("background:#0d0d0d;color:#00ff9c;border:none;")
        self.setLineWrapMode(QPlainTextEdit.LineWrapMode.NoWrap)
        self.appendPlainText(f"Terminal Plus v1.2.0 - {name}")
        self.appendPlainText("help for commands\n" + "-"*40)
        self.appendPlainText(self.prompt)

    def keyPressEvent(self, e):
        if e.key() == Qt.Key.Key_Return: self.exec_cmd()
        elif e.key() == Qt.Key.Key_Backspace and self.textCursor().positionInBlock() <= len(self.prompt): return
        elif e.key() == Qt.Key.Key_Up and self.history:
            self.hi = max(0, self.hi-1); self.replace_line(self.history[self.hi]); return
        elif e.key() == Qt.Key.Key_Down and self.history:
            self.hi = min(len(self.history)-1, self.hi+1); self.replace_line(self.history[self.hi]); return
        elif e.key() == Qt.Key.Key_L and e.modifiers() == Qt.ControlModifier:
            self.clear(); self.appendPlainText(self.prompt); return
        super().keyPressEvent(e)

    def replace_line(self, t):
        c = self.textCursor(); c.movePosition(QTextCursor.MoveOperation.StartOfBlock)
        c.movePosition(QTextCursor.MoveOperation.EndOfBlock, QTextCursor.MoveMode.KeepAnchor)
        c.removeSelectedText(); c.insertText(self.prompt + t)

    def get_cmd(self):
        c = self.textCursor(); c.movePosition(QTextCursor.MoveOperation.StartOfBlock)
        c.movePosition(QTextCursor.MoveOperation.EndOfBlock, QTextCursor.MoveMode.KeepAnchor)
        return c.selectedText()[len(self.prompt):] if c.selectedText().startswith(self.prompt) else ""

    def exec_cmd(self):
        cmd = self.get_cmd().strip()
        if not cmd: self.appendPlainText(self.prompt); return
        self.history.append(cmd); self.hi = len(self.history)
        if cmd == "help":
            self.appendPlainText("  help, clear, exit, date, echo, ls, pwd, whoami, ping <host>")
        elif cmd == "clear": self.clear()
        elif cmd == "exit":
            w = self.parent().parent().parent()
            if hasattr(w, 'removeTab'): w.removeTab(w.indexOfTab(self.parent()))
            return
        elif cmd == "date":
            import datetime; self.appendPlainText(" " + datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
        elif cmd in ("pwd","cwd"): self.appendPlainText(" " + os.getcwd())
        elif cmd == "whoami": self.appendPlainText(" " + os.getenv("USERNAME",os.getenv("USER","unknown")))
        elif cmd.startswith("echo "): self.appendPlainText(" " + cmd[5:])
        elif cmd in ("ls","dir"):
            try: self.appendPlainText("\n".join("  "+f for f in os.listdir(".")))
            except Exception as e: self.appendPlainText(" Error: " + str(e))
        elif cmd.startswith("ping "):
            h = cmd[5:].strip()
            try:
                r = subprocess.run(["ping","-n","1",h],capture_output=True,text=True,timeout=5)
                self.appendPlainText(" " + (r.stdout.split("\n")[2] if r.stdout else "No response"))
            except Exception as e: self.appendPlainText(" Error: " + str(e))
        else:
            try:
                r = subprocess.run(cmd,shell=True,capture_output=True,text=True,timeout=5)
                self.appendPlainText(" " + (r.stdout or r.stderr or "OK").strip()[:2000])
            except: self.appendPlainText(" Unknown command")
        self.appendPlainText("\n" + self.prompt)

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Terminal Plus"); self.resize(900,600)
        self.tabs = QTabWidget(); self.setCentralWidget(self.tabs)
        self.add_tab()
        m = self.menuBar().addMenu("File")
        a = QAction("New Tab (Ctrl+T)", self); a.setShortcut(QKeySequence("Ctrl+T"))
        a.triggered.connect(self.add_tab); m.addAction(a)
    def add_tab(self):
        name, ok = QInputDialog.getText(self, "New Tab", "Name:", text=f"session-{self.tabs.count()+1}")
        if not ok or not name.strip(): name = f"session-{self.tabs.count()+1}"
        w = QWidget(); l = QVBoxLayout(w); l.setContentsMargins(0,0,0,0); l.addWidget(Terminal(name.strip()))
        self.tabs.addTab(w, name.strip()); self.tabs.setCurrentIndex(self.tabs.count()-1)

if __name__ == "__main__":
    app = QApplication(sys.argv); app.setStyle("Fusion")
    w = MainWindow(); w.show(); app.exec()