# Terminal Plus

Multi-tab terminal emulator.

pip install -r requirements.txt
python main.py