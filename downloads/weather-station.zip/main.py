import sys, json, urllib.request, datetime
from PyQt6.QtWidgets import QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QLineEdit, QLabel, QTextEdit
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QFont

API_KEY = ""  # Get free key at https://openweathermap.org/api

class WeatherApp(QMainWindow):
    def __init__(self):
        super().__init__(); self.setWindowTitle("Weather Station"); self.resize(600,500)
        c = QWidget(); l = QVBoxLayout(c); self.setCentralWidget(c)
        h = QHBoxLayout()
        self.input = QLineEdit(); self.input.setPlaceholderText("City name...")
        self.input.setStyleSheet("padding:8px;font-size:14px;")
        h.addWidget(self.input)
        btn = QPushButton("Get Weather"); btn.clicked.connect(self.fetch); h.addWidget(btn)
        l.addLayout(h)
        self.output = QTextEdit(); self.output.setReadOnly(True)
        self.output.setStyleSheet("background:#0d0d0d;color:#00ff9c;font-family:Courier New;font-size:13px;")
        l.addWidget(self.output)
        self.output.setText("Weather Station v1.1.0\nEnter a city and click Get Weather.\nGet a free API key at openweathermap.org")

    def fetch(self):
        city = self.input.text().strip()
        if not city: return
        if not API_KEY:
            self.output.setText("No API key configured.\n1. Go to https://openweathermap.org/api\n2. Sign up for a free key\n3. Edit the API_KEY variable in main.py")
            return
        try:
            url = f"https://api.openweathermap.org/data/2.5/weather?q={urllib.parse.quote(city)}&appid={API_KEY}&units=metric"
            resp = urllib.request.urlopen(url, timeout=10)
            data = json.loads(resp.read())
            w = data["weather"][0]["description"]
            t = data["main"]["temp"]
            feels = data["main"]["feels_like"]
            h = data["main"]["humidity"]
            p = data["main"]["pressure"]
            wind = data["wind"]["speed"]
            name = data["name"]
            self.output.setText(f"Weather for {name}\n{'-'*30}\nConditions: {w}\nTemperature: {t:.1f}C (feels {feels:.1f}C)\nHumidity: {h}%\nPressure: {p} hPa\nWind: {wind} m/s\n{'-'*30}\n{datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        except urllib.error.HTTPError as e:
            self.output.setText(f"HTTP Error: {e.code}\nCity not found or API error.")
        except Exception as e:
            self.output.setText(f"Error: {e}")

if __name__ == "__main__":
    app = QApplication(sys.argv); app.setStyle("Fusion")
    w = WeatherApp(); w.show(); app.exec()