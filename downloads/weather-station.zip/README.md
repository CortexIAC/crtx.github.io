# Weather Station

Weather app using OpenWeatherMap.

pip install -r requirements.txt
Edit API_KEY in main.py
python main.py