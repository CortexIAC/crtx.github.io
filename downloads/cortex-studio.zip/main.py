import sys, os, subprocess, json, time, threading
from PyQt6.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QSplitter, QTextEdit, QPushButton, QLabel, QLineEdit, QTabWidget, QMenuBar,
    QStatusBar, QTreeWidget, QTreeWidgetItem, QFileDialog, QInputDialog, QListWidget, QProgressBar)
from PyQt6.QtCore import Qt, QTimer, QThread, pyqtSignal
from PyQt6.QtGui import QFont, QColor, QTextCursor, QAction, QKeySequence

# ─── CIE Engine (simplified agent) ───
class CEEngine:
    def __init__(self):
        self.history = []
        self.current_task = None
        self.plan = None

    def plan_task(self, goal, project_path="."):
        steps = [
            {"action": "think", "desc": f"Understanding: {goal}", "status": "pending"},
            {"action": "search", "desc": "Finding relevant files", "status": "pending"},
            {"action": "read", "desc": "Reading context", "status": "pending"},
            {"action": "execute", "desc": "Making changes", "status": "pending"},
            {"action": "verify", "desc": "Verifying results", "status": "pending"},
            {"action": "done", "desc": "Complete", "status": "pending"},
        ]
        self.plan = {"goal": goal, "steps": steps, "project": project_path}
        return self.plan

    def execute_step(self, step_idx, callback=None):
        if not self.plan: return
        step = self.plan["steps"][step_idx]
        step["status"] = "running"
        if callback: callback({"type": "step", "step": step, "index": step_idx})

        if step["action"] == "think":
            time.sleep(0.5)
            if callback: callback({"type": "stream", "text": f"Analyzing: {self.plan['goal']}\n"})
            step["status"] = "done"

        elif step["action"] == "search":
            if callback: callback({"type": "progress", "message": "Searching project files..."})
            results = []
            for r, d, f in os.walk(self.plan["project"]):
                for fn in f:
                    if fn.endswith((".py",".js",".html",".css",".json",".md")):
                        fp = os.path.join(r, fn)
                        rel = os.path.relpath(fp, self.plan["project"])
                        try:
                            with open(fp, "r", encoding="utf-8", errors="replace") as fh:
                                content = fh.read()
                            results.append({"file": rel, "size": len(content)})
                        except: pass
            if callback:
                callback({"type": "stream", "text": f"Found {len(results)} project files\n"})
                callback({"type": "progress", "message": f"Scanned {len(results)} files"})
            step["status"] = "done"

        elif step["action"] == "read":
            files_to_read = [f for f in results[:5]] if "results" in dir() else []
            if callback:
                for f in files_to_read[:3]:
                    callback({"type": "stream", "text": f"  Reading: {f['file']} ({f['size']} bytes)\n"})
                    callback({"type": "progress", "message": f"Reading {f['file']}..."})
                    time.sleep(0.1)
            step["status"] = "done"

        elif step["action"] == "execute":
            if callback:
                callback({"type": "stream", "text": "\nExecuting plan...\n"})
                callback({"type": "progress", "message": "Making changes..."})
            step["status"] = "done"

        elif step["action"] == "verify":
            if callback:
                callback({"type": "stream", "text": "Verifying...\n"})
            step["status"] = "done"

        elif step["action"] == "done":
            if callback:
                callback({"type": "stream", "text": "\n✅ Complete\n"})
                callback({"type": "progress", "message": "Done"})
            step["status"] = "done"

        if callback: callback({"type": "step_done", "step": step, "index": step_idx})

# ─── STUDIO MAIN WINDOW ───
class StudioMain(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Cortex Studio")
        self.resize(1400, 900)
        self.project_path = os.getcwd()
        self.engine = CEEngine()
        self.init_ui()

    def init_ui(self):
        mb = self.menuBar()
        fm = mb.addMenu("File")
        a = QAction("Open Project", self); a.setShortcut(QKeySequence("Ctrl+O"))
        a.triggered.connect(self.open_project)
        fm.addAction(a)

        # Central splitter
        main_split = QSplitter(Qt.Orientation.Horizontal)

        # Left: File Explorer + Plan
        left = QWidget()
        ll = QVBoxLayout(left)
        ll.setContentsMargins(0,0,0,0)

        self.file_tree = QTreeWidget()
        self.file_tree.setHeaderLabel("Explorer")
        self.file_tree.setStyleSheet("background:#0d0d0d;color:#ccc;font-size:12px;")
        self.file_tree.itemClicked.connect(self.open_file_viewer)
        ll.addWidget(self.file_tree)

        # Plan panel
        plan_label = QLabel("  Agent Plan")
        plan_label.setStyleSheet("background:#1a1a1a;color:#00ff9c;padding:4px;font-weight:bold;")
        ll.addWidget(plan_label)

        self.plan_list = QListWidget()
        self.plan_list.setStyleSheet("background:#0d0d0d;color:#aaa;font-size:12px;")
        ll.addWidget(self.plan_list)

        # Center: Code + Agent Output
        center = QWidget()
        cl = QVBoxLayout(center)
        cl.setContentsMargins(0,0,0,0)

        self.code_view = QTextEdit()
        self.code_view.setReadOnly(True)
        self.code_view.setFont(QFont("Courier New", 11))
        self.code_view.setStyleSheet("background:#0d0d0d;color:#00ff9c;border:none;")
        self.code_view.setPlainText("// Cortex Studio — Open a file or run the agent")

        # Agent output with streaming
        self.agent_output = QTextEdit()
        self.agent_output.setReadOnly(True)
        self.agent_output.setFont(QFont("Courier New", 11))
        self.agent_output.setStyleSheet("background:#0a0a0a;color:#ccc;border-top:1px solid #333;")
        self.agent_output.setMaximumHeight(200)
        self.agent_output.append("Agent ready")

        code_tabs = QTabWidget()
        code_tabs.addTab(self.code_view, "Code")
        code_tabs.addTab(self.agent_output, "Agent Output")

        cl.addWidget(code_tabs)

        # Progress bar
        self.progress = QProgressBar()
        self.progress.setMaximum(100)
        self.progress.setValue(0)
        self.progress.setStyleSheet("QProgressBar {background:#1a1a1a;border:none;height:4px;} QProgressBar::chunk {background:#00ff9c;}")
        self.progress.hide()
        cl.addWidget(self.progress)

        # Input area
        input_bar = QHBoxLayout()
        self.input_field = QLineEdit()
        self.input_field.setPlaceholderText("Ask the agent to do something...")
        self.input_field.setStyleSheet("padding:10px;background:#1a1a1a;color:#fff;border:1px solid #333;font-size:14px;")
        self.input_field.returnPressed.connect(self.run_agent)
        input_bar.addWidget(self.input_field)

        self.run_btn = QPushButton("Run Agent")
        self.run_btn.setStyleSheet("padding:10px 20px;background:#00ff9c;color:#000;font-weight:bold;border:none;")
        self.run_btn.clicked.connect(self.run_agent)
        input_bar.addWidget(self.run_btn)

        cl.addLayout(input_bar)

        # Right: Status + Task List
        right = QWidget()
        rl = QVBoxLayout(right)
        rl.setContentsMargins(0,0,0,0)

        rl.addWidget(QLabel("  Status"))
        self.status_log = QTextEdit()
        self.status_log.setReadOnly(True)
        self.status_log.setFont(QFont("Courier New", 10))
        self.status_log.setStyleSheet("background:#0d0d0d;color:#888;border:none;")
        rl.addWidget(self.status_log)

        main_split.addWidget(left)
        main_split.addWidget(center)
        main_split.addWidget(right)
        main_split.setSizes([300, 700, 300])

        self.setCentralWidget(main_split)
        self.status_bar = QStatusBar()
        self.setStatusBar(self.status_bar)
        self.status_bar.showMessage("Ready")

        self.load_file_tree()

    def load_file_tree(self):
        self.file_tree.clear()
        root = QTreeWidgetItem(self.file_tree, [os.path.basename(self.project_path)])
        self._populate(root, self.project_path)
        root.setExpanded(True)

    def _populate(self, parent, path):
        try:
            for item in sorted(os.listdir(path)):
                if item.startswith(".") or item in ("__pycache__", "node_modules"): continue
                full = os.path.join(path, item)
                child = QTreeWidgetItem(parent, [item])
                if os.path.isdir(full):
                    self._populate(child, full)
                    child.setChildIndicatorPolicy(QTreeWidgetItem.ChildIndicatorPolicy.ShowIndicator)
        except: pass

    def open_file_viewer(self, item, col):
        path = os.path.join(self.project_path, item.text(0))
        if os.path.isfile(path):
            try:
                with open(path, "r", encoding="utf-8", errors="replace") as f:
                    self.code_view.setPlainText(f.read())
                self.status_bar.showMessage(f"Opened: {item.text(0)}")
            except: pass

    def open_project(self):
        path = QFileDialog.getExistingDirectory(self, "Open Project")
        if path:
            self.project_path = path
            self.load_file_tree()
            self.status_bar.showMessage(f"Project: {path}")

    def run_agent(self):
        goal = self.input_field.text().strip()
        if not goal: return
        self.input_field.clear()

        self.agent_output.clear()
        self.agent_output.append(f"🤖 CIE Agent: {goal}")
        self.agent_output.append("-" * 40)
        self.progress.setValue(0)
        self.progress.show()

        plan = self.engine.plan_task(goal, self.project_path)
        self.plan_list.clear()
        for s in plan["steps"]:
            self.plan_list.addItem(f"⏳ {s['desc']}")

        def callback(msg):
            if msg["type"] == "step":
                idx = msg["index"]
                item = self.plan_list.item(idx)
                if item:
                    item.setText(f"⚡ {msg['step']['desc']}")
                    item.setForeground(QColor("#ffd700"))
            elif msg["type"] == "step_done":
                idx = msg["index"]
                item = self.plan_list.item(idx)
                if item:
                    item.setText(f"✅ {msg['step']['desc']}")
                    item.setForeground(QColor("#00ff9c"))
                self.progress.setValue(int((idx + 1) / len(plan["steps"]) * 100))
            elif msg["type"] == "stream":
                self.agent_output.moveCursor(QTextCursor.MoveOperation.End)
                for ch in msg["text"]:
                    self.agent_output.insertPlainText(ch)
                    self.agent_output.repaint()
                    time.sleep(0.01)
            elif msg["type"] == "progress":
                self.status_bar.showMessage(msg["message"])
                self.status_log.append(f"[{time.strftime('%H:%M:%S')}] {msg['message']}")
                QApplication.processEvents()

        for i in range(len(plan["steps"])):
            callback({"type": "step", "step": plan["steps"][i], "index": i})
            self.engine.execute_step(i, callback)

        self.progress.hide()
        self.status_bar.showMessage("Agent complete")

if __name__ == "__main__":
    app = QApplication(sys.argv)
    app.setStyle("Fusion")
    w = StudioMain()
    w.show()
    sys.exit(app.exec())