"""
Cortex Studio — AI Agent Workspace
Stripped down to: File Explorer + Code Viewer + Agent Chat + Terminal + Plan Panel
Everything else lives in dedicated apps (Horizon, VoiceLab, Arsenal, etc.)
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from PyQt6.QtWidgets import QApplication
from PyQt6.QtCore import Qt

from src.agent_workspace import AgentWorkspace

if __name__ == "__main__":
    app = QApplication(sys.argv)
    app.setStyle("Fusion")
    app.setApplicationName("Cortex Studio")
    app.setOrganizationName("CRTX")

    # Dark palette
    palette = app.palette()
    palette.setColor(palette.ColorRole.Window, Qt.GlobalColor.black)
    palette.setColor(palette.ColorRole.WindowText, Qt.GlobalColor.white)
    palette.setColor(palette.ColorRole.Base, Qt.GlobalColor.black)
    palette.setColor(palette.ColorRole.Text, Qt.GlobalColor.white)
    palette.setColor(palette.ColorRole.Button, Qt.GlobalColor.darkGray)
    app.setPalette(palette)

    try:
        window = AgentWorkspace()
        window.show()
        sys.exit(app.exec())
    except Exception as e:
        import traceback
        print(f"Fatal: {e}")
        traceback.print_exc()
        sys.exit(1)
