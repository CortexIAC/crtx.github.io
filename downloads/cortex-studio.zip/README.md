# Cortex Studio

AI-powered agent workspace.

pip install -r requirements.txt
python main.py