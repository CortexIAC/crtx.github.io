# Cortex Studio CIE Agent

Agentic AI workspace with plan panel, streaming output, file explorer, and status tracking.

pip install -r requirements.txt
python main.py